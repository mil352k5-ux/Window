﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Store_Gold
{
    public partial class FforgotPassword : Form
    {
        Modify modify = new Modify();
        SqlConnection conn = new SqlConnection(Properties.Settings.Default.cnnstr);
        public FforgotPassword()
        {
            InitializeComponent();
        }

        private void panelResetPassword_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnsendmypassword_Click(object sender, EventArgs e)
        {
            string email = txtResetPassword.Text;
            // Kiểm tra xem người dùng đã nhập email hay chưa
            if (string.IsNullOrWhiteSpace(email))
            {
                MessageBox.Show("Please enter the email you registered with!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Kiểm tra xem email có tồn tại trong cơ sở dữ liệu hay không
            string query = "SELECT * FROM accounts WHERE user_email = '" + email + "'";
            List<Account> accounts = modify.Accounts(query);
            if (accounts.Count > 0)
            {
                string newPassword = GenerateRandomPassword();
                SendNewPasswordByEmail(email, newPassword);

                MessageBox.Show("A new password has been sent to your email.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("This email is not registered!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private string GenerateRandomPassword()
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            StringBuilder password = new StringBuilder();
            Random random = new Random();
            for (int i = 0; i < 10; i++)
            {
                password.Append(chars[random.Next(chars.Length)]);
            }
            return password.ToString();
        }

        private void SendNewPasswordByEmail(string recipientEmail, string newPassword)
        {
            try
            {
                // Thiết lập thông tin máy chủ SMTP (ví dụ là Gmail)
                SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
                client.UseDefaultCredentials = false;
                client.EnableSsl = true; // Sử dụng SSL hoặc STARTTLS
                client.Credentials = new NetworkCredential("kcvteam134493@gmail.com", "gsxl vmsp shhg nflb");

                // Tạo nội dung email
                MailMessage mail = new MailMessage();
                mail.From = new MailAddress("kcvteam134493@gmail.com");
                mail.To.Add(recipientEmail);
                mail.Subject = "New Password";
                mail.Body = "Your new password: " + newPassword;
                // Gửi email
                client.Send(mail);
                conn.Open();
                SqlCommand cmdUpdatePassword = new SqlCommand("UPDATE Accounts SET user_password = @newPassword WHERE user_email = @userEmail", conn);
                cmdUpdatePassword.Parameters.AddWithValue("@newPassword", newPassword);
                cmdUpdatePassword.Parameters.AddWithValue("@userEmail", recipientEmail);
                cmdUpdatePassword.ExecuteNonQuery();
                MessageBox.Show("New password sent successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to send new password: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }
    }
}
