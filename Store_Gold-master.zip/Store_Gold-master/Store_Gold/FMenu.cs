﻿using Microsoft.VisualBasic.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Guna.UI2.WinForms;

namespace Store_Gold
{
    public partial class FMenu : Form
    {
        bool navigationExpand;
        private Button currentButton;
        private Random random;
        private int tempIndex;
        private Form activeForm;
        public FMenu()
        {
            InitializeComponent();
            DisplayCustomerName();
            random = new Random();
            UCMenucustomer.panelAccount.MouseHover += UCMenucustomer.panelAccount_MouseHover;
            UCMenucustomer.btnbutton1.Click += btnHomeMenu_Click;
            UCMenucustomer.btnbutton2.Click += btnListProduct_Click;
          
    

        }
        private void DisplayCustomerName()
        {
            GetInforItem();
        }
        private void GetInforItem()
        {
            UCMenucustomer.lblNameAccount.Text = "Xin chào, " + Form1.currentAccount.UserName;
            UCMenucustomer.btnbutton1.Text = "HOME";
            UCMenucustomer.btnbutton2.Text = "Product";
            UCMenucustomer.btnbutton3.Text = "SERVICE";
            UCMenucustomer.btnbutton4.Text = "BOOKING";
        }
        private Color SelectThemeColor()
        {
            int index = random.Next(ThemeColor.ColorList.Count);
            while (tempIndex == index)
            {
                index = random.Next(ThemeColor.ColorList.Count);

            }
            tempIndex = index;
            string color = ThemeColor.ColorList[index];
            return ColorTranslator.FromHtml(color);
        }
        private void ActivateButton(object btnsender)
        {
            if (btnsender != null)
            {
                if (currentButton != (Button)btnsender)
                {
                    DisableButton();
                    Color color = SelectThemeColor();
                    currentButton = (Button)btnsender;
                    currentButton.BackColor = color;
                    currentButton.ForeColor = Color.White;
                    currentButton.Font = new Font("Segoe UI", 11.5F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
                    //panelLogo1.BackColor = ThemeColor.ChangeColorBrightness(color, -0.3);
                    UCMenucustomer.panelAccount.BackColor = ThemeColor.ChangeColorBrightness(color, -0.3);
                    UCMenucustomer.panelTitle.BackColor = ThemeColor.ChangeColorBrightness(color, -0.3);
                    //ThemeColor.Primarycolor = color;
                    //ThemeColor.Secondarycolor = ThemeColor.ChangeColorBrightness(color, -0.3);
                }
            }
        }
        private void DisableButton()
        {
            foreach (Control previousBtn in UCMenucustomer.panelbtnmenu.Controls)
            {
                if (previousBtn.GetType() == typeof(Button))
                {
                    previousBtn.BackColor = Color.White;
                    previousBtn.ForeColor = Color.Black;
                    previousBtn.Font = new Font("Segoe UI Black", 11F, FontStyle.Bold, GraphicsUnit.Point);
                }
            }
        }
        private void OpenChildForm(Form childForm, object btnSender)
        {
            if (activeForm != null)
                activeForm.Close();
            ActivateButton(btnSender);
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            UCMenucustomer.panelDesktoppane.Controls.Add(childForm);
            UCMenucustomer.panelDesktoppane.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        private void btnHomeMenu_Click(object sender, EventArgs e)
        {
          
        }

        private void btnListProduct_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FListProduct(), sender);
        }

        private void btnBillMenu_Click(object sender, EventArgs e)
        {
           
        }
        private void btnManageInformation_Click(object sender, EventArgs e)
        {

        }

        private void btnLogoutMenu_Click(object sender, EventArgs e)
        {

        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void panelDesktoppane_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lblTitle_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            //timerofnavigatorCustomer.Start();
        }

        private void timerofnavigatorCustomer_Tick(object sender, EventArgs e)
        {
            /*if (navigationExpand)
            {
                UCMenucustomer.panelMenuTopOfMain.Height -= 10;
                if (panelMenuTopOfMain.Height == panelMenuTopOfMain.MinimumSize.Height)
                {
                    navigationExpand = false;
                    timerofnavigatorCustomer.Stop();
                }

            }
            else
            {
                panelMenuTpOfMain.Height += 10;
                if (panelMenuTpOfMain.Height == panelMenuTpOfMain.MaximumSize.Height)
                {
                    navigationExpand = true;
                    timerofnavigatorCustomer.Stop();
                }
            }*/
        }

        private void FMenu_Load(object sender, EventArgs e)
        {

        }

        

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
