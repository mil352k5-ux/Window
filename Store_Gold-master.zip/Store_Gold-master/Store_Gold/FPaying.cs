﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Store_Gold
{
    public partial class FPaying : Form
    {
        public FPaying()
        {
            InitializeComponent();
        }

        private void txtQuantity_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
