﻿namespace Store_Gold
{
    partial class FPrintBill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FPrintBill));
            lblCustomerName = new Label();
            lblCustomer = new Label();
            lblCustomerID = new Label();
            lblStaff = new Label();
            lblStaffID = new Label();
            lblDate2 = new Label();
            lblStaffName = new Label();
            lblBillID = new Label();
            lblAddress = new Label();
            ptbiconBill = new PictureBox();
            label1 = new Label();
            lblInvoice = new Label();
            panelBill1 = new Panel();
            btnPrintBill = new Guna.UI2.WinForms.Guna2Button();
            lblgmailoffices = new Label();
            lblPhonenumberStaff = new Label();
            lblMailAdmin = new Label();
            lblDateorder = new Label();
            lblPhoneStaffbill = new Label();
            panel2 = new Panel();
            dgvproductsorder = new DataGridView();
            lblThankyous = new Label();
            Total = new Label();
            lblTotal = new Label();
            printPreviewDialog1 = new PrintPreviewDialog();
            printDocument1 = new System.Drawing.Printing.PrintDocument();
            btnclosebill = new Button();
            ((System.ComponentModel.ISupportInitialize)ptbiconBill).BeginInit();
            panelBill1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvproductsorder).BeginInit();
            SuspendLayout();
            // 
            // lblCustomerName
            // 
            lblCustomerName.AutoSize = true;
            lblCustomerName.Font = new Font("Segoe UI Semilight", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblCustomerName.ForeColor = Color.Black;
            lblCustomerName.Location = new Point(41, 344);
            lblCustomerName.Name = "lblCustomerName";
            lblCustomerName.Size = new Size(101, 23);
            lblCustomerName.TabIndex = 8;
            lblCustomerName.Text = "John Smiths.";
            // 
            // lblCustomer
            // 
            lblCustomer.AutoSize = true;
            lblCustomer.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lblCustomer.ForeColor = Color.DarkRed;
            lblCustomer.Location = new Point(37, 265);
            lblCustomer.Name = "lblCustomer";
            lblCustomer.Size = new Size(105, 25);
            lblCustomer.TabIndex = 7;
            lblCustomer.Text = "Customer";
            // 
            // lblCustomerID
            // 
            lblCustomerID.AutoSize = true;
            lblCustomerID.Font = new Font("Segoe UI Semilight", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblCustomerID.ForeColor = Color.Black;
            lblCustomerID.Location = new Point(41, 308);
            lblCustomerID.Name = "lblCustomerID";
            lblCustomerID.Size = new Size(61, 23);
            lblCustomerID.TabIndex = 9;
            lblCustomerID.Text = "123456";
            // 
            // lblStaff
            // 
            lblStaff.AutoSize = true;
            lblStaff.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lblStaff.ForeColor = Color.DarkRed;
            lblStaff.Location = new Point(216, 265);
            lblStaff.Name = "lblStaff";
            lblStaff.Size = new Size(57, 25);
            lblStaff.TabIndex = 10;
            lblStaff.Text = "Staff";
            // 
            // lblStaffID
            // 
            lblStaffID.AutoSize = true;
            lblStaffID.Font = new Font("Segoe UI Semilight", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblStaffID.ForeColor = Color.Black;
            lblStaffID.Location = new Point(216, 308);
            lblStaffID.Name = "lblStaffID";
            lblStaffID.Size = new Size(61, 23);
            lblStaffID.TabIndex = 11;
            lblStaffID.Text = "123456";
            // 
            // lblDate2
            // 
            lblDate2.AutoSize = true;
            lblDate2.Font = new Font("Century Gothic", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lblDate2.ForeColor = Color.Black;
            lblDate2.Location = new Point(37, 112);
            lblDate2.Name = "lblDate2";
            lblDate2.Size = new Size(54, 21);
            lblDate2.TabIndex = 4;
            lblDate2.Text = "Date:";
            // 
            // lblStaffName
            // 
            lblStaffName.AutoSize = true;
            lblStaffName.Font = new Font("Segoe UI Semilight", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblStaffName.ForeColor = Color.Black;
            lblStaffName.Location = new Point(216, 344);
            lblStaffName.Name = "lblStaffName";
            lblStaffName.Size = new Size(104, 23);
            lblStaffName.TabIndex = 12;
            lblStaffName.Text = "David Brown";
            // 
            // lblBillID
            // 
            lblBillID.AutoSize = true;
            lblBillID.Font = new Font("Segoe UI Light", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblBillID.Location = new Point(598, 60);
            lblBillID.Name = "lblBillID";
            lblBillID.Size = new Size(61, 23);
            lblBillID.TabIndex = 3;
            lblBillID.Text = "000001";
            // 
            // lblAddress
            // 
            lblAddress.AutoSize = true;
            lblAddress.Font = new Font("Century Gothic", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lblAddress.ForeColor = Color.Black;
            lblAddress.Location = new Point(37, 144);
            lblAddress.Name = "lblAddress";
            lblAddress.Size = new Size(78, 21);
            lblAddress.TabIndex = 13;
            lblAddress.Text = "Address:";
            // 
            // ptbiconBill
            // 
            ptbiconBill.Image = Properties.Resources.icons8_bill_64;
            ptbiconBill.Location = new Point(37, 9);
            ptbiconBill.Name = "ptbiconBill";
            ptbiconBill.Size = new Size(88, 78);
            ptbiconBill.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbiconBill.TabIndex = 2;
            ptbiconBill.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semilight", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.DimGray;
            label1.Location = new Point(121, 144);
            label1.Name = "label1";
            label1.Size = new Size(296, 23);
            label1.TabIndex = 14;
            label1.Text = "1912 Harvest Lane, New York, NY 12210";
            // 
            // lblInvoice
            // 
            lblInvoice.AutoSize = true;
            lblInvoice.Font = new Font("Segoe UI", 24F, FontStyle.Bold, GraphicsUnit.Point);
            lblInvoice.ForeColor = Color.IndianRed;
            lblInvoice.Location = new Point(272, 9);
            lblInvoice.Name = "lblInvoice";
            lblInvoice.Size = new Size(158, 54);
            lblInvoice.TabIndex = 0;
            lblInvoice.Text = "Invoice";
            // 
            // panelBill1
            // 
            panelBill1.Controls.Add(btnclosebill);
            panelBill1.Controls.Add(btnPrintBill);
            panelBill1.Controls.Add(lblgmailoffices);
            panelBill1.Controls.Add(lblPhonenumberStaff);
            panelBill1.Controls.Add(lblMailAdmin);
            panelBill1.Controls.Add(lblDateorder);
            panelBill1.Controls.Add(lblPhoneStaffbill);
            panelBill1.Controls.Add(lblInvoice);
            panelBill1.Controls.Add(label1);
            panelBill1.Controls.Add(ptbiconBill);
            panelBill1.Controls.Add(lblAddress);
            panelBill1.Controls.Add(lblBillID);
            panelBill1.Controls.Add(lblStaffName);
            panelBill1.Controls.Add(lblDate2);
            panelBill1.Controls.Add(lblStaffID);
            panelBill1.Controls.Add(lblStaff);
            panelBill1.Controls.Add(lblCustomerID);
            panelBill1.Controls.Add(lblCustomer);
            panelBill1.Controls.Add(lblCustomerName);
            panelBill1.Dock = DockStyle.Top;
            panelBill1.Location = new Point(0, 0);
            panelBill1.Name = "panelBill1";
            panelBill1.Size = new Size(723, 403);
            panelBill1.TabIndex = 18;
            // 
            // btnPrintBill
            // 
            btnPrintBill.CustomizableEdges = customizableEdges3;
            btnPrintBill.DisabledState.BorderColor = Color.DarkGray;
            btnPrintBill.DisabledState.CustomBorderColor = Color.DarkGray;
            btnPrintBill.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnPrintBill.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnPrintBill.FillColor = Color.Transparent;
            btnPrintBill.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnPrintBill.ForeColor = Color.White;
            btnPrintBill.Image = Properties.Resources.icons8_print_48;
            btnPrintBill.ImageSize = new Size(50, 50);
            btnPrintBill.Location = new Point(585, 3);
            btnPrintBill.Name = "btnPrintBill";
            btnPrintBill.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btnPrintBill.Size = new Size(74, 54);
            btnPrintBill.TabIndex = 23;
            btnPrintBill.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            btnPrintBill.Click += btnPrintBill_Click;
            // 
            // lblgmailoffices
            // 
            lblgmailoffices.AutoSize = true;
            lblgmailoffices.Font = new Font("Segoe UI Semilight", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblgmailoffices.ForeColor = Color.DimGray;
            lblgmailoffices.Location = new Point(109, 220);
            lblgmailoffices.Name = "lblgmailoffices";
            lblgmailoffices.Size = new Size(217, 23);
            lblgmailoffices.TabIndex = 20;
            lblgmailoffices.Text = "toankhoa86443@gmail.com";
            // 
            // lblPhonenumberStaff
            // 
            lblPhonenumberStaff.AutoSize = true;
            lblPhonenumberStaff.Font = new Font("Segoe UI Semilight", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblPhonenumberStaff.ForeColor = Color.DimGray;
            lblPhonenumberStaff.Location = new Point(147, 180);
            lblPhonenumberStaff.Name = "lblPhonenumberStaff";
            lblPhonenumberStaff.Size = new Size(122, 23);
            lblPhonenumberStaff.TabIndex = 19;
            lblPhonenumberStaff.Text = "+84 382186443";
            // 
            // lblMailAdmin
            // 
            lblMailAdmin.AutoSize = true;
            lblMailAdmin.Font = new Font("Century Gothic", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lblMailAdmin.ForeColor = Color.Black;
            lblMailAdmin.Location = new Point(41, 220);
            lblMailAdmin.Name = "lblMailAdmin";
            lblMailAdmin.Size = new Size(64, 21);
            lblMailAdmin.TabIndex = 18;
            lblMailAdmin.Text = "Gmail:";
            // 
            // lblDateorder
            // 
            lblDateorder.AutoSize = true;
            lblDateorder.Font = new Font("Segoe UI Semilight", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblDateorder.ForeColor = Color.DimGray;
            lblDateorder.Location = new Point(109, 112);
            lblDateorder.Name = "lblDateorder";
            lblDateorder.Size = new Size(49, 23);
            lblDateorder.TabIndex = 16;
            lblDateorder.Text = "Date:";
            // 
            // lblPhoneStaffbill
            // 
            lblPhoneStaffbill.AutoSize = true;
            lblPhoneStaffbill.Font = new Font("Century Gothic", 10.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            lblPhoneStaffbill.ForeColor = Color.Black;
            lblPhoneStaffbill.Location = new Point(37, 180);
            lblPhoneStaffbill.Name = "lblPhoneStaffbill";
            lblPhoneStaffbill.Size = new Size(104, 21);
            lblPhoneStaffbill.TabIndex = 17;
            lblPhoneStaffbill.Text = "Phone, NO:";
            // 
            // panel2
            // 
            panel2.Controls.Add(dgvproductsorder);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 403);
            panel2.Name = "panel2";
            panel2.Size = new Size(723, 257);
            panel2.TabIndex = 19;
            // 
            // dgvproductsorder
            // 
            dgvproductsorder.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvproductsorder.Dock = DockStyle.Fill;
            dgvproductsorder.Location = new Point(0, 0);
            dgvproductsorder.Name = "dgvproductsorder";
            dgvproductsorder.RowHeadersWidth = 51;
            dgvproductsorder.RowTemplate.Height = 29;
            dgvproductsorder.Size = new Size(723, 257);
            dgvproductsorder.TabIndex = 0;
            // 
            // lblThankyous
            // 
            lblThankyous.AutoSize = true;
            lblThankyous.Font = new Font("Corbel", 13.8F, FontStyle.Italic, GraphicsUnit.Point);
            lblThankyous.ForeColor = Color.Black;
            lblThankyous.Location = new Point(608, 749);
            lblThankyous.Name = "lblThankyous";
            lblThankyous.Size = new Size(115, 28);
            lblThankyous.TabIndex = 21;
            lblThankyous.Text = "Thanks You";
            // 
            // Total
            // 
            Total.AutoSize = true;
            Total.Font = new Font("Corbel", 13.8F, FontStyle.Italic, GraphicsUnit.Point);
            Total.ForeColor = Color.Black;
            Total.Location = new Point(508, 680);
            Total.Name = "Total";
            Total.Size = new Size(66, 28);
            Total.TabIndex = 22;
            Total.Text = "Total:";
            // 
            // lblTotal
            // 
            lblTotal.AutoSize = true;
            lblTotal.Font = new Font("Segoe UI Semilight", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblTotal.ForeColor = Color.Black;
            lblTotal.Location = new Point(598, 680);
            lblTotal.Name = "lblTotal";
            lblTotal.Size = new Size(61, 23);
            lblTotal.TabIndex = 21;
            lblTotal.Text = "123456";
            // 
            // printPreviewDialog1
            // 
            printPreviewDialog1.AutoScrollMargin = new Size(0, 0);
            printPreviewDialog1.AutoScrollMinSize = new Size(0, 0);
            printPreviewDialog1.ClientSize = new Size(400, 300);
            printPreviewDialog1.Enabled = true;
            printPreviewDialog1.Icon = (Icon)resources.GetObject("printPreviewDialog1.Icon");
            printPreviewDialog1.Name = "printPreviewDialog1";
            printPreviewDialog1.Visible = false;
            // 
            // btnclosebill
            // 
            btnclosebill.Image = Properties.Resources.icons8_logout_100;
            btnclosebill.Location = new Point(672, 3);
            btnclosebill.Name = "btnclosebill";
            btnclosebill.Size = new Size(48, 35);
            btnclosebill.TabIndex = 24;
            btnclosebill.UseVisualStyleBackColor = true;
            btnclosebill.Click += btnclosebill_Click;
            // 
            // FPrintBill
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImageLayout = ImageLayout.None;
            ClientSize = new Size(723, 775);
            ControlBox = false;
            Controls.Add(lblTotal);
            Controls.Add(Total);
            Controls.Add(lblThankyous);
            Controls.Add(panel2);
            Controls.Add(panelBill1);
            Name = "FPrintBill";
            ShowIcon = false;
            ShowInTaskbar = false;
            Load += FPrintBill_Load;
            ((System.ComponentModel.ISupportInitialize)ptbiconBill).EndInit();
            panelBill1.ResumeLayout(false);
            panelBill1.PerformLayout();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvproductsorder).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblCustomerName;
        private Label lblCustomer;
        private Label lblCustomerID;
        private Label lblStaff;
        private Label lblStaffID;
        private Label lblDate2;
        private Label lblStaffName;
        private Label lblBillID;
        private Label lblAddress;
        private PictureBox ptbiconBill;
        private Label label1;
        private Label lblInvoice;
        private Panel panelBill1;
        private Label lblDateorder;
        private Panel panel2;
        private Label lblMailAdmin;
        private Label lblPhoneStaffbill;
        private Label lblgmailoffices;
        private Label lblPhonenumberStaff;
        private Label lblThankyous;
        private DataGridView dgvproductsorder;
        private Label Total;
        private Label lblTotal;
        private Guna.UI2.WinForms.Guna2Button btnPrintBill;
        private PrintPreviewDialog printPreviewDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private Button btnclosebill;
    }
}