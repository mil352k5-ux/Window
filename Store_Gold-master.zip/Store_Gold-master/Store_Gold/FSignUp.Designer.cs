﻿namespace ProjectFinalKCVTourism
{
    partial class FSignUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panelSignUp = new Panel();
            txtPhonenumberregister = new Guna.UI2.WinForms.Guna2TextBox();
            lblPhonenumberRegister = new Label();
            linkLabelAlreadymember = new LinkLabel();
            ptbAccount = new PictureBox();
            btnRegister = new Guna.UI2.WinForms.Guna2Button();
            txtVerifyPassword = new Guna.UI2.WinForms.Guna2TextBox();
            label1 = new Label();
            txtPassword = new Guna.UI2.WinForms.Guna2TextBox();
            lblPassword = new Label();
            txtIDCard = new Guna.UI2.WinForms.Guna2TextBox();
            lblIDCard = new Label();
            txtYourName = new Guna.UI2.WinForms.Guna2TextBox();
            lblFirstName = new Label();
            txtContactEmail = new Guna.UI2.WinForms.Guna2TextBox();
            lblContactEmail = new Label();
            lblNotice = new Label();
            epContactEmail = new Guna.UI2.WinForms.Guna2Elipse(components);
            panel1 = new Panel();
            lbltitleKCV = new Label();
            panelSignUp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ptbAccount).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panelSignUp
            // 
            panelSignUp.BackColor = Color.LightBlue;
            panelSignUp.Controls.Add(txtPhonenumberregister);
            panelSignUp.Controls.Add(lblPhonenumberRegister);
            panelSignUp.Controls.Add(linkLabelAlreadymember);
            panelSignUp.Controls.Add(ptbAccount);
            panelSignUp.Controls.Add(btnRegister);
            panelSignUp.Controls.Add(txtVerifyPassword);
            panelSignUp.Controls.Add(label1);
            panelSignUp.Controls.Add(txtPassword);
            panelSignUp.Controls.Add(lblPassword);
            panelSignUp.Controls.Add(txtIDCard);
            panelSignUp.Controls.Add(lblIDCard);
            panelSignUp.Controls.Add(txtYourName);
            panelSignUp.Controls.Add(lblFirstName);
            panelSignUp.Controls.Add(txtContactEmail);
            panelSignUp.Controls.Add(lblContactEmail);
            panelSignUp.Location = new Point(165, 99);
            panelSignUp.Name = "panelSignUp";
            panelSignUp.Size = new Size(850, 706);
            panelSignUp.TabIndex = 0;
            panelSignUp.Paint += panelSignUp_Paint;
            // 
            // txtPhonenumberregister
            // 
            txtPhonenumberregister.BorderRadius = 20;
            txtPhonenumberregister.BorderThickness = 0;
            txtPhonenumberregister.CustomizableEdges = customizableEdges1;
            txtPhonenumberregister.DefaultText = "";
            txtPhonenumberregister.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPhonenumberregister.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPhonenumberregister.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPhonenumberregister.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPhonenumberregister.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPhonenumberregister.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtPhonenumberregister.ForeColor = Color.Black;
            txtPhonenumberregister.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPhonenumberregister.Location = new Point(28, 362);
            txtPhonenumberregister.Name = "txtPhonenumberregister";
            txtPhonenumberregister.PasswordChar = '\0';
            txtPhonenumberregister.PlaceholderText = "";
            txtPhonenumberregister.SelectedText = "";
            txtPhonenumberregister.ShadowDecoration.CustomizableEdges = customizableEdges2;
            txtPhonenumberregister.Size = new Size(354, 46);
            txtPhonenumberregister.TabIndex = 19;
            // 
            // lblPhonenumberRegister
            // 
            lblPhonenumberRegister.AutoSize = true;
            lblPhonenumberRegister.Font = new Font("Georgia", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblPhonenumberRegister.Location = new Point(28, 336);
            lblPhonenumberRegister.Name = "lblPhonenumberRegister";
            lblPhonenumberRegister.Size = new Size(154, 21);
            lblPhonenumberRegister.TabIndex = 18;
            lblPhonenumberRegister.Text = "PhoneNumber:";
            // 
            // linkLabelAlreadymember
            // 
            linkLabelAlreadymember.AutoSize = true;
            linkLabelAlreadymember.Font = new Font("Century Gothic", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            linkLabelAlreadymember.LinkColor = Color.RoyalBlue;
            linkLabelAlreadymember.Location = new Point(549, 622);
            linkLabelAlreadymember.Name = "linkLabelAlreadymember";
            linkLabelAlreadymember.Size = new Size(166, 19);
            linkLabelAlreadymember.TabIndex = 17;
            linkLabelAlreadymember.TabStop = true;
            linkLabelAlreadymember.Text = "I'm alreay member";
            linkLabelAlreadymember.LinkClicked += linkLabelAlreadymember_LinkClicked;
            // 
            // ptbAccount
            // 
            //ptbAccount.Image = Properties.Resources.kyc;
            ptbAccount.Location = new Point(491, 362);
            ptbAccount.Name = "ptbAccount";
            ptbAccount.Size = new Size(283, 256);
            ptbAccount.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbAccount.TabIndex = 16;
            ptbAccount.TabStop = false;
            // 
            // btnRegister
            // 
            btnRegister.BorderRadius = 25;
            btnRegister.CustomizableEdges = customizableEdges3;
            btnRegister.DisabledState.BorderColor = Color.DarkGray;
            btnRegister.DisabledState.CustomBorderColor = Color.DarkGray;
            btnRegister.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnRegister.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnRegister.FillColor = Color.DarkSalmon;
            btnRegister.Font = new Font("Georgia", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnRegister.ForeColor = Color.White;
            btnRegister.Location = new Point(144, 622);
            btnRegister.Name = "btnRegister";
            btnRegister.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btnRegister.Size = new Size(124, 57);
            btnRegister.TabIndex = 13;
            btnRegister.Text = "Register";
            btnRegister.Click += btnRegister_Click;
            // 
            // txtVerifyPassword
            // 
            txtVerifyPassword.BorderRadius = 20;
            txtVerifyPassword.BorderThickness = 0;
            txtVerifyPassword.CustomizableEdges = customizableEdges5;
            txtVerifyPassword.DefaultText = "";
            txtVerifyPassword.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtVerifyPassword.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtVerifyPassword.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtVerifyPassword.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtVerifyPassword.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtVerifyPassword.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtVerifyPassword.ForeColor = Color.Black;
            txtVerifyPassword.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtVerifyPassword.Location = new Point(28, 549);
            txtVerifyPassword.Name = "txtVerifyPassword";
            txtVerifyPassword.PasswordChar = '\0';
            txtVerifyPassword.PlaceholderText = "";
            txtVerifyPassword.SelectedText = "";
            txtVerifyPassword.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtVerifyPassword.Size = new Size(354, 46);
            txtVerifyPassword.TabIndex = 12;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Georgia", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(28, 523);
            label1.Name = "label1";
            label1.Size = new Size(175, 21);
            label1.TabIndex = 11;
            label1.Text = "Vertify Password:";
            // 
            // txtPassword
            // 
            txtPassword.BorderRadius = 20;
            txtPassword.BorderThickness = 0;
            txtPassword.CustomizableEdges = customizableEdges7;
            txtPassword.DefaultText = "";
            txtPassword.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPassword.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPassword.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPassword.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPassword.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPassword.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtPassword.ForeColor = Color.Black;
            txtPassword.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPassword.Location = new Point(28, 452);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '\0';
            txtPassword.PlaceholderText = "";
            txtPassword.SelectedText = "";
            txtPassword.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtPassword.Size = new Size(354, 46);
            txtPassword.TabIndex = 10;
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Font = new Font("Georgia", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblPassword.Location = new Point(28, 428);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(107, 21);
            lblPassword.TabIndex = 9;
            lblPassword.Text = "Password:";
            // 
            // txtIDCard
            // 
            txtIDCard.BorderRadius = 20;
            txtIDCard.BorderThickness = 0;
            txtIDCard.CustomizableEdges = customizableEdges9;
            txtIDCard.DefaultText = "";
            txtIDCard.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtIDCard.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtIDCard.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtIDCard.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtIDCard.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtIDCard.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtIDCard.ForeColor = Color.Black;
            txtIDCard.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtIDCard.Location = new Point(28, 270);
            txtIDCard.Name = "txtIDCard";
            txtIDCard.PasswordChar = '\0';
            txtIDCard.PlaceholderText = "";
            txtIDCard.SelectedText = "";
            txtIDCard.ShadowDecoration.CustomizableEdges = customizableEdges10;
            txtIDCard.Size = new Size(354, 46);
            txtIDCard.TabIndex = 8;
            // 
            // lblIDCard
            // 
            lblIDCard.AutoSize = true;
            lblIDCard.Font = new Font("Georgia", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblIDCard.Location = new Point(28, 246);
            lblIDCard.Name = "lblIDCard";
            lblIDCard.Size = new Size(90, 21);
            lblIDCard.TabIndex = 7;
            lblIDCard.Text = "IDCard: ";
            // 
            // txtYourName
            // 
            txtYourName.BorderRadius = 20;
            txtYourName.BorderThickness = 0;
            txtYourName.CustomizableEdges = customizableEdges11;
            txtYourName.DefaultText = "";
            txtYourName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtYourName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtYourName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtYourName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtYourName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtYourName.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtYourName.ForeColor = Color.Black;
            txtYourName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtYourName.Location = new Point(28, 182);
            txtYourName.Name = "txtYourName";
            txtYourName.PasswordChar = '\0';
            txtYourName.PlaceholderText = "";
            txtYourName.SelectedText = "";
            txtYourName.ShadowDecoration.CustomizableEdges = customizableEdges12;
            txtYourName.Size = new Size(354, 46);
            txtYourName.TabIndex = 6;
            // 
            // lblFirstName
            // 
            lblFirstName.AutoSize = true;
            lblFirstName.Font = new Font("Georgia", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblFirstName.Location = new Point(28, 158);
            lblFirstName.Name = "lblFirstName";
            lblFirstName.Size = new Size(117, 21);
            lblFirstName.TabIndex = 5;
            lblFirstName.Text = "YourName:";
            // 
            // txtContactEmail
            // 
            txtContactEmail.BackColor = Color.Transparent;
            txtContactEmail.BorderColor = Color.DimGray;
            txtContactEmail.BorderRadius = 20;
            txtContactEmail.BorderStyle = System.Drawing.Drawing2D.DashStyle.Dash;
            txtContactEmail.BorderThickness = 0;
            txtContactEmail.Cursor = Cursors.IBeam;
            txtContactEmail.CustomizableEdges = customizableEdges13;
            txtContactEmail.DefaultText = "";
            txtContactEmail.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtContactEmail.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtContactEmail.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtContactEmail.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtContactEmail.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtContactEmail.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtContactEmail.ForeColor = Color.Black;
            txtContactEmail.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtContactEmail.Location = new Point(28, 82);
            txtContactEmail.Name = "txtContactEmail";
            txtContactEmail.PasswordChar = '\0';
            txtContactEmail.PlaceholderForeColor = Color.White;
            txtContactEmail.PlaceholderText = "";
            txtContactEmail.SelectedText = "";
            txtContactEmail.ShadowDecoration.CustomizableEdges = customizableEdges14;
            txtContactEmail.Size = new Size(354, 46);
            txtContactEmail.TabIndex = 4;
            // 
            // lblContactEmail
            // 
            lblContactEmail.AutoSize = true;
            lblContactEmail.Font = new Font("Georgia", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblContactEmail.ForeColor = SystemColors.InactiveCaptionText;
            lblContactEmail.Location = new Point(28, 55);
            lblContactEmail.Name = "lblContactEmail";
            lblContactEmail.Size = new Size(148, 21);
            lblContactEmail.TabIndex = 3;
            lblContactEmail.Text = "ContactEmail: ";
            // 
            // lblNotice
            // 
            lblNotice.AutoSize = true;
            lblNotice.Font = new Font("Century Gothic", 7.8F, FontStyle.Italic | FontStyle.Underline, GraphicsUnit.Point);
            lblNotice.ForeColor = Color.Black;
            lblNotice.Location = new Point(324, 66);
            lblNotice.Name = "lblNotice";
            lblNotice.Size = new Size(580, 16);
            lblNotice.TabIndex = 2;
            lblNotice.Text = "Please complete this form to create an account, receive email updates and much more.";
            lblNotice.Click += lblNotice_Click;
            // 
            // epContactEmail
            // 
            epContactEmail.BorderRadius = 100;
            epContactEmail.TargetControl = panelSignUp;
            // 
            // panel1
            // 
            panel1.BackColor = Color.GhostWhite;
            panel1.Controls.Add(lbltitleKCV);
            panel1.Controls.Add(lblNotice);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1182, 93);
            panel1.TabIndex = 17;
            // 
            // lbltitleKCV
            // 
            lbltitleKCV.AutoSize = true;
            lbltitleKCV.BackColor = Color.Transparent;
            lbltitleKCV.Font = new Font("Gill Sans Ultra Bold", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point);
            lbltitleKCV.ForeColor = Color.MediumAquamarine;
            lbltitleKCV.Location = new Point(517, 18);
            lbltitleKCV.Name = "lbltitleKCV";
            lbltitleKCV.Size = new Size(179, 48);
            lbltitleKCV.TabIndex = 18;
            lbltitleKCV.Text = "Sign Up";
            // 
            // FSignUp
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.GhostWhite;
            ClientSize = new Size(1182, 853);
            Controls.Add(panel1);
            Controls.Add(panelSignUp);
            Name = "FSignUp";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FSignUp";
            Load += FSignUp_Load;
            panelSignUp.ResumeLayout(false);
            panelSignUp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)ptbAccount).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelSignUp;
        private Label lblNotice;
        private Label lblContactEmail;
        private Label lblFirstName;
        private Guna.UI2.WinForms.Guna2Button btnRegister;
        private Guna.UI2.WinForms.Guna2TextBox txtVerifyPassword;
        private Label label1;
        private Guna.UI2.WinForms.Guna2TextBox txtPassword;
        private Label lblPassword;
        private Guna.UI2.WinForms.Guna2TextBox txtIDCard;
        private Label lblIDCard;
        private Guna.UI2.WinForms.Guna2TextBox txtYourName;
        private Guna.UI2.WinForms.Guna2Elipse epContactEmail;
        private Panel panel1;
        private Label lbltitleKCV;
        public Guna.UI2.WinForms.Guna2TextBox txtContactEmail;
        private PictureBox ptbAccount;
        private LinkLabel linkLabelAlreadymember;
        private Guna.UI2.WinForms.Guna2TextBox txtPhonenumberregister;
        private Label lblPhonenumberRegister;
    }
}