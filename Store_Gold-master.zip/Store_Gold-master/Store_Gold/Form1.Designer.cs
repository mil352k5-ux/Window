﻿namespace Store_Gold
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panelSignIn = new Panel();
            cbshowpasswordSignin = new CheckBox();
            linklblEmailContact = new LinkLabel();
            lblsupporttitle3 = new Label();
            lblsupporttitle2 = new Label();
            lblsupporttitle1 = new Label();
            btnCloseLogin = new Button();
            pcLogoAvatar = new PictureBox();
            linklblForgotAccount = new LinkLabel();
            btnSignIn = new Guna.UI2.WinForms.Guna2Button();
            txtPasswordSignin = new Guna.UI2.WinForms.Guna2TextBox();
            txtUsername = new Guna.UI2.WinForms.Guna2TextBox();
            lblTilteSignin = new Label();
            panelSignUp = new Panel();
            lblDevelop2 = new Label();
            lblDeveloped = new Label();
            btnSignUp = new Guna.UI2.WinForms.Guna2Button();
            lblsubtitle2 = new Label();
            pcLogoKCV = new PictureBox();
            lblSubTitle = new Label();
            lblTiltleSignUp = new Label();
            epSignUp = new Guna.UI2.WinForms.Guna2Elipse(components);
            epLogin = new Guna.UI2.WinForms.Guna2Elipse(components);
            panelSignIn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pcLogoAvatar).BeginInit();
            panelSignUp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pcLogoKCV).BeginInit();
            SuspendLayout();
            // 
            // panelSignIn
            // 
            panelSignIn.BackColor = Color.Linen;
            panelSignIn.BackgroundImageLayout = ImageLayout.None;
            panelSignIn.Controls.Add(cbshowpasswordSignin);
            panelSignIn.Controls.Add(linklblEmailContact);
            panelSignIn.Controls.Add(lblsupporttitle3);
            panelSignIn.Controls.Add(lblsupporttitle2);
            panelSignIn.Controls.Add(lblsupporttitle1);
            panelSignIn.Controls.Add(btnCloseLogin);
            panelSignIn.Controls.Add(pcLogoAvatar);
            panelSignIn.Controls.Add(linklblForgotAccount);
            panelSignIn.Controls.Add(btnSignIn);
            panelSignIn.Controls.Add(txtPasswordSignin);
            panelSignIn.Controls.Add(txtUsername);
            panelSignIn.Controls.Add(lblTilteSignin);
            panelSignIn.Dock = DockStyle.Right;
            panelSignIn.Location = new Point(411, 0);
            panelSignIn.Name = "panelSignIn";
            panelSignIn.Size = new Size(439, 530);
            panelSignIn.TabIndex = 0;
            // 
            // cbshowpasswordSignin
            // 
            cbshowpasswordSignin.AutoSize = true;
            cbshowpasswordSignin.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            cbshowpasswordSignin.Location = new Point(112, 267);
            cbshowpasswordSignin.Name = "cbshowpasswordSignin";
            cbshowpasswordSignin.Size = new Size(131, 21);
            cbshowpasswordSignin.TabIndex = 3;
            cbshowpasswordSignin.Text = "Show password";
            cbshowpasswordSignin.UseVisualStyleBackColor = true;
            cbshowpasswordSignin.CheckedChanged += cbshowpasswordSignin_CheckedChanged;
            cbshowpasswordSignin.CheckStateChanged += cbshowpasswordSignin_CheckStateChanged;
            cbshowpasswordSignin.Click += cbshowpasswordSignin_Click;
            // 
            // linklblEmailContact
            // 
            linklblEmailContact.AutoSize = true;
            linklblEmailContact.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            linklblEmailContact.LinkColor = Color.DarkSlateGray;
            linklblEmailContact.Location = new Point(224, 492);
            linklblEmailContact.Name = "linklblEmailContact";
            linklblEmailContact.Size = new Size(189, 17);
            linklblEmailContact.TabIndex = 17;
            linklblEmailContact.TabStop = true;
            linklblEmailContact.Text = "toankhoa86443@gmail.com";
            // 
            // lblsupporttitle3
            // 
            lblsupporttitle3.AutoSize = true;
            lblsupporttitle3.Font = new Font("Century Gothic", 7.8F, FontStyle.Italic, GraphicsUnit.Point);
            lblsupporttitle3.ForeColor = Color.DarkSlateGray;
            lblsupporttitle3.Location = new Point(19, 492);
            lblsupporttitle3.Name = "lblsupporttitle3";
            lblsupporttitle3.Size = new Size(199, 16);
            lblsupporttitle3.TabIndex = 16;
            lblsupporttitle3.Text = "Send an email message to us:";
            // 
            // lblsupporttitle2
            // 
            lblsupporttitle2.AutoSize = true;
            lblsupporttitle2.Font = new Font("Century Gothic", 7.8F, FontStyle.Italic, GraphicsUnit.Point);
            lblsupporttitle2.ForeColor = Color.DarkSlateGray;
            lblsupporttitle2.Location = new Point(19, 472);
            lblsupporttitle2.Name = "lblsupporttitle2";
            lblsupporttitle2.Size = new Size(378, 16);
            lblsupporttitle2.TabIndex = 15;
            lblsupporttitle2.Text = "To obtain access this app or any question about this app ";
            // 
            // lblsupporttitle1
            // 
            lblsupporttitle1.AutoSize = true;
            lblsupporttitle1.Font = new Font("Century Gothic", 7.8F, FontStyle.Italic, GraphicsUnit.Point);
            lblsupporttitle1.ForeColor = Color.DarkSlateGray;
            lblsupporttitle1.Location = new Point(19, 452);
            lblsupporttitle1.Name = "lblsupporttitle1";
            lblsupporttitle1.Size = new Size(57, 16);
            lblsupporttitle1.TabIndex = 14;
            lblsupporttitle1.Text = "Support";
            // 
            // btnCloseLogin
            // 
            btnCloseLogin.FlatAppearance.BorderSize = 0;
            btnCloseLogin.FlatStyle = FlatStyle.Flat;
            btnCloseLogin.Image = Properties.Resources.icons8_logout_100__1_;
            btnCloseLogin.Location = new Point(391, 9);
            btnCloseLogin.Name = "btnCloseLogin";
            btnCloseLogin.Size = new Size(44, 38);
            btnCloseLogin.TabIndex = 2;
            btnCloseLogin.UseVisualStyleBackColor = true;
            btnCloseLogin.Click += btnCloseLogin_Click;
            // 
            // pcLogoAvatar
            // 
            pcLogoAvatar.Image = Properties.Resources.human1;
            pcLogoAvatar.Location = new Point(19, 35);
            pcLogoAvatar.Name = "pcLogoAvatar";
            pcLogoAvatar.Size = new Size(105, 97);
            pcLogoAvatar.SizeMode = PictureBoxSizeMode.StretchImage;
            pcLogoAvatar.TabIndex = 5;
            pcLogoAvatar.TabStop = false;
            // 
            // linklblForgotAccount
            // 
            linklblForgotAccount.AutoSize = true;
            linklblForgotAccount.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            linklblForgotAccount.LinkColor = Color.DarkSlateGray;
            linklblForgotAccount.Location = new Point(272, 268);
            linklblForgotAccount.Name = "linklblForgotAccount";
            linklblForgotAccount.Size = new Size(155, 17);
            linklblForgotAccount.TabIndex = 4;
            linklblForgotAccount.TabStop = true;
            linklblForgotAccount.Text = "Forgot your password?";
            linklblForgotAccount.LinkClicked += linklblForgotAccount_LinkClicked;
            // 
            // btnSignIn
            // 
            btnSignIn.BorderColor = Color.Transparent;
            btnSignIn.BorderRadius = 20;
            btnSignIn.CustomizableEdges = customizableEdges9;
            btnSignIn.DisabledState.BorderColor = Color.DarkGray;
            btnSignIn.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSignIn.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSignIn.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSignIn.FillColor = Color.DarkSlateGray;
            btnSignIn.Font = new Font("Century Gothic", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            btnSignIn.ForeColor = Color.White;
            btnSignIn.Location = new Point(172, 312);
            btnSignIn.Name = "btnSignIn";
            btnSignIn.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnSignIn.Size = new Size(133, 50);
            btnSignIn.TabIndex = 5;
            btnSignIn.Text = "Submit";
            btnSignIn.Click += btnSignIn_Click;
            // 
            // txtPasswordSignin
            // 
            txtPasswordSignin.BorderRadius = 20;
            txtPasswordSignin.CustomizableEdges = customizableEdges11;
            txtPasswordSignin.DefaultText = "Password";
            txtPasswordSignin.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPasswordSignin.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPasswordSignin.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPasswordSignin.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPasswordSignin.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPasswordSignin.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtPasswordSignin.ForeColor = Color.DarkSlateGray;
            txtPasswordSignin.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPasswordSignin.Location = new Point(112, 216);
            txtPasswordSignin.Name = "txtPasswordSignin";
            txtPasswordSignin.PasswordChar = '●';
            txtPasswordSignin.PlaceholderText = "";
            txtPasswordSignin.SelectedText = "";
            txtPasswordSignin.ShadowDecoration.CustomizableEdges = customizableEdges12;
            txtPasswordSignin.Size = new Size(250, 45);
            txtPasswordSignin.TabIndex = 2;
            txtPasswordSignin.TextChanged += txtPasswordSignin_TextChanged;
            // 
            // txtUsername
            // 
            txtUsername.BorderRadius = 20;
            txtUsername.CustomizableEdges = customizableEdges13;
            txtUsername.DefaultText = "Username";
            txtUsername.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtUsername.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtUsername.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtUsername.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtUsername.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtUsername.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtUsername.ForeColor = Color.DarkSlateGray;
            txtUsername.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtUsername.Location = new Point(112, 147);
            txtUsername.Name = "txtUsername";
            txtUsername.PasswordChar = '\0';
            txtUsername.PlaceholderText = "";
            txtUsername.SelectedText = "";
            txtUsername.ShadowDecoration.CustomizableEdges = customizableEdges14;
            txtUsername.Size = new Size(250, 45);
            txtUsername.TabIndex = 1;
            txtUsername.TextChanged += txtUsername_TextChanged;
            // 
            // lblTilteSignin
            // 
            lblTilteSignin.AutoSize = true;
            lblTilteSignin.Font = new Font("Microsoft Sans Serif", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblTilteSignin.ForeColor = Color.DarkSlateGray;
            lblTilteSignin.Location = new Point(172, 100);
            lblTilteSignin.Name = "lblTilteSignin";
            lblTilteSignin.Size = new Size(102, 32);
            lblTilteSignin.TabIndex = 0;
            lblTilteSignin.Text = "Sign In";
            // 
            // panelSignUp
            // 
            panelSignUp.BackColor = Color.CadetBlue;
            panelSignUp.Controls.Add(lblDevelop2);
            panelSignUp.Controls.Add(lblDeveloped);
            panelSignUp.Controls.Add(btnSignUp);
            panelSignUp.Controls.Add(lblsubtitle2);
            panelSignUp.Controls.Add(pcLogoKCV);
            panelSignUp.Controls.Add(lblSubTitle);
            panelSignUp.Controls.Add(lblTiltleSignUp);
            panelSignUp.Dock = DockStyle.Fill;
            panelSignUp.Location = new Point(0, 0);
            panelSignUp.Name = "panelSignUp";
            panelSignUp.Size = new Size(411, 530);
            panelSignUp.TabIndex = 1;
            // 
            // lblDevelop2
            // 
            lblDevelop2.AutoSize = true;
            lblDevelop2.Font = new Font("Century Gothic", 7.8F, FontStyle.Italic, GraphicsUnit.Point);
            lblDevelop2.ForeColor = Color.White;
            lblDevelop2.Location = new Point(12, 492);
            lblDevelop2.Name = "lblDevelop2";
            lblDevelop2.Size = new Size(119, 16);
            lblDevelop2.TabIndex = 12;
            lblDevelop2.Text = "KCV Coder team";
            // 
            // lblDeveloped
            // 
            lblDeveloped.AutoSize = true;
            lblDeveloped.Font = new Font("Century Gothic", 7.8F, FontStyle.Italic, GraphicsUnit.Point);
            lblDeveloped.ForeColor = Color.White;
            lblDeveloped.Location = new Point(12, 472);
            lblDeveloped.Name = "lblDeveloped";
            lblDeveloped.Size = new Size(97, 16);
            lblDeveloped.TabIndex = 11;
            lblDeveloped.Text = "Developed by";
            // 
            // btnSignUp
            // 
            btnSignUp.BackColor = Color.Transparent;
            btnSignUp.BorderColor = Color.White;
            btnSignUp.BorderRadius = 20;
            btnSignUp.BorderThickness = 2;
            btnSignUp.CustomizableEdges = customizableEdges15;
            btnSignUp.DisabledState.BorderColor = Color.DarkGray;
            btnSignUp.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSignUp.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSignUp.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSignUp.FillColor = Color.DarkSlateGray;
            btnSignUp.FocusedColor = Color.Transparent;
            btnSignUp.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnSignUp.ForeColor = Color.White;
            btnSignUp.Location = new Point(135, 373);
            btnSignUp.Name = "btnSignUp";
            btnSignUp.ShadowDecoration.CustomizableEdges = customizableEdges16;
            btnSignUp.Size = new Size(133, 50);
            btnSignUp.TabIndex = 6;
            btnSignUp.Text = "Sign Up";
            btnSignUp.Click += btnSignUp_Click;
            // 
            // lblsubtitle2
            // 
            lblsubtitle2.AutoSize = true;
            lblsubtitle2.Font = new Font("Microsoft Sans Serif", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblsubtitle2.ForeColor = Color.White;
            lblsubtitle2.Location = new Point(28, 15);
            lblsubtitle2.Name = "lblsubtitle2";
            lblsubtitle2.Size = new Size(340, 32);
            lblsubtitle2.TabIndex = 8;
            lblsubtitle2.Text = "WELCOM KVC TOURISM";
            // 
            // pcLogoKCV
            // 
            pcLogoKCV.Image = Properties.Resources._74ef005a4cd571ef2f8971791b6bfc98;
            pcLogoKCV.Location = new Point(102, 80);
            pcLogoKCV.Name = "pcLogoKCV";
            pcLogoKCV.Size = new Size(196, 181);
            pcLogoKCV.SizeMode = PictureBoxSizeMode.StretchImage;
            pcLogoKCV.TabIndex = 6;
            pcLogoKCV.TabStop = false;
            // 
            // lblSubTitle
            // 
            lblSubTitle.AutoSize = true;
            lblSubTitle.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblSubTitle.ForeColor = Color.White;
            lblSubTitle.Location = new Point(67, 47);
            lblSubTitle.Name = "lblSubTitle";
            lblSubTitle.Size = new Size(250, 21);
            lblSubTitle.TabIndex = 7;
            lblSubTitle.Text = "KCV in the middle of cetizen ";
            // 
            // lblTiltleSignUp
            // 
            lblTiltleSignUp.AutoSize = true;
            lblTiltleSignUp.Font = new Font("Microsoft Sans Serif", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblTiltleSignUp.ForeColor = Color.LightYellow;
            lblTiltleSignUp.Location = new Point(130, 333);
            lblTiltleSignUp.Name = "lblTiltleSignUp";
            lblTiltleSignUp.Size = new Size(141, 29);
            lblTiltleSignUp.TabIndex = 6;
            lblTiltleSignUp.Text = "NEW HERE";
            // 
            // epSignUp
            // 
            epSignUp.BorderRadius = 120;
            epSignUp.TargetControl = pcLogoKCV;
            // 
            // epLogin
            // 
            epLogin.BorderRadius = 50;
            epLogin.TargetControl = this;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(850, 530);
            ControlBox = false;
            Controls.Add(panelSignUp);
            Controls.Add(panelSignIn);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Login";
            panelSignIn.ResumeLayout(false);
            panelSignIn.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pcLogoAvatar).EndInit();
            panelSignUp.ResumeLayout(false);
            panelSignUp.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pcLogoKCV).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelSignIn;
        private Guna.UI2.WinForms.Guna2TextBox txtPasswordSignin;
        private Guna.UI2.WinForms.Guna2TextBox txtUsername;
        private Label lblTilteSignin;
        private PictureBox pcLogoAvatar;
        private LinkLabel linklblForgotAccount;
        private Guna.UI2.WinForms.Guna2Button btnSignIn;
        private Panel panelSignUp;
        private Label lblSubTitle;
        private Label lblTiltleSignUp;
        private Label lblsubtitle2;
        private PictureBox pcLogoKCV;
        private Guna.UI2.WinForms.Guna2Elipse epSignUp;
        private Guna.UI2.WinForms.Guna2Button btnSignUp;
        private Label lblDevelop2;
        private Label lblDeveloped;
        private Button btnCloseLogin;
        private Label lblsupporttitle1;
        private LinkLabel linklblEmailContact;
        private Label lblsupporttitle3;
        private Label lblsupporttitle2;
        private Guna.UI2.WinForms.Guna2Elipse epLogin;
        private CheckBox cbshowpasswordSignin;
    }
}
