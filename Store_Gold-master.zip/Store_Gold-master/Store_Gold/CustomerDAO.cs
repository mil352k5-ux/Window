﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store_Gold
{
    public class CustomerDAO : PersonDAO
    {
              DBConnection db = new DBConnection();
        
        public CustomerDAO() : base() 
        {
            this.tableName = "CustomerInfo";
        }
        public CustomerDAO(Customer customer) : base(customer)
        {
            this.tableName = "CustomerInfo";
        }
        public override DataTable Load()
        {
            return base.Load();
        }
        
        public override void Add()
        {
            base.Add();
        }
        public override void Delete()
        {
            base.Delete();
        }
        public override void Update()
        {
            base.Update();
        }
        public DataTable GetTopCustomers()
        {
            string procedureName = "GetTopCustomers";
            SqlParameter[] parameters = new SqlParameter[0]; 
            DataTable dt = db.ExecuteProcedureWithResult(procedureName, parameters);
            return dt;
        }
    }
}
