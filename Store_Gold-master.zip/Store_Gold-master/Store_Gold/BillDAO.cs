﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store_Gold
{
    internal class BillDAO
    {
        DBConnection db = new DBConnection();
        public DataTable Load()
        {
            string SQL = string.Format("SELECT * FROM Bill ");
            DataTable dt = db.Load(SQL);
            return dt;
        }
        public void Add(string billID, string productID, string customerID, string staffID, decimal totalcost,int quantity, DateTime datebuy)
        {
            string procedureName = "AddBill5";
            SqlParameter[] parameters = new SqlParameter[7];
            parameters[0] = new SqlParameter("@Bill_ID", billID);
            parameters[1] = new SqlParameter("@Product_ID", productID);
            parameters[2] = new SqlParameter("@Customer_ID", customerID);
            parameters[3] = new SqlParameter("@Staff_ID", staffID);
            parameters[4] = new SqlParameter("@Total_cost", totalcost);
            parameters[5] = new SqlParameter("@Date_buy",datebuy);
            parameters[6] = new SqlParameter("@Quantity_product", quantity);

            db.ExecuteProcedure(procedureName, parameters);
        }
        public Bill GetBillByID(string billID)
        {
            string procedureName = "GetBillByID";
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@Bill_ID", billID);

            DataTable dt = db.ExecuteProcedureWithResult(procedureName, parameters);

            // Kiểm tra xem có kết quả trả về hay không
            if (dt.Rows.Count > 0)
            {
                DataRow row = dt.Rows[0];
                Bill bill = new Bill
                {
                    Billid = row["Bill_ID"].ToString(),
                    Productid = row["Product_ID"].ToString(),
                    Customerid = row["Customer_ID"].ToString(),
                    Staffid = row["Staff_ID"].ToString(),
                    Datebuy = Convert.ToDateTime(row["Date_buy"])
                    // Các trường khác nếu cần
                };

                return bill;
            }
            else
            {
                // Trả về null nếu không tìm thấy hóa đơn với ID cung cấp
                return null;
            }
        }



    }
}
