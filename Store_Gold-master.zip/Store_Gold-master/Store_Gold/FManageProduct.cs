﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Store_Gold
{
    public partial class FManageProduct : Form
    {
        public FManageProduct()
        {
            InitializeComponent();

        }

        private void dgvManageProduct_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void FManageProduct_Load(object sender, EventArgs e)
        {
            ProductDAO productDao = new ProductDAO();
            dgvManageProduct.DataSource = productDao.Load();
            dgvManageProduct.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            btnSearch.Click += btnSearch_Click;
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            string productID = txtIDProduct.Text;
            string productName = txtNameProduct.Text;
            string categoryID = txtCagoryID.Text;
            DateTime dateIn = dtpDayIn.Value;
            int quantity = int.Parse(txtQuantity.Text);
            decimal mass = decimal.Parse(txtMass.Text);
            // Khởi tạo đối tượng ProductDAO và gọi phương thức Add
            ProductDAO productDao = new ProductDAO();
            productDao.Add(productID, productName, categoryID, dateIn, quantity, mass);
            // Sau khi thêm thành công, reload dữ liệu lên DataGridView
            dgvManageProduct.DataSource = productDao.Load();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string productID = txtIDProduct.Text;
            ProductDAO productDao = new ProductDAO();
            productDao.Delete(productID);
            dgvManageProduct.DataSource = productDao.Load();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            Show_result_search();
        }
        public void Show_result_search()
        {
            string searchType = comboSearch.Text;
            string searchText = txtSearch.Text;

            // Khởi tạo đối tượng ProductDAO và gọi phương thức Search
            ProductDAO productDao = new ProductDAO();
            DataTable searchResult = productDao.SearchProduct(searchType, searchText);
            // Hiển thị kết quả tìm kiếm trên DataGridView
            dgvManageProduct.DataSource = searchResult;
            dgvManageProduct.Refresh();
        }

        private void comboFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataTable dataTable = new DataTable();
            if (comboFilter.SelectedIndex == 1)
            {
                using (SqlConnection connection = DBConnection.GetSqlConnection())
                {
                    using (SqlCommand command = new SqlCommand("Top5BestSellingProducts", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        adapter.Fill(dataTable);
                    }
                }
            }
            else if (comboFilter.SelectedIndex == 2)   // nh? s?a procedure 
            {


                using (SqlConnection connection = DBConnection.GetSqlConnection())
                {
                    using (SqlCommand command = new SqlCommand("GetCustomerWithMaxTotalBooking2", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        adapter.Fill(dataTable);
                    }
                }
            }
            else if (comboFilter.SelectedIndex == 3) // nh? s?a procedure 
            {
                using (SqlConnection connection = DBConnection.GetSqlConnection())
                {
                    using (SqlCommand command = new SqlCommand("GetCustomerWithMaxTotalBooking2", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        adapter.Fill(dataTable);
                    }
                }
            }
            dgvManageProduct.DataSource = dataTable;
        }
    }
}
