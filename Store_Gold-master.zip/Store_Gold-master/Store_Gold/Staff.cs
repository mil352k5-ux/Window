﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store_Gold
{
    public class Staff:Person
    {
        public Staff(string Name, string CMND, string Address, string Email, string PhoneNumber, DateTime Birthday) :base(Name, CMND, Address, Email, PhoneNumber, Birthday)
        { }
        public Staff()
        { }
        public bool HasPermission(string permission)
        {
    
            if (permission == "delete_product")
            {
                // Trả về true nếu nhân viên có quyền hạn, ngược lại trả về false
                return false; // hoặc false
            }
            else
            {
                // Nếu quyền hạn không được xác định, có thể trả về false hoặc thực hiện xử lý phù hợp khác
                return true;
            }
        }
    }
}
