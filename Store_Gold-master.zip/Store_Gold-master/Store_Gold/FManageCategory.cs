﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Store_Gold
{
    public partial class FManageCategory : Form
    {
        public FManageCategory()
        {
            InitializeComponent();

        }

        //Function tính tổng sản phẩm cho từng category
        private DataTable GetTotalProductQuantityByCategory()
        {
            string connectionString = DBConnection.stringconnection;
            DataTable dataTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand("SELECT * FROM dbo.GetTotalProductQuantityByCategory()", connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(dataTable);
            }
            return dataTable;
        }

        private void dgvCategoryList_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvCategoryList.Rows[e.RowIndex];
                txtCategoryID.Text = row.Cells["Category_id"].Value.ToString();
                txtNameCategory.Text = row.Cells["Category_name"].Value.ToString();
                txtCategoryQuantity.Text = row.Cells["Quantity"].Value.ToString();
                txtCategoryPrice.Text = row.Cells["Category_price"].Value.ToString();
            }
        }

        private void FManageCategory_Load(object sender, EventArgs e)
        {
            dgvCategoryList.DataSource = GetTotalProductQuantityByCategory();
        }
    }

}
