﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TheArtOfDevHtmlRenderer.Adapters;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using System.Drawing.Printing;
using PdfSharp.UniversalAccessibility.Drawing;
using System.Drawing.Imaging;



namespace Store_Gold
{
    public partial class FPrintBill : Form
    {
        public static Bill currentBill = new Bill();
        BillDAO billDAO = new BillDAO();
        public FPrintBill()
        {
            InitializeComponent();

        }

        private void FPrintBill_Load(object sender, EventArgs e)
        {
            Bill bill = billDAO.GetBillByID(FBill.currentBill.Billid);
            lblDateorder.Text = bill.Datebuy.ToString("dd/MM/yyyy");
            lblBillID.Text = bill.Billid;
            lblTotal.Text = FListProduct.selectedProduct.price.ToString();
            lblStaffID.Text = Form1.currentStaff.CMND;
            lblStaffName.Text = Form1.currentStaff.FullName;
            lblCustomerID.Text = FDetailCustomerInformation.currentcustomer.CMND;
            lblCustomerName.Text = FDetailCustomerInformation.currentcustomer.FullName;
            ProductDAO productDao = new ProductDAO();
            dgvproductsorder.DataSource = productDao.GetSelectedProducts();
            dgvproductsorder.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }
        private void PrintToPdf(Form form)
        {
            Bitmap bitmap = new Bitmap(form.Width, form.Height);

            // Chụp hình ảnh của form và vẽ lên Bitmap
            form.DrawToBitmap(bitmap, new Rectangle(0, 0, form.Width, form.Height));

            // Lưu hình ảnh vào file PDF
            using (PdfDocument pdfDoc = new PdfDocument())
            {
                PdfPage page = pdfDoc.AddPage();
                XGraphics gfx = XGraphics.FromPdfPage(page);

                // Chuyển đổi đối tượng Bitmap thành XImage
                XImage image = GetXImageFromBitmap(bitmap);

                // Vẽ hình ảnh lên trang PDF
                gfx.DrawImage(image, 0, 0);

                string directoryPath = @"C:\Users\ToanKhoa\Downloads";
                string fileName = Path.Combine(directoryPath, "Bill.pdf");

                pdfDoc.Save(fileName);

                MessageBox.Show("Form convert successful to file PDF.", "Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            // Giải phóng đối tượng Bitmap
            bitmap.Dispose();
        }
        private XImage GetXImageFromBitmap(Bitmap bitmap)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                bitmap.Save(ms, ImageFormat.Png);
                ms.Seek(0, SeekOrigin.Begin);
                return XImage.FromStream(ms);
            }
        }

        private void btnPrintBill_Click(object sender, EventArgs e)
        {
            PrintToPdf(this);
        }

        private void btnclosebill_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
