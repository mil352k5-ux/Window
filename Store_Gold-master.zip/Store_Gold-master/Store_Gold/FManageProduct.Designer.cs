﻿namespace Store_Gold
{
    partial class FManageProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges29 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges30 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges31 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges32 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            dgvManageProduct = new DataGridView();
            label5 = new Label();
            lblDateIn = new Label();
            dtpDayIn = new Guna.UI2.WinForms.Guna2DateTimePicker();
            lblCategory = new Label();
            panelInformation = new Panel();
            btnUpdate = new Guna.UI2.WinForms.Guna2Button();
            btnAdd = new Guna.UI2.WinForms.Guna2Button();
            btnDelete = new Guna.UI2.WinForms.Guna2Button();
            comboSearch = new Guna.UI2.WinForms.Guna2ComboBox();
            btnSearch = new Guna.UI2.WinForms.Guna2Button();
            txtSearch = new Guna.UI2.WinForms.Guna2TextBox();
            lblFilter = new Label();
            comboFilter = new Guna.UI2.WinForms.Guna2ComboBox();
            panel1 = new Panel();
            dtpDayOut = new Guna.UI2.WinForms.Guna2DateTimePicker();
            lblCagoryID = new Label();
            txtCagoryID = new Guna.UI2.WinForms.Guna2TextBox();
            lblDayOut = new Label();
            label1 = new Label();
            txtQuantity = new Guna.UI2.WinForms.Guna2TextBox();
            txtPrice = new Guna.UI2.WinForms.Guna2TextBox();
            txtMass = new Guna.UI2.WinForms.Guna2TextBox();
            lblPhone = new Label();
            lblMass = new Label();
            txtIDProduct = new Guna.UI2.WinForms.Guna2TextBox();
            lblD = new Label();
            txtNameProduct = new Guna.UI2.WinForms.Guna2TextBox();
            lblProductName = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvManageProduct).BeginInit();
            panelInformation.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // dgvManageProduct
            // 
            dgvManageProduct.BackgroundColor = SystemColors.ButtonHighlight;
            dgvManageProduct.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvManageProduct.Dock = DockStyle.Fill;
            dgvManageProduct.Location = new Point(485, 0);
            dgvManageProduct.Name = "dgvManageProduct";
            dgvManageProduct.RowHeadersWidth = 51;
            dgvManageProduct.Size = new Size(697, 553);
            dgvManageProduct.TabIndex = 3;
            dgvManageProduct.CellContentClick += dgvManageProduct_CellContentClick;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(45, 389);
            label5.Name = "label5";
            label5.Size = new Size(0, 20);
            label5.TabIndex = 12;
            // 
            // lblDateIn
            // 
            lblDateIn.AutoSize = true;
            lblDateIn.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblDateIn.ForeColor = Color.SteelBlue;
            lblDateIn.Location = new Point(23, 250);
            lblDateIn.Name = "lblDateIn";
            lblDateIn.Size = new Size(76, 20);
            lblDateIn.TabIndex = 30;
            lblDateIn.Text = "Day In:";
            // 
            // dtpDayIn
            // 
            dtpDayIn.BorderRadius = 20;
            dtpDayIn.Checked = true;
            dtpDayIn.CustomizableEdges = customizableEdges1;
            dtpDayIn.FillColor = Color.FromArgb(192, 192, 255);
            dtpDayIn.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dtpDayIn.Format = DateTimePickerFormat.Long;
            dtpDayIn.Location = new Point(10, 272);
            dtpDayIn.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dtpDayIn.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dtpDayIn.Name = "dtpDayIn";
            dtpDayIn.ShadowDecoration.CustomizableEdges = customizableEdges2;
            dtpDayIn.Size = new Size(220, 46);
            dtpDayIn.TabIndex = 29;
            dtpDayIn.Value = new DateTime(2024, 4, 16, 17, 49, 34, 508);
            // 
            // lblCategory
            // 
            lblCategory.AutoSize = true;
            lblCategory.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblCategory.ForeColor = Color.SteelBlue;
            lblCategory.Location = new Point(274, 170);
            lblCategory.Name = "lblCategory";
            lblCategory.Size = new Size(95, 20);
            lblCategory.TabIndex = 27;
            lblCategory.Text = "Category:";
            // 
            // panelInformation
            // 
            panelInformation.BackColor = Color.AliceBlue;
            panelInformation.Controls.Add(btnUpdate);
            panelInformation.Controls.Add(btnAdd);
            panelInformation.Controls.Add(btnDelete);
            panelInformation.Controls.Add(comboSearch);
            panelInformation.Controls.Add(btnSearch);
            panelInformation.Controls.Add(txtSearch);
            panelInformation.Controls.Add(lblFilter);
            panelInformation.Controls.Add(comboFilter);
            panelInformation.Controls.Add(panel1);
            panelInformation.Controls.Add(label5);
            panelInformation.Dock = DockStyle.Left;
            panelInformation.Location = new Point(0, 0);
            panelInformation.Name = "panelInformation";
            panelInformation.Size = new Size(485, 553);
            panelInformation.TabIndex = 2;
            // 
            // btnUpdate
            // 
            btnUpdate.BorderRadius = 10;
            btnUpdate.CustomizableEdges = customizableEdges3;
            btnUpdate.DisabledState.BorderColor = Color.DarkGray;
            btnUpdate.DisabledState.CustomBorderColor = Color.DarkGray;
            btnUpdate.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnUpdate.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnUpdate.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnUpdate.ForeColor = Color.White;
            btnUpdate.Location = new Point(326, 485);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btnUpdate.Size = new Size(118, 56);
            btnUpdate.TabIndex = 32;
            btnUpdate.Text = "UPDATE";
            // 
            // btnAdd
            // 
            btnAdd.BorderRadius = 10;
            btnAdd.CustomizableEdges = customizableEdges5;
            btnAdd.DisabledState.BorderColor = Color.DarkGray;
            btnAdd.DisabledState.CustomBorderColor = Color.DarkGray;
            btnAdd.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnAdd.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnAdd.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnAdd.ForeColor = Color.White;
            btnAdd.Location = new Point(181, 485);
            btnAdd.Name = "btnAdd";
            btnAdd.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btnAdd.Size = new Size(110, 56);
            btnAdd.TabIndex = 31;
            btnAdd.Text = "ADD";
            btnAdd.Click += btnAdd_Click;
            // 
            // btnDelete
            // 
            btnDelete.BorderRadius = 10;
            btnDelete.CustomizableEdges = customizableEdges7;
            btnDelete.DisabledState.BorderColor = Color.DarkGray;
            btnDelete.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDelete.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDelete.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDelete.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnDelete.ForeColor = Color.White;
            btnDelete.Location = new Point(45, 485);
            btnDelete.Name = "btnDelete";
            btnDelete.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnDelete.Size = new Size(107, 56);
            btnDelete.TabIndex = 30;
            btnDelete.Text = "DELETE";
            btnDelete.Click += btnDelete_Click;
            // 
            // comboSearch
            // 
            comboSearch.BackColor = Color.Transparent;
            comboSearch.BorderColor = Color.FromArgb(64, 64, 64);
            comboSearch.BorderRadius = 20;
            comboSearch.CustomizableEdges = customizableEdges9;
            comboSearch.DrawMode = DrawMode.OwnerDrawFixed;
            comboSearch.DropDownStyle = ComboBoxStyle.DropDownList;
            comboSearch.FocusedColor = Color.FromArgb(94, 148, 255);
            comboSearch.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            comboSearch.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            comboSearch.ForeColor = Color.FromArgb(68, 88, 112);
            comboSearch.ItemHeight = 40;
            comboSearch.Items.AddRange(new object[] { "Product_Name", "Product_ID", "DayBuying", "Category_ID", "None" });
            comboSearch.Location = new Point(23, 341);
            comboSearch.Name = "comboSearch";
            comboSearch.ShadowDecoration.CustomizableEdges = customizableEdges10;
            comboSearch.Size = new Size(101, 46);
            comboSearch.TabIndex = 29;
            comboSearch.TextAlign = HorizontalAlignment.Center;
            // 
            // btnSearch
            // 
            btnSearch.BackColor = Color.Transparent;
            btnSearch.BackgroundImage = Properties.Resources.search;
            btnSearch.BackgroundImageLayout = ImageLayout.Stretch;
            btnSearch.CustomizableEdges = customizableEdges11;
            btnSearch.DisabledState.BorderColor = Color.DarkGray;
            btnSearch.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSearch.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSearch.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSearch.FillColor = Color.Transparent;
            btnSearch.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnSearch.ForeColor = Color.White;
            btnSearch.Location = new Point(433, 341);
            btnSearch.Name = "btnSearch";
            btnSearch.ShadowDecoration.CustomizableEdges = customizableEdges12;
            btnSearch.Size = new Size(39, 37);
            btnSearch.TabIndex = 24;
            btnSearch.Click += btnSearch_Click;
            // 
            // txtSearch
            // 
            txtSearch.BorderColor = Color.FromArgb(64, 64, 64);
            txtSearch.BorderRadius = 15;
            txtSearch.CustomizableEdges = customizableEdges13;
            txtSearch.DefaultText = "";
            txtSearch.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtSearch.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtSearch.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtSearch.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtSearch.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSearch.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtSearch.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSearch.Location = new Point(127, 340);
            txtSearch.Margin = new Padding(3, 4, 3, 4);
            txtSearch.Name = "txtSearch";
            txtSearch.PasswordChar = '\0';
            txtSearch.PlaceholderText = "";
            txtSearch.SelectedText = "";
            txtSearch.ShadowDecoration.CustomizableEdges = customizableEdges14;
            txtSearch.Size = new Size(300, 47);
            txtSearch.TabIndex = 23;
            // 
            // lblFilter
            // 
            lblFilter.AutoSize = true;
            lblFilter.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblFilter.ForeColor = Color.SteelBlue;
            lblFilter.Location = new Point(23, 427);
            lblFilter.Name = "lblFilter";
            lblFilter.Size = new Size(58, 20);
            lblFilter.TabIndex = 22;
            lblFilter.Text = "Filter";
            // 
            // comboFilter
            // 
            comboFilter.BackColor = Color.Transparent;
            comboFilter.BorderColor = Color.FromArgb(64, 64, 64);
            comboFilter.BorderRadius = 20;
            comboFilter.CustomizableEdges = customizableEdges15;
            comboFilter.DrawMode = DrawMode.OwnerDrawFixed;
            comboFilter.DropDownStyle = ComboBoxStyle.DropDownList;
            comboFilter.FocusedColor = Color.FromArgb(94, 148, 255);
            comboFilter.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            comboFilter.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            comboFilter.ForeColor = Color.FromArgb(68, 88, 112);
            comboFilter.ItemHeight = 40;
            comboFilter.Items.AddRange(new object[] { "Top 5 Product buying the MOST(Quatity)", "Descending (Price)", "Product còn lại trong kho", "Product đã bán ra" });
            comboFilter.Location = new Point(84, 415);
            comboFilter.Name = "comboFilter";
            comboFilter.ShadowDecoration.CustomizableEdges = customizableEdges16;
            comboFilter.Size = new Size(388, 46);
            comboFilter.TabIndex = 18;
            comboFilter.SelectedIndexChanged += comboFilter_SelectedIndexChanged;
            // 
            // panel1
            // 
            panel1.Controls.Add(dtpDayOut);
            panel1.Controls.Add(lblCagoryID);
            panel1.Controls.Add(txtCagoryID);
            panel1.Controls.Add(lblDayOut);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(txtQuantity);
            panel1.Controls.Add(dtpDayIn);
            panel1.Controls.Add(lblDateIn);
            panel1.Controls.Add(lblCategory);
            panel1.Controls.Add(txtPrice);
            panel1.Controls.Add(txtMass);
            panel1.Controls.Add(lblPhone);
            panel1.Controls.Add(lblMass);
            panel1.Controls.Add(txtIDProduct);
            panel1.Controls.Add(lblD);
            panel1.Controls.Add(txtNameProduct);
            panel1.Controls.Add(lblProductName);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(485, 333);
            panel1.TabIndex = 17;
            // 
            // dtpDayOut
            // 
            dtpDayOut.BorderRadius = 20;
            dtpDayOut.Checked = true;
            dtpDayOut.CustomizableEdges = customizableEdges17;
            dtpDayOut.FillColor = Color.FromArgb(192, 192, 255);
            dtpDayOut.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dtpDayOut.Format = DateTimePickerFormat.Long;
            dtpDayOut.Location = new Point(257, 273);
            dtpDayOut.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dtpDayOut.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dtpDayOut.Name = "dtpDayOut";
            dtpDayOut.ShadowDecoration.CustomizableEdges = customizableEdges18;
            dtpDayOut.Size = new Size(220, 46);
            dtpDayOut.TabIndex = 40;
            dtpDayOut.Value = new DateTime(2024, 4, 16, 17, 49, 34, 508);
            // 
            // lblCagoryID
            // 
            lblCagoryID.AutoSize = true;
            lblCagoryID.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblCagoryID.ForeColor = Color.SteelBlue;
            lblCagoryID.Location = new Point(326, 9);
            lblCagoryID.Name = "lblCagoryID";
            lblCagoryID.Size = new Size(95, 20);
            lblCagoryID.TabIndex = 39;
            lblCagoryID.Text = "CagoryID";
            lblCagoryID.TextAlign = ContentAlignment.TopCenter;
            // 
            // txtCagoryID
            // 
            txtCagoryID.BorderColor = Color.FromArgb(64, 64, 64);
            txtCagoryID.BorderRadius = 20;
            txtCagoryID.CustomizableEdges = customizableEdges19;
            txtCagoryID.DefaultText = "123";
            txtCagoryID.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtCagoryID.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtCagoryID.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtCagoryID.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtCagoryID.FillColor = Color.MistyRose;
            txtCagoryID.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCagoryID.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtCagoryID.ForeColor = Color.CornflowerBlue;
            txtCagoryID.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCagoryID.Location = new Point(326, 39);
            txtCagoryID.Margin = new Padding(3, 4, 3, 4);
            txtCagoryID.Name = "txtCagoryID";
            txtCagoryID.PasswordChar = '\0';
            txtCagoryID.PlaceholderText = "";
            txtCagoryID.SelectedText = "";
            txtCagoryID.ShadowDecoration.CustomizableEdges = customizableEdges20;
            txtCagoryID.Size = new Size(104, 46);
            txtCagoryID.TabIndex = 38;
            txtCagoryID.TextAlign = HorizontalAlignment.Center;
            // 
            // lblDayOut
            // 
            lblDayOut.AutoSize = true;
            lblDayOut.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblDayOut.ForeColor = Color.SteelBlue;
            lblDayOut.Location = new Point(274, 250);
            lblDayOut.Name = "lblDayOut";
            lblDayOut.Size = new Size(82, 20);
            lblDayOut.TabIndex = 37;
            lblDayOut.Text = "Day Out";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.SteelBlue;
            label1.Location = new Point(181, 9);
            label1.Name = "label1";
            label1.Size = new Size(90, 20);
            label1.TabIndex = 36;
            label1.Text = "Quantity";
            label1.TextAlign = ContentAlignment.TopCenter;
            // 
            // txtQuantity
            // 
            txtQuantity.BorderColor = Color.FromArgb(64, 64, 64);
            txtQuantity.BorderRadius = 20;
            txtQuantity.CustomizableEdges = customizableEdges23;
            txtQuantity.DefaultText = "123";
            txtQuantity.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtQuantity.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtQuantity.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtQuantity.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtQuantity.FillColor = Color.MistyRose;
            txtQuantity.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtQuantity.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtQuantity.ForeColor = Color.CornflowerBlue;
            txtQuantity.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtQuantity.Location = new Point(173, 39);
            txtQuantity.Margin = new Padding(3, 4, 3, 4);
            txtQuantity.Name = "txtQuantity";
            txtQuantity.PasswordChar = '\0';
            txtQuantity.PlaceholderText = "";
            txtQuantity.SelectedText = "";
            txtQuantity.ShadowDecoration.CustomizableEdges = customizableEdges24;
            txtQuantity.Size = new Size(104, 46);
            txtQuantity.TabIndex = 35;
            txtQuantity.TextAlign = HorizontalAlignment.Center;
            // 
            // txtPrice
            // 
            txtPrice.BorderColor = Color.FromArgb(64, 64, 64);
            txtPrice.BorderRadius = 20;
            txtPrice.CustomizableEdges = customizableEdges25;
            txtPrice.DefaultText = "50";
            txtPrice.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPrice.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPrice.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPrice.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPrice.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPrice.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtPrice.ForeColor = Color.CornflowerBlue;
            txtPrice.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPrice.Location = new Point(7, 194);
            txtPrice.Margin = new Padding(3, 4, 3, 4);
            txtPrice.Name = "txtPrice";
            txtPrice.PasswordChar = '\0';
            txtPrice.PlaceholderText = "";
            txtPrice.SelectedText = "";
            txtPrice.ShadowDecoration.CustomizableEdges = customizableEdges26;
            txtPrice.Size = new Size(219, 43);
            txtPrice.TabIndex = 26;
            txtPrice.TextAlign = HorizontalAlignment.Center;
            // 
            // txtMass
            // 
            txtMass.BorderColor = Color.FromArgb(64, 64, 64);
            txtMass.BorderRadius = 20;
            txtMass.CustomizableEdges = customizableEdges27;
            txtMass.DefaultText = "0.6";
            txtMass.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtMass.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtMass.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtMass.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtMass.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMass.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtMass.ForeColor = Color.CornflowerBlue;
            txtMass.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMass.Location = new Point(257, 113);
            txtMass.Margin = new Padding(3, 4, 3, 4);
            txtMass.Name = "txtMass";
            txtMass.PasswordChar = '\0';
            txtMass.PlaceholderText = "";
            txtMass.SelectedText = "";
            txtMass.ShadowDecoration.CustomizableEdges = customizableEdges28;
            txtMass.Size = new Size(221, 43);
            txtMass.TabIndex = 25;
            txtMass.TextAlign = HorizontalAlignment.Center;
            // 
            // lblPhone
            // 
            lblPhone.AutoSize = true;
            lblPhone.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblPhone.ForeColor = Color.SteelBlue;
            lblPhone.Location = new Point(23, 170);
            lblPhone.Name = "lblPhone";
            lblPhone.Size = new Size(88, 20);
            lblPhone.TabIndex = 22;
            lblPhone.Text = "Price($):";
            // 
            // lblMass
            // 
            lblMass.AutoSize = true;
            lblMass.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblMass.ForeColor = Color.SteelBlue;
            lblMass.Location = new Point(274, 89);
            lblMass.Name = "lblMass";
            lblMass.Size = new Size(87, 20);
            lblMass.TabIndex = 21;
            lblMass.Text = "Mass(g):";
            // 
            // txtIDProduct
            // 
            txtIDProduct.BorderColor = Color.FromArgb(64, 64, 64);
            txtIDProduct.BorderRadius = 20;
            txtIDProduct.CustomizableEdges = customizableEdges29;
            txtIDProduct.DefaultText = "012";
            txtIDProduct.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtIDProduct.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtIDProduct.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtIDProduct.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtIDProduct.FillColor = Color.MistyRose;
            txtIDProduct.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtIDProduct.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtIDProduct.ForeColor = Color.CornflowerBlue;
            txtIDProduct.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtIDProduct.Location = new Point(23, 39);
            txtIDProduct.Margin = new Padding(3, 4, 3, 4);
            txtIDProduct.Name = "txtIDProduct";
            txtIDProduct.PasswordChar = '\0';
            txtIDProduct.PlaceholderText = "";
            txtIDProduct.SelectedText = "";
            txtIDProduct.ShadowDecoration.CustomizableEdges = customizableEdges30;
            txtIDProduct.Size = new Size(103, 46);
            txtIDProduct.TabIndex = 20;
            txtIDProduct.TextAlign = HorizontalAlignment.Center;
            // 
            // lblD
            // 
            lblD.AutoSize = true;
            lblD.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblD.ForeColor = Color.SteelBlue;
            lblD.Location = new Point(58, 9);
            lblD.Name = "lblD";
            lblD.Size = new Size(32, 20);
            lblD.TabIndex = 19;
            lblD.Text = "ID";
            // 
            // txtNameProduct
            // 
            txtNameProduct.BorderColor = Color.FromArgb(64, 64, 64);
            txtNameProduct.BorderRadius = 20;
            txtNameProduct.CustomizableEdges = customizableEdges31;
            txtNameProduct.DefaultText = "Sun Ring";
            txtNameProduct.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtNameProduct.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtNameProduct.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtNameProduct.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtNameProduct.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNameProduct.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtNameProduct.ForeColor = Color.CornflowerBlue;
            txtNameProduct.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNameProduct.Location = new Point(7, 112);
            txtNameProduct.Margin = new Padding(3, 4, 3, 4);
            txtNameProduct.Name = "txtNameProduct";
            txtNameProduct.PasswordChar = '\0';
            txtNameProduct.PlaceholderText = "";
            txtNameProduct.SelectedText = "";
            txtNameProduct.ShadowDecoration.CustomizableEdges = customizableEdges32;
            txtNameProduct.Size = new Size(219, 43);
            txtNameProduct.TabIndex = 18;
            txtNameProduct.TextAlign = HorizontalAlignment.Center;
            // 
            // lblProductName
            // 
            lblProductName.AutoSize = true;
            lblProductName.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblProductName.ForeColor = Color.SteelBlue;
            lblProductName.Location = new Point(23, 89);
            lblProductName.Name = "lblProductName";
            lblProductName.Size = new Size(144, 20);
            lblProductName.TabIndex = 17;
            lblProductName.Text = "Product Name:";
            // 
            
          
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1182, 553);
            Controls.Add(dgvManageProduct);
            Controls.Add(panelInformation);
            Name = "FManageProduct";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FManageProduct";
            Load += FManageProduct_Load;
            ((System.ComponentModel.ISupportInitialize)dgvManageProduct).EndInit();
            panelInformation.ResumeLayout(false);
            panelInformation.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private DataGridView dgvManageProduct;
        private Label label5;
        private Label lblAddress;
        private Label lblDateIn;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpDayIn;
        private Label lblCategory;
        private Panel panelInformation;
        private Guna.UI2.WinForms.Guna2Button btnUpdate;
        private Guna.UI2.WinForms.Guna2Button btnAdd;
        private Guna.UI2.WinForms.Guna2Button btnDelete;
        private Guna.UI2.WinForms.Guna2ComboBox comboSearch;
        private Guna.UI2.WinForms.Guna2Button btnSearch;
        private Guna.UI2.WinForms.Guna2TextBox txtSearch;
        private Label lblFilter;
        private Guna.UI2.WinForms.Guna2ComboBox comboFilter;
        private Panel panel1;
        private Guna.UI2.WinForms.Guna2TextBox txtPrice;
        private Guna.UI2.WinForms.Guna2TextBox txtMass;
        private Label lblPhone;
        private Label lblMass;
        private Guna.UI2.WinForms.Guna2TextBox txtIDProduct;
        private Label lblD;
        private Guna.UI2.WinForms.Guna2TextBox txtNameProduct;
        private Label lblProductName;
        private Label label1;
        private Guna.UI2.WinForms.Guna2TextBox txtQuantity;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpDayOut;
        private Label lblCagoryID;
        private Guna.UI2.WinForms.Guna2TextBox txtCagoryID;
        private Label lblDayOut;
    }
}