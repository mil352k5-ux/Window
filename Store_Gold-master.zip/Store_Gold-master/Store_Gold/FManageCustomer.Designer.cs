﻿namespace Store_Gold
{
    partial class FManageCustomer
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges29 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges30 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges31 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges32 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panelInformation = new Panel();
            btnTopCustomer = new Guna.UI2.WinForms.Guna2Button();
            btnUpdate = new Guna.UI2.WinForms.Guna2Button();
            btnDelete = new Guna.UI2.WinForms.Guna2Button();
            comboSearch = new Guna.UI2.WinForms.Guna2ComboBox();
            btnSearch = new Guna.UI2.WinForms.Guna2Button();
            txtSearch = new Guna.UI2.WinForms.Guna2TextBox();
            lblFilter = new Label();
            comboFilter = new Guna.UI2.WinForms.Guna2ComboBox();
            panel1 = new Panel();
            label3 = new Label();
            dtpBirthday = new Guna.UI2.WinForms.Guna2DateTimePicker();
            lblAddress = new Label();
            txtAddress = new Guna.UI2.WinForms.Guna2TextBox();
            label2 = new Label();
            dtpDayBuying = new Guna.UI2.WinForms.Guna2DateTimePicker();
            comboSex = new Guna.UI2.WinForms.Guna2ComboBox();
            label1 = new Label();
            txtPhone = new Guna.UI2.WinForms.Guna2TextBox();
            txtEmail = new Guna.UI2.WinForms.Guna2TextBox();
            txtRank = new Guna.UI2.WinForms.Guna2TextBox();
            lblRank = new Label();
            lblPhone = new Label();
            lblEmail = new Label();
            txtIDCustomer = new Guna.UI2.WinForms.Guna2TextBox();
            lblD = new Label();
            txtFullName = new Guna.UI2.WinForms.Guna2TextBox();
            lblFullName = new Label();
            label5 = new Label();
            dgvManageCustomer = new DataGridView();
            bindingSource1 = new BindingSource(components);
            panelInformation.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvManageCustomer).BeginInit();
            ((System.ComponentModel.ISupportInitialize)bindingSource1).BeginInit();
            SuspendLayout();
            // 
            // panelInformation
            // 
            panelInformation.BackColor = Color.AliceBlue;
            panelInformation.Controls.Add(btnTopCustomer);
            panelInformation.Controls.Add(btnUpdate);
            panelInformation.Controls.Add(btnDelete);
            panelInformation.Controls.Add(comboSearch);
            panelInformation.Controls.Add(btnSearch);
            panelInformation.Controls.Add(txtSearch);
            panelInformation.Controls.Add(lblFilter);
            panelInformation.Controls.Add(comboFilter);
            panelInformation.Controls.Add(panel1);
            panelInformation.Controls.Add(label5);
            panelInformation.Dock = DockStyle.Left;
            panelInformation.Location = new Point(0, 0);
            panelInformation.Name = "panelInformation";
            panelInformation.Size = new Size(485, 553);
            panelInformation.TabIndex = 0;
            // 
            // btnTopCustomer
            // 
            btnTopCustomer.BorderRadius = 20;
            btnTopCustomer.CustomizableEdges = customizableEdges1;
            btnTopCustomer.DisabledState.BorderColor = Color.DarkGray;
            btnTopCustomer.DisabledState.CustomBorderColor = Color.DarkGray;
            btnTopCustomer.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnTopCustomer.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnTopCustomer.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnTopCustomer.ForeColor = Color.White;
            btnTopCustomer.Location = new Point(69, 485);
            btnTopCustomer.Name = "btnTopCustomer";
            btnTopCustomer.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnTopCustomer.Size = new Size(147, 56);
            btnTopCustomer.TabIndex = 33;
            btnTopCustomer.Text = "TopCustomer";
            btnTopCustomer.Click += btnTopCustomer_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.BorderRadius = 20;
            btnUpdate.CustomizableEdges = customizableEdges3;
            btnUpdate.DisabledState.BorderColor = Color.DarkGray;
            btnUpdate.DisabledState.CustomBorderColor = Color.DarkGray;
            btnUpdate.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnUpdate.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnUpdate.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnUpdate.ForeColor = Color.White;
            btnUpdate.Location = new Point(354, 485);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btnUpdate.Size = new Size(118, 56);
            btnUpdate.TabIndex = 32;
            btnUpdate.Text = "UPDATE";
            btnUpdate.Click += btnUpdate_Click_1;
            // 
            // btnDelete
            // 
            btnDelete.BorderRadius = 20;
            btnDelete.CustomizableEdges = customizableEdges5;
            btnDelete.DisabledState.BorderColor = Color.DarkGray;
            btnDelete.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDelete.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDelete.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDelete.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnDelete.ForeColor = Color.White;
            btnDelete.Location = new Point(238, 485);
            btnDelete.Name = "btnDelete";
            btnDelete.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btnDelete.Size = new Size(103, 56);
            btnDelete.TabIndex = 30;
            btnDelete.Text = "DELETE";
            btnDelete.Click += btnDelete_Click_1;
            // 
            // comboSearch
            // 
            comboSearch.BackColor = Color.Transparent;
            comboSearch.BorderColor = Color.FromArgb(64, 64, 64);
            comboSearch.BorderRadius = 20;
            comboSearch.CustomizableEdges = customizableEdges7;
            comboSearch.DrawMode = DrawMode.OwnerDrawFixed;
            comboSearch.DropDownStyle = ComboBoxStyle.DropDownList;
            comboSearch.FocusedColor = Color.FromArgb(94, 148, 255);
            comboSearch.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            comboSearch.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            comboSearch.ForeColor = Color.FromArgb(68, 88, 112);
            comboSearch.ItemHeight = 40;
            comboSearch.Items.AddRange(new object[] { "Product_Name", "Product_ID", "Date_In", "Category_ID" });
            comboSearch.Location = new Point(18, 341);
            comboSearch.Name = "comboSearch";
            comboSearch.ShadowDecoration.CustomizableEdges = customizableEdges8;
            comboSearch.Size = new Size(101, 46);
            comboSearch.TabIndex = 29;
            comboSearch.TextAlign = HorizontalAlignment.Center;
            // 
            // btnSearch
            // 
            btnSearch.BackColor = Color.Transparent;
            btnSearch.BackgroundImage = Properties.Resources.search;
            btnSearch.BackgroundImageLayout = ImageLayout.Stretch;
            btnSearch.CustomizableEdges = customizableEdges9;
            btnSearch.DisabledState.BorderColor = Color.DarkGray;
            btnSearch.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSearch.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSearch.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSearch.FillColor = Color.Transparent;
            btnSearch.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnSearch.ForeColor = Color.White;
            btnSearch.Location = new Point(433, 341);
            btnSearch.Name = "btnSearch";
            btnSearch.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnSearch.Size = new Size(39, 37);
            btnSearch.TabIndex = 24;
            // 
            // txtSearch
            // 
            txtSearch.BorderColor = Color.FromArgb(64, 64, 64);
            txtSearch.BorderRadius = 15;
            txtSearch.CustomizableEdges = customizableEdges11;
            txtSearch.DefaultText = "";
            txtSearch.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtSearch.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtSearch.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtSearch.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtSearch.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSearch.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtSearch.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSearch.Location = new Point(127, 340);
            txtSearch.Margin = new Padding(3, 4, 3, 4);
            txtSearch.Name = "txtSearch";
            txtSearch.PasswordChar = '\0';
            txtSearch.PlaceholderText = "";
            txtSearch.SelectedText = "";
            txtSearch.ShadowDecoration.CustomizableEdges = customizableEdges12;
            txtSearch.Size = new Size(300, 47);
            txtSearch.TabIndex = 23;
            // 
            // lblFilter
            // 
            lblFilter.AutoSize = true;
            lblFilter.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblFilter.ForeColor = Color.SteelBlue;
            lblFilter.Location = new Point(20, 429);
            lblFilter.Name = "lblFilter";
            lblFilter.Size = new Size(58, 20);
            lblFilter.TabIndex = 22;
            lblFilter.Text = "Filter";
            // 
            // comboFilter
            // 
            comboFilter.BackColor = Color.Transparent;
            comboFilter.BorderColor = Color.FromArgb(64, 64, 64);
            comboFilter.BorderRadius = 20;
            comboFilter.CustomizableEdges = customizableEdges13;
            comboFilter.DrawMode = DrawMode.OwnerDrawFixed;
            comboFilter.DropDownStyle = ComboBoxStyle.DropDownList;
            comboFilter.FocusedColor = Color.FromArgb(94, 148, 255);
            comboFilter.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            comboFilter.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            comboFilter.ForeColor = Color.FromArgb(68, 88, 112);
            comboFilter.ItemHeight = 40;
            comboFilter.Items.AddRange(new object[] { "Top 5 Customers buying the MOST(Quatity)", "Top 5 Customers  buying the MOST(Money)" });
            comboFilter.Location = new Point(84, 415);
            comboFilter.Name = "comboFilter";
            comboFilter.ShadowDecoration.CustomizableEdges = customizableEdges14;
            comboFilter.Size = new Size(388, 46);
            comboFilter.TabIndex = 18;
            // 
            // panel1
            // 
            panel1.Controls.Add(label3);
            panel1.Controls.Add(dtpBirthday);
            panel1.Controls.Add(lblAddress);
            panel1.Controls.Add(txtAddress);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(dtpDayBuying);
            panel1.Controls.Add(comboSex);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(txtPhone);
            panel1.Controls.Add(txtEmail);
            panel1.Controls.Add(txtRank);
            panel1.Controls.Add(lblRank);
            panel1.Controls.Add(lblPhone);
            panel1.Controls.Add(lblEmail);
            panel1.Controls.Add(txtIDCustomer);
            panel1.Controls.Add(lblD);
            panel1.Controls.Add(txtFullName);
            panel1.Controls.Add(lblFullName);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(485, 335);
            panel1.TabIndex = 17;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.SteelBlue;
            label3.Location = new Point(23, 246);
            label3.Name = "label3";
            label3.Size = new Size(96, 20);
            label3.TabIndex = 34;
            label3.Text = "Birthday:";
            // 
            // dtpBirthday
            // 
            dtpBirthday.BorderRadius = 20;
            dtpBirthday.Checked = true;
            dtpBirthday.CustomizableEdges = customizableEdges15;
            dtpBirthday.FillColor = Color.FromArgb(192, 192, 255);
            dtpBirthday.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dtpBirthday.Format = DateTimePickerFormat.Long;
            dtpBirthday.Location = new Point(7, 269);
            dtpBirthday.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dtpBirthday.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dtpBirthday.Name = "dtpBirthday";
            dtpBirthday.ShadowDecoration.CustomizableEdges = customizableEdges16;
            dtpBirthday.Size = new Size(220, 46);
            dtpBirthday.TabIndex = 33;
            dtpBirthday.Value = new DateTime(2024, 4, 16, 17, 49, 34, 508);
            // 
            // lblAddress
            // 
            lblAddress.AutoSize = true;
            lblAddress.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblAddress.ForeColor = Color.SteelBlue;
            lblAddress.Location = new Point(274, 170);
            lblAddress.Name = "lblAddress";
            lblAddress.Size = new Size(89, 20);
            lblAddress.TabIndex = 32;
            lblAddress.Text = "Address:";
            // 
            // txtAddress
            // 
            txtAddress.BorderColor = Color.FromArgb(64, 64, 64);
            txtAddress.BorderRadius = 20;
            txtAddress.CustomizableEdges = customizableEdges17;
            txtAddress.DefaultText = "HCMC";
            txtAddress.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtAddress.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtAddress.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtAddress.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtAddress.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAddress.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtAddress.ForeColor = Color.CornflowerBlue;
            txtAddress.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtAddress.Location = new Point(253, 194);
            txtAddress.Margin = new Padding(3, 4, 3, 4);
            txtAddress.Name = "txtAddress";
            txtAddress.PasswordChar = '\0';
            txtAddress.PlaceholderText = "";
            txtAddress.SelectedText = "";
            txtAddress.ShadowDecoration.CustomizableEdges = customizableEdges18;
            txtAddress.Size = new Size(225, 43);
            txtAddress.TabIndex = 31;
            txtAddress.TextAlign = HorizontalAlignment.Center;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.SteelBlue;
            label2.Location = new Point(162, 34);
            label2.Name = "label2";
            label2.Size = new Size(90, 20);
            label2.TabIndex = 30;
            label2.Text = "Day Buy:";
            // 
            // dtpDayBuying
            // 
            dtpDayBuying.BorderRadius = 20;
            dtpDayBuying.Checked = true;
            dtpDayBuying.CustomizableEdges = customizableEdges19;
            dtpDayBuying.FillColor = Color.FromArgb(192, 192, 255);
            dtpDayBuying.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dtpDayBuying.Format = DateTimePickerFormat.Long;
            dtpDayBuying.Location = new Point(258, 22);
            dtpDayBuying.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dtpDayBuying.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dtpDayBuying.Name = "dtpDayBuying";
            dtpDayBuying.ShadowDecoration.CustomizableEdges = customizableEdges20;
            dtpDayBuying.Size = new Size(220, 46);
            dtpDayBuying.TabIndex = 29;
            dtpDayBuying.Value = new DateTime(2024, 4, 16, 17, 49, 34, 508);
            // 
            // comboSex
            // 
            comboSex.BackColor = Color.Transparent;
            comboSex.BorderColor = Color.FromArgb(64, 64, 64);
            comboSex.BorderRadius = 20;
            comboSex.CustomizableEdges = customizableEdges21;
            comboSex.DrawMode = DrawMode.OwnerDrawFixed;
            comboSex.DropDownStyle = ComboBoxStyle.DropDownList;
            comboSex.FocusedColor = Color.FromArgb(94, 148, 255);
            comboSex.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            comboSex.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            comboSex.ForeColor = Color.FromArgb(68, 88, 112);
            comboSex.ItemHeight = 40;
            comboSex.Items.AddRange(new object[] { "Male", "Female" });
            comboSex.Location = new Point(377, 270);
            comboSex.Name = "comboSex";
            comboSex.ShadowDecoration.CustomizableEdges = customizableEdges22;
            comboSex.Size = new Size(101, 46);
            comboSex.TabIndex = 28;
            comboSex.TextAlign = HorizontalAlignment.Center;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.SteelBlue;
            label1.Location = new Point(381, 246);
            label1.Name = "label1";
            label1.Size = new Size(46, 20);
            label1.TabIndex = 27;
            label1.Text = "Sex:";
            // 
            // txtPhone
            // 
            txtPhone.BorderColor = Color.FromArgb(64, 64, 64);
            txtPhone.BorderRadius = 20;
            txtPhone.CustomizableEdges = customizableEdges23;
            txtPhone.DefaultText = "999-9999-999";
            txtPhone.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPhone.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPhone.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPhone.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPhone.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPhone.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtPhone.ForeColor = Color.CornflowerBlue;
            txtPhone.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPhone.Location = new Point(7, 194);
            txtPhone.Margin = new Padding(3, 4, 3, 4);
            txtPhone.Name = "txtPhone";
            txtPhone.PasswordChar = '\0';
            txtPhone.PlaceholderText = "";
            txtPhone.SelectedText = "";
            txtPhone.ShadowDecoration.CustomizableEdges = customizableEdges24;
            txtPhone.Size = new Size(219, 43);
            txtPhone.TabIndex = 26;
            txtPhone.TextAlign = HorizontalAlignment.Center;
            // 
            // txtEmail
            // 
            txtEmail.BorderColor = Color.FromArgb(64, 64, 64);
            txtEmail.BorderRadius = 20;
            txtEmail.CustomizableEdges = customizableEdges25;
            txtEmail.DefaultText = "ToanKhoa@gmail.com";
            txtEmail.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtEmail.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtEmail.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtEmail.ForeColor = Color.CornflowerBlue;
            txtEmail.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Location = new Point(257, 113);
            txtEmail.Margin = new Padding(3, 4, 3, 4);
            txtEmail.Name = "txtEmail";
            txtEmail.PasswordChar = '\0';
            txtEmail.PlaceholderText = "";
            txtEmail.SelectedText = "";
            txtEmail.ShadowDecoration.CustomizableEdges = customizableEdges26;
            txtEmail.Size = new Size(221, 43);
            txtEmail.TabIndex = 25;
            txtEmail.TextAlign = HorizontalAlignment.Center;
            // 
            // txtRank
            // 
            txtRank.BorderColor = Color.FromArgb(64, 64, 64);
            txtRank.BorderRadius = 20;
            txtRank.CustomizableEdges = customizableEdges27;
            txtRank.DefaultText = "7";
            txtRank.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtRank.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtRank.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtRank.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtRank.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtRank.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtRank.ForeColor = Color.CornflowerBlue;
            txtRank.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtRank.Location = new Point(253, 271);
            txtRank.Margin = new Padding(3, 4, 3, 4);
            txtRank.Name = "txtRank";
            txtRank.PasswordChar = '\0';
            txtRank.PlaceholderText = "";
            txtRank.SelectedText = "";
            txtRank.ShadowDecoration.CustomizableEdges = customizableEdges28;
            txtRank.Size = new Size(96, 45);
            txtRank.TabIndex = 24;
            txtRank.TextAlign = HorizontalAlignment.Center;
            // 
            // lblRank
            // 
            lblRank.AutoSize = true;
            lblRank.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblRank.ForeColor = Color.SteelBlue;
            lblRank.Location = new Point(258, 247);
            lblRank.Name = "lblRank";
            lblRank.Size = new Size(64, 20);
            lblRank.TabIndex = 23;
            lblRank.Text = "Rank:";
            // 
            // lblPhone
            // 
            lblPhone.AutoSize = true;
            lblPhone.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblPhone.ForeColor = Color.SteelBlue;
            lblPhone.Location = new Point(23, 170);
            lblPhone.Name = "lblPhone";
            lblPhone.Size = new Size(74, 20);
            lblPhone.TabIndex = 22;
            lblPhone.Text = "Phone:";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblEmail.ForeColor = Color.SteelBlue;
            lblEmail.Location = new Point(274, 89);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(67, 20);
            lblEmail.TabIndex = 21;
            lblEmail.Text = "Email:";
            // 
            // txtIDCustomer
            // 
            txtIDCustomer.BorderColor = Color.FromArgb(64, 64, 64);
            txtIDCustomer.BorderRadius = 20;
            txtIDCustomer.CustomizableEdges = customizableEdges29;
            txtIDCustomer.DefaultText = "012";
            txtIDCustomer.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtIDCustomer.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtIDCustomer.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtIDCustomer.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtIDCustomer.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtIDCustomer.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtIDCustomer.ForeColor = Color.CornflowerBlue;
            txtIDCustomer.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtIDCustomer.Location = new Point(51, 22);
            txtIDCustomer.Margin = new Padding(3, 4, 3, 4);
            txtIDCustomer.Name = "txtIDCustomer";
            txtIDCustomer.PasswordChar = '\0';
            txtIDCustomer.PlaceholderText = "";
            txtIDCustomer.SelectedText = "";
            txtIDCustomer.ShadowDecoration.CustomizableEdges = customizableEdges30;
            txtIDCustomer.Size = new Size(85, 46);
            txtIDCustomer.TabIndex = 20;
            txtIDCustomer.TextAlign = HorizontalAlignment.Center;
            // 
            // lblD
            // 
            lblD.AutoSize = true;
            lblD.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblD.ForeColor = Color.SteelBlue;
            lblD.Location = new Point(10, 31);
            lblD.Name = "lblD";
            lblD.Size = new Size(38, 20);
            lblD.TabIndex = 19;
            lblD.Text = "ID:";
            // 
            // txtFullName
            // 
            txtFullName.BorderColor = Color.FromArgb(64, 64, 64);
            txtFullName.BorderRadius = 20;
            txtFullName.CustomizableEdges = customizableEdges31;
            txtFullName.DefaultText = "Nguyen Nguyen Toan Khoa";
            txtFullName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtFullName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtFullName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtFullName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtFullName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtFullName.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtFullName.ForeColor = Color.CornflowerBlue;
            txtFullName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtFullName.Location = new Point(7, 112);
            txtFullName.Margin = new Padding(3, 4, 3, 4);
            txtFullName.Name = "txtFullName";
            txtFullName.PasswordChar = '\0';
            txtFullName.PlaceholderText = "";
            txtFullName.SelectedText = "";
            txtFullName.ShadowDecoration.CustomizableEdges = customizableEdges32;
            txtFullName.Size = new Size(219, 43);
            txtFullName.TabIndex = 18;
            txtFullName.TextAlign = HorizontalAlignment.Center;
            // 
            // lblFullName
            // 
            lblFullName.AutoSize = true;
            lblFullName.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblFullName.ForeColor = Color.SteelBlue;
            lblFullName.Location = new Point(23, 89);
            lblFullName.Name = "lblFullName";
            lblFullName.Size = new Size(103, 20);
            lblFullName.TabIndex = 17;
            lblFullName.Text = "FullName:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(45, 389);
            label5.Name = "label5";
            label5.Size = new Size(0, 20);
            label5.TabIndex = 12;
            // 
            // dgvManageCustomer
            // 
            dgvManageCustomer.BackgroundColor = SystemColors.ButtonHighlight;
            dgvManageCustomer.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvManageCustomer.ColumnHeadersVisible = false;
            dgvManageCustomer.Dock = DockStyle.Fill;
            dgvManageCustomer.Location = new Point(485, 0);
            dgvManageCustomer.Name = "dgvManageCustomer";
            dgvManageCustomer.RowHeadersWidth = 51;
            dgvManageCustomer.Size = new Size(697, 553);
            dgvManageCustomer.TabIndex = 1;
            dgvManageCustomer.CellContentClick += dgvManageCustomer_CellContentClick;
            // 
            // FManageCustomer
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1182, 553);
            Controls.Add(dgvManageCustomer);
            Controls.Add(panelInformation);
            Name = "FManageCustomer";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FManageCustomer";
            Load += FManageCustomer_Load_1;
            panelInformation.ResumeLayout(false);
            panelInformation.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvManageCustomer).EndInit();
            ((System.ComponentModel.ISupportInitialize)bindingSource1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelInformation;
        private DataGridView dgvManageCustomer;
        private Label label5;
        private Panel panel1;
        private Guna.UI2.WinForms.Guna2ComboBox comboFilter;
        private Label label2;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpDayBuying;
        private Guna.UI2.WinForms.Guna2ComboBox comboSex;
        private Label label1;
        private Guna.UI2.WinForms.Guna2TextBox txtPhone;
        private Guna.UI2.WinForms.Guna2TextBox txtEmail;
        private Guna.UI2.WinForms.Guna2TextBox txtRank;
        private Label lblRank;
        private Label lblPhone;
        private Label lblEmail;
        private Guna.UI2.WinForms.Guna2TextBox txtIDCustomer;
        private Label lblD;
        private Guna.UI2.WinForms.Guna2TextBox txtFullName;
        private Label lblFullName;
        private Guna.UI2.WinForms.Guna2Button btnSearch;
        private Guna.UI2.WinForms.Guna2TextBox txtSearch;
        private Label lblFilter;
        private BindingSource bindingSource1;
        private Guna.UI2.WinForms.Guna2Button btnDelete;
        private Guna.UI2.WinForms.Guna2ComboBox comboSearch;
        private Guna.UI2.WinForms.Guna2Button btnUpdate;
        private Label lblAddress;
        private Guna.UI2.WinForms.Guna2TextBox txtAddress;
        private Label label3;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpBirthday;
        private Guna.UI2.WinForms.Guna2Button btnTopCustomer;
    }
}
