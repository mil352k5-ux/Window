﻿namespace Store_Gold
{
    partial class FImportgoods
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panel1 = new Panel();
            lblSupplierImport = new Label();
            panel2 = new Panel();
            dgvImportsgood = new DataGridView();
            btnConfirm = new Guna.UI2.WinForms.Guna2Button();
            panel3 = new Panel();
            txtQuantityImports = new Guna.UI2.WinForms.Guna2TextBox();
            txtProvidesNameImport = new Guna.UI2.WinForms.Guna2TextBox();
            txtProductIDImport = new Guna.UI2.WinForms.Guna2TextBox();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvImportsgood).BeginInit();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.Azure;
            panel1.Controls.Add(lblSupplierImport);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(882, 98);
            panel1.TabIndex = 2;
            // 
            // lblSupplierImport
            // 
            lblSupplierImport.AutoSize = true;
            lblSupplierImport.Font = new Font("Microsoft Sans Serif", 24F, FontStyle.Regular, GraphicsUnit.Point);
            lblSupplierImport.ForeColor = Color.CadetBlue;
            lblSupplierImport.Location = new Point(213, 9);
            lblSupplierImport.Name = "lblSupplierImport";
            lblSupplierImport.Size = new Size(443, 46);
            lblSupplierImport.TabIndex = 15;
            lblSupplierImport.Text = "Supplier - Import Goods";
            // 
            // panel2
            // 
            panel2.Controls.Add(dgvImportsgood);
            panel2.Dock = DockStyle.Right;
            panel2.Location = new Point(447, 98);
            panel2.Name = "panel2";
            panel2.Size = new Size(435, 528);
            panel2.TabIndex = 3;
            // 
            // dgvImportsgood
            // 
            dgvImportsgood.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvImportsgood.Dock = DockStyle.Fill;
            dgvImportsgood.Location = new Point(0, 0);
            dgvImportsgood.Name = "dgvImportsgood";
            dgvImportsgood.RowHeadersWidth = 51;
            dgvImportsgood.RowTemplate.Height = 29;
            dgvImportsgood.Size = new Size(435, 528);
            dgvImportsgood.TabIndex = 0;
            dgvImportsgood.CellContentClick += dgvImportsgood_CellContentClick;
            // 
            // btnConfirm
            // 
            btnConfirm.BorderRadius = 15;
            btnConfirm.CustomizableEdges = customizableEdges1;
            btnConfirm.DisabledState.BorderColor = Color.DarkGray;
            btnConfirm.DisabledState.CustomBorderColor = Color.DarkGray;
            btnConfirm.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnConfirm.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnConfirm.FillColor = Color.IndianRed;
            btnConfirm.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnConfirm.ForeColor = Color.White;
            btnConfirm.Location = new Point(35, 445);
            btnConfirm.Name = "btnConfirm";
            btnConfirm.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnConfirm.Size = new Size(344, 56);
            btnConfirm.TabIndex = 14;
            btnConfirm.Text = "Confirm";
            btnConfirm.Click += btnConfirm_Click_1;
            // 
            // panel3
            // 
            panel3.Controls.Add(txtQuantityImports);
            panel3.Controls.Add(txtProvidesNameImport);
            panel3.Controls.Add(txtProductIDImport);
            panel3.Controls.Add(btnConfirm);
            panel3.Dock = DockStyle.Fill;
            panel3.Location = new Point(0, 98);
            panel3.Name = "panel3";
            panel3.Size = new Size(447, 528);
            panel3.TabIndex = 15;
            // 
            // txtQuantityImports
            // 
            txtQuantityImports.BorderColor = Color.Red;
            txtQuantityImports.BorderRadius = 15;
            txtQuantityImports.CustomizableEdges = customizableEdges3;
            txtQuantityImports.DefaultText = "How many ? ";
            txtQuantityImports.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtQuantityImports.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtQuantityImports.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtQuantityImports.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtQuantityImports.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtQuantityImports.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtQuantityImports.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtQuantityImports.Location = new Point(35, 339);
            txtQuantityImports.Name = "txtQuantityImports";
            txtQuantityImports.PasswordChar = '\0';
            txtQuantityImports.PlaceholderText = "";
            txtQuantityImports.SelectedText = "";
            txtQuantityImports.ShadowDecoration.CustomizableEdges = customizableEdges4;
            txtQuantityImports.Size = new Size(250, 45);
            txtQuantityImports.TabIndex = 17;
            // 
            // txtProvidesNameImport
            // 
            txtProvidesNameImport.BorderColor = Color.Red;
            txtProvidesNameImport.BorderRadius = 15;
            txtProvidesNameImport.CustomizableEdges = customizableEdges5;
            txtProvidesNameImport.DefaultText = "";
            txtProvidesNameImport.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtProvidesNameImport.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtProvidesNameImport.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtProvidesNameImport.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtProvidesNameImport.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtProvidesNameImport.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtProvidesNameImport.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtProvidesNameImport.Location = new Point(35, 227);
            txtProvidesNameImport.Name = "txtProvidesNameImport";
            txtProvidesNameImport.PasswordChar = '\0';
            txtProvidesNameImport.PlaceholderText = "";
            txtProvidesNameImport.SelectedText = "";
            txtProvidesNameImport.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtProvidesNameImport.Size = new Size(250, 45);
            txtProvidesNameImport.TabIndex = 16;
            // 
            // txtProductIDImport
            // 
            txtProductIDImport.BorderColor = Color.Red;
            txtProductIDImport.BorderRadius = 15;
            txtProductIDImport.CustomizableEdges = customizableEdges7;
            txtProductIDImport.DefaultText = "";
            txtProductIDImport.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtProductIDImport.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtProductIDImport.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtProductIDImport.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtProductIDImport.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtProductIDImport.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtProductIDImport.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtProductIDImport.Location = new Point(35, 119);
            txtProductIDImport.Name = "txtProductIDImport";
            txtProductIDImport.PasswordChar = '\0';
            txtProductIDImport.PlaceholderText = "";
            txtProductIDImport.SelectedText = "";
            txtProductIDImport.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtProductIDImport.Size = new Size(250, 45);
            txtProductIDImport.TabIndex = 15;
            // 
            // FImportgoods
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(882, 626);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "FImportgoods";
            Text = "FImportgoods";
            Load += FImportgoods_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvImportsgood).EndInit();
            panel3.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion
        private Panel panel1;
        private Panel panel2;
        private DataGridView dgvImportsgood;
        private Guna.UI2.WinForms.Guna2Button btnConfirm;
        private Label lblSupplierImport;
        private Panel panel3;
        private Guna.UI2.WinForms.Guna2TextBox txtProvidesNameImport;
        private Guna.UI2.WinForms.Guna2TextBox txtProductIDImport;
        private Guna.UI2.WinForms.Guna2TextBox txtQuantityImports;
    }
}