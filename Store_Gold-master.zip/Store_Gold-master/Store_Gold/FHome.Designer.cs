﻿namespace Store_Gold
{
    partial class FHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FHome));
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            ptbListOther = new PictureBox();
            imagelistRing = new ImageList(components);
            imagelistOther = new ImageList(components);
            ptbListRing = new PictureBox();
            ptbHome = new PictureBox();
            panel1 = new Panel();
            lblRevenue = new Label();
            panel2 = new Panel();
            dgvrevenue = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)ptbListOther).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ptbListRing).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ptbHome).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvrevenue).BeginInit();
            SuspendLayout();
            // 
            // ptbListOther
            // 
            ptbListOther.Location = new Point(870, 12);
            ptbListOther.Name = "ptbListOther";
            ptbListOther.Size = new Size(250, 250);
            ptbListOther.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbListOther.TabIndex = 1;
            ptbListOther.TabStop = false;
            ptbListOther.Click += ptbListOther_Click;
            // 
            // imagelistRing
            // 
            imagelistRing.ColorDepth = ColorDepth.Depth32Bit;
            imagelistRing.ImageStream = (ImageListStreamer)resources.GetObject("imagelistRing.ImageStream");
            imagelistRing.TransparentColor = Color.Transparent;
            imagelistRing.Images.SetKeyName(0, "ring5.jpg");
            imagelistRing.Images.SetKeyName(1, "ring4.jpg");
            imagelistRing.Images.SetKeyName(2, "ring3.jpg");
            imagelistRing.Images.SetKeyName(3, "ring2.jpg");
            imagelistRing.Images.SetKeyName(4, "ring1.jpg");
            // 
            // imagelistOther
            // 
            imagelistOther.ColorDepth = ColorDepth.Depth8Bit;
            imagelistOther.ImageStream = (ImageListStreamer)resources.GetObject("imagelistOther.ImageStream");
            imagelistOther.TransparentColor = Color.Transparent;
            imagelistOther.Images.SetKeyName(0, "ring8.jpg");
            imagelistOther.Images.SetKeyName(1, "ring7.jpg");
            imagelistOther.Images.SetKeyName(2, "ring6.jpg");
            imagelistOther.Images.SetKeyName(3, "ring5.jpg");
            imagelistOther.Images.SetKeyName(4, "ring4.jpg");
            // 
            // ptbListRing
            // 
            ptbListRing.Location = new Point(586, 12);
            ptbListRing.Name = "ptbListRing";
            ptbListRing.Size = new Size(250, 250);
            ptbListRing.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbListRing.TabIndex = 0;
            ptbListRing.TabStop = false;
            ptbListRing.Click += ptbListRing_Click;
            // 
            // ptbHome
            // 
            ptbHome.BackgroundImage = (Image)resources.GetObject("ptbHome.BackgroundImage");
            ptbHome.BackgroundImageLayout = ImageLayout.Stretch;
            ptbHome.Location = new Point(6, 12);
            ptbHome.Name = "ptbHome";
            ptbHome.Size = new Size(516, 781);
            ptbHome.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbHome.TabIndex = 0;
            ptbHome.TabStop = false;
            // 
            // panel1
            // 
            panel1.Controls.Add(lblRevenue);
            panel1.Location = new Point(528, 338);
            panel1.Name = "panel1";
            panel1.Size = new Size(646, 64);
            panel1.TabIndex = 2;
            // 
            // lblRevenue
            // 
            lblRevenue.AutoSize = true;
            lblRevenue.Font = new Font("Microsoft Sans Serif", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblRevenue.ForeColor = Color.DarkSlateGray;
            lblRevenue.Location = new Point(254, 15);
            lblRevenue.Name = "lblRevenue";
            lblRevenue.Size = new Size(128, 32);
            lblRevenue.TabIndex = 1;
            lblRevenue.Text = "Revenue";
            // 
            // panel2
            // 
            panel2.Controls.Add(dgvrevenue);
            panel2.Location = new Point(528, 429);
            panel2.Name = "panel2";
            panel2.Size = new Size(646, 345);
            panel2.TabIndex = 3;
            // 
            // dgvrevenue
            // 
            dgvrevenue.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvrevenue.Dock = DockStyle.Fill;
            dgvrevenue.Location = new Point(0, 0);
            dgvrevenue.Name = "dgvrevenue";
            dgvrevenue.RowHeadersWidth = 51;
            dgvrevenue.RowTemplate.Height = 29;
            dgvrevenue.Size = new Size(646, 345);
            dgvrevenue.TabIndex = 0;
            // 
            // FHome
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.nen_xam;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1182, 801);
            ControlBox = false;
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(ptbHome);
            Controls.Add(ptbListRing);
            Controls.Add(ptbListOther);
            Name = "FHome";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FHome";
            Load += FHome_Load;
            ((System.ComponentModel.ISupportInitialize)ptbListOther).EndInit();
            ((System.ComponentModel.ISupportInitialize)ptbListRing).EndInit();
            ((System.ComponentModel.ISupportInitialize)ptbHome).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvrevenue).EndInit();
            ResumeLayout(false);
        }

        #endregion
        public ImageList imagelistRing;
        public ImageList imagelistOther;
        public PictureBox ptbListOther;
        public PictureBox ptbListRing;
        public PictureBox ptbHome;
        private Panel panel1;
        private Label lblRevenue;
        private Panel panel2;
        private DataGridView dgvrevenue;
    }
}