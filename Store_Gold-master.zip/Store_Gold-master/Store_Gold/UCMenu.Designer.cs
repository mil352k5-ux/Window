﻿namespace Store_Gold
{
    partial class UCMenu
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCMenu));
            panelAccount = new Panel();
            ptbPictureAccount = new PictureBox();
            lblNameAccount = new Label();
            panel2 = new Panel();
            pbmenu = new PictureBox();
            btnbutton1 = new Button();
            btnbutton2 = new Button();
            btnbutton3 = new Button();
            btnbutton4 = new Button();
            panelbtnmenu = new Panel();
            btnbutton6 = new Button();
            btnbutton5 = new Button();
            panelTitle = new Panel();
            mtAccount = new Guna.UI2.WinForms.Guna2ContextMenuStrip();
            yourInformationToolStripMenuItem = new ToolStripMenuItem();
            logOutToolStripMenuItem = new ToolStripMenuItem();
            panelDesktoppane = new Panel();
            panelAccount.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ptbPictureAccount).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pbmenu).BeginInit();
            panelbtnmenu.SuspendLayout();
            panelTitle.SuspendLayout();
            mtAccount.SuspendLayout();
            SuspendLayout();
            // 
            // panelAccount
            // 
            panelAccount.BackColor = Color.Transparent;
            panelAccount.Controls.Add(ptbPictureAccount);
            panelAccount.Controls.Add(lblNameAccount);
            panelAccount.Dock = DockStyle.Right;
            panelAccount.Location = new Point(999, 0);
            panelAccount.Name = "panelAccount";
            panelAccount.Size = new Size(201, 52);
            panelAccount.TabIndex = 5;
            // 
            // ptbPictureAccount
            // 
            ptbPictureAccount.Location = new Point(152, 12);
            ptbPictureAccount.Name = "ptbPictureAccount";
            ptbPictureAccount.Size = new Size(29, 33);
            ptbPictureAccount.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbPictureAccount.TabIndex = 1;
            ptbPictureAccount.TabStop = false;
            // 
            // lblNameAccount
            // 
            lblNameAccount.AutoSize = true;
            lblNameAccount.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblNameAccount.ForeColor = Color.SteelBlue;
            lblNameAccount.Location = new Point(3, 19);
            lblNameAccount.Name = "lblNameAccount";
            lblNameAccount.Size = new Size(143, 17);
            lblNameAccount.TabIndex = 0;
            lblNameAccount.Text = "Welcome, ToànKhoa";
            // 
            // panel2
            // 
            panel2.Controls.Add(pbmenu);
            panel2.Dock = DockStyle.Left;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(56, 52);
            panel2.TabIndex = 5;
            // 
            // pbmenu
            // 
            pbmenu.Dock = DockStyle.Fill;
            pbmenu.Location = new Point(0, 0);
            pbmenu.Name = "pbmenu";
            pbmenu.Size = new Size(56, 52);
            pbmenu.SizeMode = PictureBoxSizeMode.StretchImage;
            pbmenu.TabIndex = 1;
            pbmenu.TabStop = false;
            // 
            // btnbutton1
            // 
            btnbutton1.BackColor = Color.Transparent;
            btnbutton1.Dock = DockStyle.Left;
            btnbutton1.FlatAppearance.BorderSize = 0;
            btnbutton1.FlatStyle = FlatStyle.Flat;
            btnbutton1.Font = new Font("Segoe UI Black", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            btnbutton1.ForeColor = Color.Black;
            btnbutton1.Image = (Image)resources.GetObject("btnbutton1.Image");
            btnbutton1.ImageAlign = ContentAlignment.MiddleLeft;
            btnbutton1.Location = new Point(0, 0);
            btnbutton1.Name = "btnbutton1";
            btnbutton1.Size = new Size(154, 52);
            btnbutton1.TabIndex = 3;
            btnbutton1.Text = "button1";
            btnbutton1.UseVisualStyleBackColor = false;
            // 
            // btnbutton2
            // 
            btnbutton2.BackColor = Color.Transparent;
            btnbutton2.Dock = DockStyle.Left;
            btnbutton2.FlatAppearance.BorderSize = 0;
            btnbutton2.FlatStyle = FlatStyle.Flat;
            btnbutton2.Font = new Font("Segoe UI Black", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            btnbutton2.ForeColor = Color.Black;
            btnbutton2.Image = (Image)resources.GetObject("btnbutton2.Image");
            btnbutton2.ImageAlign = ContentAlignment.MiddleLeft;
            btnbutton2.Location = new Point(154, 0);
            btnbutton2.Name = "btnbutton2";
            btnbutton2.Size = new Size(154, 52);
            btnbutton2.TabIndex = 2;
            btnbutton2.Text = "button2";
            btnbutton2.UseVisualStyleBackColor = false;
            // 
            // btnbutton3
            // 
            btnbutton3.Dock = DockStyle.Left;
            btnbutton3.FlatAppearance.BorderSize = 0;
            btnbutton3.FlatStyle = FlatStyle.Flat;
            btnbutton3.Font = new Font("Segoe UI Black", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            btnbutton3.ForeColor = Color.Black;
            btnbutton3.Image = (Image)resources.GetObject("btnbutton3.Image");
            btnbutton3.ImageAlign = ContentAlignment.MiddleLeft;
            btnbutton3.Location = new Point(308, 0);
            btnbutton3.Name = "btnbutton3";
            btnbutton3.RightToLeft = RightToLeft.No;
            btnbutton3.Size = new Size(154, 52);
            btnbutton3.TabIndex = 3;
            btnbutton3.Text = "button3";
            btnbutton3.UseVisualStyleBackColor = true;
            // 
            // btnbutton4
            // 
            btnbutton4.Dock = DockStyle.Left;
            btnbutton4.FlatAppearance.BorderSize = 0;
            btnbutton4.FlatStyle = FlatStyle.Flat;
            btnbutton4.Font = new Font("Segoe UI Black", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            btnbutton4.ForeColor = Color.Black;
            btnbutton4.Image = (Image)resources.GetObject("btnbutton4.Image");
            btnbutton4.ImageAlign = ContentAlignment.MiddleLeft;
            btnbutton4.Location = new Point(462, 0);
            btnbutton4.Name = "btnbutton4";
            btnbutton4.RightToLeft = RightToLeft.No;
            btnbutton4.Size = new Size(154, 52);
            btnbutton4.TabIndex = 4;
            btnbutton4.Text = "button4";
            btnbutton4.UseVisualStyleBackColor = true;
            // 
            // panelbtnmenu
            // 
            panelbtnmenu.Controls.Add(btnbutton6);
            panelbtnmenu.Controls.Add(btnbutton5);
            panelbtnmenu.Controls.Add(btnbutton4);
            panelbtnmenu.Controls.Add(btnbutton3);
            panelbtnmenu.Controls.Add(btnbutton2);
            panelbtnmenu.Controls.Add(btnbutton1);
            panelbtnmenu.Dock = DockStyle.Fill;
            panelbtnmenu.Location = new Point(56, 0);
            panelbtnmenu.Name = "panelbtnmenu";
            panelbtnmenu.Size = new Size(943, 52);
            panelbtnmenu.TabIndex = 11;
            // 
            // btnbutton6
            // 
            btnbutton6.Dock = DockStyle.Left;
            btnbutton6.FlatAppearance.BorderSize = 0;
            btnbutton6.FlatStyle = FlatStyle.Flat;
            btnbutton6.Font = new Font("Segoe UI Black", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            btnbutton6.ForeColor = Color.Black;
            btnbutton6.Image = (Image)resources.GetObject("btnbutton6.Image");
            btnbutton6.ImageAlign = ContentAlignment.MiddleLeft;
            btnbutton6.Location = new Point(770, 0);
            btnbutton6.Name = "btnbutton6";
            btnbutton6.RightToLeft = RightToLeft.No;
            btnbutton6.Size = new Size(154, 52);
            btnbutton6.TabIndex = 6;
            btnbutton6.Text = "button4";
            btnbutton6.UseVisualStyleBackColor = true;
            btnbutton6.Click += btnbutton6_Click;
            // 
            // btnbutton5
            // 
            btnbutton5.Dock = DockStyle.Left;
            btnbutton5.FlatAppearance.BorderSize = 0;
            btnbutton5.FlatStyle = FlatStyle.Flat;
            btnbutton5.Font = new Font("Segoe UI Black", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            btnbutton5.ForeColor = Color.Black;
            btnbutton5.Image = (Image)resources.GetObject("btnbutton5.Image");
            btnbutton5.ImageAlign = ContentAlignment.MiddleLeft;
            btnbutton5.Location = new Point(616, 0);
            btnbutton5.Name = "btnbutton5";
            btnbutton5.RightToLeft = RightToLeft.No;
            btnbutton5.Size = new Size(154, 52);
            btnbutton5.TabIndex = 5;
            btnbutton5.Text = "button4";
            btnbutton5.UseVisualStyleBackColor = true;
            // 
            // panelTitle
            // 
            panelTitle.BackColor = SystemColors.HighlightText;
            panelTitle.Controls.Add(panelbtnmenu);
            panelTitle.Controls.Add(panel2);
            panelTitle.Controls.Add(panelAccount);
            panelTitle.Dock = DockStyle.Top;
            panelTitle.ForeColor = SystemColors.ActiveBorder;
            panelTitle.Location = new Point(0, 0);
            panelTitle.Name = "panelTitle";
            panelTitle.Size = new Size(1200, 52);
            panelTitle.TabIndex = 7;
            // 
            // mtAccount
            // 
            mtAccount.BackColor = SystemColors.ControlLightLight;
            mtAccount.ImageScalingSize = new Size(50, 50);
            mtAccount.Items.AddRange(new ToolStripItem[] { yourInformationToolStripMenuItem, logOutToolStripMenuItem });
            mtAccount.LayoutStyle = ToolStripLayoutStyle.HorizontalStackWithOverflow;
            mtAccount.Name = "mtAccount";
            mtAccount.RenderStyle.ArrowColor = Color.FromArgb(151, 143, 255);
            mtAccount.RenderStyle.BorderColor = Color.Gainsboro;
            mtAccount.RenderStyle.ColorTable = null;
            mtAccount.RenderStyle.RoundedEdges = true;
            mtAccount.RenderStyle.SelectionArrowColor = Color.White;
            mtAccount.RenderStyle.SelectionBackColor = Color.FromArgb(100, 88, 255);
            mtAccount.RenderStyle.SelectionForeColor = Color.White;
            mtAccount.RenderStyle.SeparatorColor = Color.Gainsboro;
            mtAccount.RenderStyle.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SystemDefault;
            mtAccount.Size = new Size(198, 52);
            // 
            // yourInformationToolStripMenuItem
            // 
            yourInformationToolStripMenuItem.BackgroundImageLayout = ImageLayout.None;
            yourInformationToolStripMenuItem.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            yourInformationToolStripMenuItem.Name = "yourInformationToolStripMenuItem";
            yourInformationToolStripMenuItem.RightToLeft = RightToLeft.Yes;
            yourInformationToolStripMenuItem.Size = new Size(197, 24);
            yourInformationToolStripMenuItem.Text = "Your Information";
            yourInformationToolStripMenuItem.TextDirection = ToolStripTextDirection.Horizontal;
            // 
            // logOutToolStripMenuItem
            // 
            logOutToolStripMenuItem.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            logOutToolStripMenuItem.Name = "logOutToolStripMenuItem";
            logOutToolStripMenuItem.Size = new Size(197, 24);
            logOutToolStripMenuItem.Text = "Log out";
            logOutToolStripMenuItem.Click += logOutToolStripMenuItem_Click;
            // 
            // panelDesktoppane
            // 
            panelDesktoppane.Dock = DockStyle.Fill;
            panelDesktoppane.Location = new Point(0, 52);
            panelDesktoppane.Name = "panelDesktoppane";
            panelDesktoppane.Size = new Size(1200, 848);
            panelDesktoppane.TabIndex = 8;
            // 
            // UCMenu
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(panelDesktoppane);
            Controls.Add(panelTitle);
            Name = "UCMenu";
            Size = new Size(1200, 900);
            panelAccount.ResumeLayout(false);
            panelAccount.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)ptbPictureAccount).EndInit();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pbmenu).EndInit();
            panelbtnmenu.ResumeLayout(false);
            panelTitle.ResumeLayout(false);
            mtAccount.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        public Panel panelAccount;
        public PictureBox ptbPictureAccount;
        public Label lblNameAccount;
        public Panel panel2;
        public PictureBox pbmenu;
        public Button btnbutton1;
        public Button btnbutton2;
        public Button btnbutton3;
        public Button btnbutton4;
        public Panel panelbtnmenu;
        public Panel panelTitle;
        private Guna.UI2.WinForms.Guna2ContextMenuStrip mtAccount;
        private ToolStripMenuItem yourInformationToolStripMenuItem;
        private ToolStripMenuItem logOutToolStripMenuItem;
        public Panel panelDesktoppane;
        public Button btnbutton6;
        public Button btnbutton5;
    }
}
