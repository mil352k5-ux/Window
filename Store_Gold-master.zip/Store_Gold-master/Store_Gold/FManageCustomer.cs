﻿using Guna.UI2.WinForms;

namespace Store_Gold
{
    public partial class FManageCustomer : Form
    {
        public FManageCustomer()
        {
            InitializeComponent();
            txtIDCustomer.Click += TextBox_Click;
            txtFullName.Click += TextBox_Click;
            txtEmail.Click += TextBox_Click;
            txtPhone.Click += TextBox_Click;
            txtAddress.Click += TextBox_Click;
        }
        private void ClearTextBox(Guna2TextBox textBox)
        {
            textBox.Text = "";
            textBox.ForeColor = System.Drawing.SystemColors.ControlText;
        }
        private void FManageCustomer_Load_1(object sender, EventArgs e)
        {
            CustomerDAO customerDao = new CustomerDAO();
            dgvManageCustomer.DataSource = customerDao.Load(); /// gvHsinh = name cua data gridview
            dgvManageCustomer.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }
        private void TextBox_Click(object sender, EventArgs e)
        {
            if (sender is Guna2TextBox)
            {
                ClearTextBox(sender as Guna2TextBox);
            }
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            Customer customer = new Customer(txtFullName.Text, txtIDCustomer.Text, txtAddress.Text, txtEmail.Text, txtPhone.Text, dtpBirthday.Value);
            CustomerDAO customerDao = new CustomerDAO(customer);
            customerDao.Delete();
            FManageCustomer_Load_1(sender, e);
        }

        private void btnUpdate_Click_1(object sender, EventArgs e)
        {
            Customer customer = new Customer(txtFullName.Text, txtIDCustomer.Text, txtAddress.Text, txtEmail.Text, txtPhone.Text, dtpBirthday.Value);
            CustomerDAO customerDao = new CustomerDAO(customer);
            customerDao.Update();
            FManageCustomer_Load_1(sender, e);
        }

        private void dgvManageCustomer_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvManageCustomer.Rows[e.RowIndex];
                txtIDCustomer.Text = row.Cells["customer_id"].Value.ToString();
                txtFullName.Text = row.Cells["customer_name"].Value.ToString();
                txtAddress.Text = row.Cells["customer_address"].Value.ToString();
                txtPhone.Text = row.Cells["customer_phone"].Value.ToString();
                dtpBirthday.Text = row.Cells["customer_birthday"].Value.ToString();
                txtEmail.Text = row.Cells["customer_email"].Value.ToString();
            }
        }
        private void btnDelete_Click_1(object sender, EventArgs e)
        {
            Customer customer = new Customer(txtFullName.Text, txtIDCustomer.Text, txtAddress.Text, txtEmail.Text, txtPhone.Text, dtpBirthday.Value);
            CustomerDAO customerDao = new CustomerDAO(customer);
            customerDao.Delete();
            FManageCustomer_Load_1(sender, e);
        }

        private void btnTopCustomer_Click(object sender, EventArgs e)
        {
            CustomerDAO customerDao = new CustomerDAO();
            dgvManageCustomer.DataSource = customerDao.GetTopCustomers();
            dgvManageCustomer.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }
    }
}
