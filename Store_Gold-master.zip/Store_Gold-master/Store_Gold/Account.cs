﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store_Gold
{
    public class Account
    {
        private string email;
        private string userID;
        private string userName;
        private string password;
        private string phonenumber;

        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        public string UserID
        {
            get { return userID; }
            set { userID = value; }
        }
        public string UserName
        {
            get { return userName; }
            set { userName = value; }
        }
        public string Password
        {
            get { return password; }
            set { password = value; }
        }
        public string Phonenumber
        {
            get { return phonenumber; }
            set { phonenumber = value; }
        }
        public Account() { }
        public Account(string UserID, string UserName, string Password, string Email, string Phonenumber)
        {
            this.UserID = UserID;
            this.UserName = UserName;
            this.Password = Password;
            this.Email = Email;
            this.Phonenumber = Phonenumber;
        }
    }
}
