﻿using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Store_Gold
{
    public partial class FDetailCustomerInformation : Form
    {
        public static Customer currentcustomer = new Customer();

        public FDetailCustomerInformation()
        {
            InitializeComponent();
            txtPhoneNumber.Click += TextBox_Click;
            txtYourAddress.Click += TextBox_Click;
            txtNameContact.Click += TextBox_Click;
            txtYourMessage.Click += TextBox_Click;
            txtEmail.Click += TextBox_Click;

        }
        private void FDetailCustomerInformation_Load(object sender, EventArgs e)
        {
            lblNameCustomer.Text = currentcustomer.FullName;
            lblIDCustomer.Text = currentcustomer.CMND;
            lblDayofBook.Text = (DateTime.Now).ToShortDateString();
            lblIDProduct.Text = FListProduct.selectedProduct.productID;
            lblType.Text = FListProduct.selectedProduct.productName;
            lblPrice.Text = (FListProduct.selectedProduct.price).ToString();
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void ClearTextBox(Guna2TextBox textBox)
        {
            textBox.Text = "";
            textBox.ForeColor = System.Drawing.SystemColors.ControlText;
        }

        private void TextBox_Click(object sender, EventArgs e)
        {
            if (sender is Guna2TextBox)
            {
                ClearTextBox(sender as Guna2TextBox);
            }
        }
        private void btnPayingNow_Click(object sender, EventArgs e)
        {
            int quantityToBuy = int.Parse(txtquantitytobuy.Text);
            ProductDAO productDao = new ProductDAO();
            productDao.DeductProductQuantity(FListProduct.selectedProduct.productID, quantityToBuy);
            FBill.currentBill.Quantity_product = quantityToBuy;
            this.Close();
            FBill bill = new FBill();
            bill.ShowDialog();
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            Customer customer = new Customer(txtNameContact.Text, txtIDCustomer.Text, txtYourAddress.Text, txtEmail.Text, txtPhoneNumber.Text, dtpBirtday.Value);
            CustomerDAO customerDao = new CustomerDAO(customer);
            if (customerDao.CheckInforValid() == true)
            {
                customerDao.Add();
            }
            currentcustomer = customer;
            FDetailCustomerInformation_Load(sender, e);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtquantitytobuy_TextChanged(object sender, EventArgs e)
        {
            if (!int.TryParse(txtquantitytobuy.Text, out int quantity))
            {
                return;
            }
            decimal price = ((decimal)FListProduct.selectedProduct.price);
            decimal totalPrice = price * quantity;
            lblPrice.Text = totalPrice.ToString();
        }
    }
}
