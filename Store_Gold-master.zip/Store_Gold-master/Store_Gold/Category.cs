﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store_Gold
{
    public class Category
    {
        public string categoryID;
        public string categoryName;
        public double price;
        public int quantity;
        public Category() { }
        public Category(string categoryID, string categoryName, double price, int quantity)
        {
            this.categoryID = categoryID;
            this.categoryName = categoryName;
            this.price = price;
            this.quantity = quantity;
        }
    }
}
