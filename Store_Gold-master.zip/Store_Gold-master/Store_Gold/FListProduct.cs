﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Store_Gold
{
    public partial class FListProduct : Form
    {
        public static Product selectedProduct = new Product();
        public FListProduct()
        {
            InitializeComponent();
        }
        private void dgvListProduct_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ProductDAO productDao = new ProductDAO();
            productDao.ClearSelectedProducts();
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvListProduct.Rows[e.RowIndex];
                selectedProduct.productID = row.Cells["product_id"].Value.ToString();
                selectedProduct.productName = row.Cells["product_name"].Value.ToString();
                // Convert string to DateTime
                if (DateTime.TryParse(row.Cells["date_in"].Value.ToString(), out DateTime dateIn))
                {
                    selectedProduct.dateIn = dateIn;
                }
                // Convert string to DateTime
                if (DateTime.TryParse(row.Cells["date_out"].Value.ToString(), out DateTime dateOut))
                {
                    selectedProduct.dateOut = dateOut;
                }
                selectedProduct.category.categoryID = row.Cells["category_id"].Value.ToString();
                if (int.TryParse(row.Cells["quantity"].Value.ToString(), out int quantity))
                {
                    selectedProduct.quantity = quantity;
                }
                // Convert string to double
                if (double.TryParse(row.Cells["mace"].Value.ToString(), out double mace))
                {
                    selectedProduct.mace = mace;
                }
                if (double.TryParse(row.Cells["price"].Value.ToString(), out double price))
                {
                    selectedProduct.price = price;
                }
                productDao.AddSelectedProducts(selectedProduct.productID, selectedProduct.productName, selectedProduct.category.categoryID, selectedProduct.price);
                this.Hide();
                FDetailCustomerInformation detail = new FDetailCustomerInformation();
                detail.Show();
            }
        }

        private void FListProduct_Load(object sender, EventArgs e)
        {
            ProductDAO productDao = new ProductDAO();
            dgvListProduct.DataSource = productDao.Load();
            dgvListProduct.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            btnSearchProduct.Click += btnSearchProduct_Click;
        }
        public void Show_result_search()
        {
            string searchType = comboSearch.Text;
            string searchText = txtSearch.Text;
            ProductDAO productDao = new ProductDAO();
            DataTable searchResult = productDao.SearchProduct(searchType, searchText);
            // Hiển thị kết quả tìm kiếm trên DataGridView
            dgvListProduct.DataSource = searchResult;
            dgvListProduct.Refresh();
        }

        private void btnSearchProduct_Click(object sender, EventArgs e)
        {
            Show_result_search();
        }

        private void comboFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            string filtertype = comboFilter.Text;
            ProductDAO productDao = new ProductDAO();
            DataTable searchFilter = productDao.SearchFilterProduct(filtertype);
            dgvListProduct.DataSource = searchFilter;
            dgvListProduct.Refresh();
        }
    }
}
