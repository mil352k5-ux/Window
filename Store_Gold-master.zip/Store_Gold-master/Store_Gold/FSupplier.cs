﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Store_Gold
{
    public partial class FSupplier : Form
    {
        SupplierDAO supplierDAO = new SupplierDAO();
        private List<string> selectedProductIDs = new List<string>();
        public FSupplier()
        {
            InitializeComponent();
        }

        private void txtSupplierName_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void FSupplier_Load(object sender, EventArgs e)
        {
            dgvSupplier.DataSource = supplierDAO.Load();
            dgvSupplier.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            LoadSuppliers();
        }
        private void LoadSuppliers()
        {
            try
            {
                DataTable dtSuppliers = supplierDAO.GetSuppliers();
                if (dtSuppliers != null && dtSuppliers.Rows.Count > 0)
                {
                    // Tạo một DataTable mới để chứa danh sách công ty cung cấp, bao gồm cả tùy chọn "None"
                    DataTable dtSuppliersWithNoneOption = new DataTable();
                    dtSuppliersWithNoneOption.Columns.Add("Supplier_ID");
                    dtSuppliersWithNoneOption.Columns.Add("Supplier_Name");

                    // Thêm hàng "None" vào DataTable mới
                    dtSuppliersWithNoneOption.Rows.Add("None", "None");

                    // Sao chép dữ liệu từ DataTable nhận được từ cơ sở dữ liệu vào DataTable mới
                    foreach (DataRow row in dtSuppliers.Rows)
                    {
                        dtSuppliersWithNoneOption.ImportRow(row);
                    }

                    // Thiết lập dữ liệu cho ComboBox từ DataTable mới đã có cả tùy chọn "None"
                    cbCompany.DataSource = dtSuppliersWithNoneOption;
                    cbCompany.DisplayMember = "Supplier_Name";
                    cbCompany.ValueMember = "Supplier_ID";
                }
                else
                {
                    MessageBox.Show("Không có công ty cung cấp nào được tìm thấy.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error " + ex.Message);
            }
        }
        private void dgvSupplier_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }
        private void cbCompany_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedSupplierName = cbCompany.Text;
            if (!string.IsNullOrEmpty(selectedSupplierName))
            {
                if (selectedSupplierName == "None")
                {
                    DataTable dtAllProducts = supplierDAO.Load();
                    dgvSupplier.DataSource = dtAllProducts;
                }
                else
                {
                    DataTable dtProducts = supplierDAO.GetProductsBySupplier(selectedSupplierName);
                    dgvSupplier.DataSource = dtProducts;
                }
            }
        }
        private void btnImportgoods_Click(object sender, EventArgs e)
        {
            if (selectedProductIDs.Count > 0)
            {
                // Mở form FImportGoods và truyền danh sách sản phẩm đã chọn vào
                FImportgoods importForm = new FImportgoods(selectedProductIDs);
                importForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("Vui lòng chọn ít nhất một sản phẩm để nhập hàng.");
            }
        }
        private void dgvSupplier_SelectionChanged(object sender, EventArgs e)
        {
            selectedProductIDs.Clear();
            foreach (DataGridViewRow row in dgvSupplier.SelectedRows)
            {
                string productID = row.Cells["Product_ID"].Value.ToString();
                selectedProductIDs.Add(productID);
            }
        }

    }
}
