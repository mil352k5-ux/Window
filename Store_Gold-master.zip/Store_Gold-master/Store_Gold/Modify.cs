﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store_Gold
{
    internal class Modify
    {
        public Modify( )
        {
        }
        SqlCommand sqlCommand;
        SqlDataReader sqlDataReader;
        public List<Account> Accounts(string query)
        {
            List<Account> accounts = new List<Account>();
            using (SqlConnection sqlConnection = DBConnection.GetSqlConnection())
            {
                sqlConnection.Open();
                sqlCommand = new SqlCommand(query, sqlConnection);
                sqlDataReader = sqlCommand.ExecuteReader();
                while (sqlDataReader.Read())
                {
                    //accounts.Add(new Account(sqlDataReader.GetString(0), sqlDataReader.GetString(3)));
                }
                sqlConnection.Close();
            }
            return accounts;
        }
        public void Command(string query)
        {
            using (SqlConnection sqlConnection = DBConnection.GetSqlConnection())
            {
                sqlConnection.Open();
                sqlCommand = new SqlCommand (query , sqlConnection);
                sqlCommand.ExecuteNonQuery(); // thực thi câu truy vấn
                sqlConnection.Close();

            }    
            
        }
    }
}
