﻿using Guna.UI2.WinForms;
using ProjectFinalKCVTourism;
using System.Data.SqlClient;

namespace Store_Gold
{

    public partial class Form1 : Form
    {
        SqlConnection conn = new SqlConnection(Properties.Settings.Default.cnnstr);
        public static string ConnectString;
        public static Admin currentAdmin = new Admin();
        public static Account currentAccount = new Account();
        public static Staff currentStaff = new Staff();
        public Form1()
        {
            InitializeComponent();
            txtUsername.Click += TextBox_Click;
            cbshowpasswordSignin.CheckStateChanged += cbshowpasswordSignin_CheckStateChanged;
            cbshowpasswordSignin.Click += cbshowpasswordSignin_Click;
            txtPasswordSignin.Click += TextBox_Click;
        }
        private void TextBox_Click(object sender, EventArgs e)
        {
            if (sender is Guna2TextBox)
            {
                ClearTextBox(sender as Guna2TextBox);
            }
        }
        private void ClearTextBox(Guna2TextBox textBox)
        {
            textBox.Text = "";
            textBox.ForeColor = System.Drawing.SystemColors.ControlText;
        }
        private void btnCloseLogin_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void NewForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            // Hiển thị lại form gốc khi form mới đóng
            this.Show();
        } 
        int GetAccountCount(string userId, string password, SqlConnection conn)
        {
            string queryAccount = "SELECT COUNT(*) FROM Logininfo WHERE userid = @userId AND password = @password";
            SqlCommand sqlCommandAccount = new SqlCommand(queryAccount, conn);
            sqlCommandAccount.Parameters.AddWithValue("@userId", userId);
            sqlCommandAccount.Parameters.AddWithValue("@password", password);
            return (int)sqlCommandAccount.ExecuteScalar();
        }
        void GetUserAccountInfo(string userId, SqlConnection conn)
        {
            string queryGetAccountInfo = "SELECT username FROM Logininfo WHERE userid = @userId";
            SqlCommand sqlCommandGetAccountInfo = new SqlCommand(queryGetAccountInfo, conn);
            sqlCommandGetAccountInfo.Parameters.AddWithValue("@userId", userId);
            SqlDataReader readerAccount = sqlCommandGetAccountInfo.ExecuteReader();

            if (readerAccount.Read())
            {
                currentAccount.UserName = readerAccount["username"].ToString();
             
            }
            readerAccount.Close();
        }
        void GetStaffInfo(string userId, SqlConnection conn)
        {
            string queryGetStaffInfo = "SELECT * FROM Staff WHERE Staff_ID = @userId";
            SqlCommand sqlCommandGetStaffInfo = new SqlCommand(queryGetStaffInfo, conn);
            sqlCommandGetStaffInfo.Parameters.AddWithValue("@userId", userId);
            SqlDataReader readerStaff = sqlCommandGetStaffInfo.ExecuteReader();

            if (readerStaff.Read())
            {
                currentStaff.CMND = readerStaff["Staff_ID"].ToString();
                currentStaff.FullName = readerStaff["Staff_Name"].ToString();
                // Thêm các trường thông tin khác tương ứng với Staff vào đây
            }
            readerStaff.Close();
        }
        bool IsAdmin(string userId, SqlConnection conn)
        {
            string queryAdmin = "SELECT COUNT(*) FROM Admin WHERE admin_id = @userId";
            SqlCommand sqlCommandAdmin = new SqlCommand(queryAdmin, conn);
            sqlCommandAdmin.Parameters.AddWithValue("@userId", userId);
            int count = (int)sqlCommandAdmin.ExecuteScalar();
            return count > 0;
        }

        bool IsStaff(string userId, SqlConnection conn)
        {
            string queryStaff = "SELECT COUNT(*) FROM Staff WHERE Staff_ID = @userId";
            SqlCommand sqlCommandStaff = new SqlCommand(queryStaff, conn);
            sqlCommandStaff.Parameters.AddWithValue("@userId", userId);
            int count = (int)sqlCommandStaff.ExecuteScalar();
            return count > 0;
        }

        private void btnSignIn_Click(object sender, EventArgs e)
        {
            string userId = txtUsername.Text.Trim();
            string password = txtPasswordSignin.Text.Trim();

            if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please input your username and password");
                return;
            }

            try
            {
                using (conn)
                {
                    conn.Open();

                    // Kiểm tra xem tài khoản tồn tại và mật khẩu khớp
                    int accountCount = GetAccountCount(userId, password, conn);
                    if (accountCount == 1)
                    {
                        // Kiểm tra loại tài khoản (Admin hoặc Staff)
                        bool isAdmin = IsAdmin(userId, conn);
                        bool isStaff = IsStaff(userId, conn);

                        if (isAdmin)
                        {
                            MessageBox.Show("NOTICE!! LOGIN SUCCESSFULLY as Admin", "NOTICE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            OpenAdminMenu(userId, password);
                        }
                        else if (isStaff)
                        { 
                            MessageBox.Show("NOTICE!! LOGIN SUCCESSFULLY as Staff", "NOTICE", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            GetStaffInfo(userId, conn);
                            OpenAdminMenu(userId, password);
                        }
                        else
                        {
                            MessageBox.Show("Invalid credentials. Please check your username and password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid credentials. Please check your username and password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void OpenAdminMenu(string userId, string password)
        {
            ConnectString = $"Data Source=(localdb)\\mssqllocaldb;Initial Catalog=Store_gold;Encrypt=False;User ID={userId};Password={password}";
            DBConnection.Connectionstring = ConnectString;
            this.Hide();
            using (FMenuAdmin fmenuAdmin = new FMenuAdmin())
            {
                fmenuAdmin.FormClosed += NewForm_FormClosed;
                fmenuAdmin.ShowDialog();
            }
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            this.Hide();
            //FSignUp form3 = new FSignUp();
            //form3.FormClosed += NewForm_FormClosed;
            //form3.ShowDialog();
        }
        private void cbshowpasswordSignin_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void txtPasswordSignin_TextChanged(object sender, EventArgs e)
        {

        }

        private void linklblForgotAccount_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            FforgotPassword forgot = new FforgotPassword();
            forgot.FormClosed += NewForm_FormClosed;
            forgot.ShowDialog();
        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void cbshowpasswordSignin_Click(object sender, EventArgs e)
        {
            if (cbshowpasswordSignin.CheckState == CheckState.Checked)
            {
                txtPasswordSignin.PasswordChar = '\0'; // '\0' là ký tự rỗng
            }
            else
            {
                txtPasswordSignin.PasswordChar = '●';
            }
        }

        private void cbshowpasswordSignin_CheckStateChanged(object sender, EventArgs e)
        {
            if (cbshowpasswordSignin.Checked)
            {

                txtPasswordSignin.UseSystemPasswordChar = true;
            }
            else
            {

                txtPasswordSignin.UseSystemPasswordChar = false;
            }
        }
    }

}
