﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store_Gold
{
    public class Product
    {
        public string productID;
        public string productName;
        public DateTime dateIn;
        public DateTime dateOut;
        public int quantity;
        public double mace;
        public Category category = new Category();
        public double price;
        public Product()
        {
        }
        public Product(string productID, string productName, Category category, DateTime dateIn, DateTime dateOut, int quantity, double mace)
        {
            this.productID = productID;
            this.productName = productName;
            this.category = category;
            this.dateIn = dateIn;
            this.dateOut = dateOut;
            this.quantity = quantity;
            this.mace = mace;
        }
    }
}
