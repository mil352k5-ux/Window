﻿namespace Store_Gold
{
    partial class FPaying
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            dgCustomer = new DataGridView();
            dgProduct = new DataGridView();
            dgBill = new DataGridView();
            lblBill = new Label();
            lblCustomer = new Label();
            lblProduct = new Label();
            btnPrint = new Guna.UI2.WinForms.Guna2Button();
            panel1 = new Panel();
            btnAddBill = new Guna.UI2.WinForms.Guna2Button();
            txtPrice = new Guna.UI2.WinForms.Guna2TextBox();
            lblPrice = new Label();
            guna2TextBox2 = new Guna.UI2.WinForms.Guna2TextBox();
            lblLabour = new Label();
            txtQuantity = new Guna.UI2.WinForms.Guna2TextBox();
            lblQuantity = new Label();
            cbCategory = new Guna.UI2.WinForms.Guna2ComboBox();
            lblCategory = new Label();
            guna2TextBox1 = new Guna.UI2.WinForms.Guna2TextBox();
            lblCustomerName = new Label();
            txtProductName = new Guna.UI2.WinForms.Guna2TextBox();
            lblProductName = new Label();
            ((System.ComponentModel.ISupportInitialize)dgCustomer).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgProduct).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgBill).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // dgCustomer
            // 
            dgCustomer.BackgroundColor = Color.White;
            dgCustomer.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgCustomer.Location = new Point(60, 461);
            dgCustomer.Name = "dgCustomer";
            dgCustomer.RowHeadersWidth = 51;
            dgCustomer.RowTemplate.Height = 29;
            dgCustomer.Size = new Size(568, 279);
            dgCustomer.TabIndex = 0;
            // 
            // dgProduct
            // 
            dgProduct.BackgroundColor = Color.White;
            dgProduct.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgProduct.Location = new Point(655, 461);
            dgProduct.Name = "dgProduct";
            dgProduct.RowHeadersWidth = 51;
            dgProduct.RowTemplate.Height = 29;
            dgProduct.Size = new Size(568, 279);
            dgProduct.TabIndex = 1;
            // 
            // dgBill
            // 
            dgBill.BackgroundColor = Color.White;
            dgBill.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgBill.GridColor = Color.White;
            dgBill.Location = new Point(655, 54);
            dgBill.Name = "dgBill";
            dgBill.RowHeadersWidth = 51;
            dgBill.RowTemplate.Height = 29;
            dgBill.Size = new Size(568, 261);
            dgBill.TabIndex = 2;
            // 
            // lblBill
            // 
            lblBill.AutoSize = true;
            lblBill.Font = new Font("SFU Futura", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblBill.ForeColor = Color.DarkCyan;
            lblBill.Location = new Point(916, 16);
            lblBill.Name = "lblBill";
            lblBill.Size = new Size(60, 35);
            lblBill.TabIndex = 3;
            lblBill.Text = "BILL";
            // 
            // lblCustomer
            // 
            lblCustomer.AutoSize = true;
            lblCustomer.Font = new Font("SFU Futura", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblCustomer.ForeColor = Color.DarkCyan;
            lblCustomer.Location = new Point(260, 408);
            lblCustomer.Name = "lblCustomer";
            lblCustomer.Size = new Size(127, 35);
            lblCustomer.TabIndex = 4;
            lblCustomer.Text = "Customer";
            // 
            // lblProduct
            // 
            lblProduct.AutoSize = true;
            lblProduct.Font = new Font("SFU Futura", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblProduct.ForeColor = Color.DarkCyan;
            lblProduct.Location = new Point(876, 408);
            lblProduct.Name = "lblProduct";
            lblProduct.Size = new Size(105, 35);
            lblProduct.TabIndex = 5;
            lblProduct.Text = "Product";
            // 
            // btnPrint
            // 
            btnPrint.BorderRadius = 20;
            btnPrint.CustomizableEdges = customizableEdges1;
            btnPrint.DisabledState.BorderColor = Color.DarkGray;
            btnPrint.DisabledState.CustomBorderColor = Color.DarkGray;
            btnPrint.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnPrint.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnPrint.FillColor = Color.DarkCyan;
            btnPrint.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnPrint.ForeColor = Color.White;
            btnPrint.Location = new Point(1089, 331);
            btnPrint.Name = "btnPrint";
            btnPrint.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnPrint.Size = new Size(134, 51);
            btnPrint.TabIndex = 6;
            btnPrint.Text = "Print";
            // 
            // panel1
            // 
            panel1.BackColor = Color.Azure;
            panel1.Controls.Add(btnAddBill);
            panel1.Controls.Add(txtPrice);
            panel1.Controls.Add(lblPrice);
            panel1.Controls.Add(guna2TextBox2);
            panel1.Controls.Add(lblLabour);
            panel1.Controls.Add(txtQuantity);
            panel1.Controls.Add(lblQuantity);
            panel1.Controls.Add(cbCategory);
            panel1.Controls.Add(lblCategory);
            panel1.Controls.Add(guna2TextBox1);
            panel1.Controls.Add(lblCustomerName);
            panel1.Controls.Add(txtProductName);
            panel1.Controls.Add(lblProductName);
            panel1.Location = new Point(60, 54);
            panel1.Name = "panel1";
            panel1.Size = new Size(568, 328);
            panel1.TabIndex = 7;
            // 
            // btnAddBill
            // 
            btnAddBill.BorderRadius = 20;
            btnAddBill.CustomizableEdges = customizableEdges3;
            btnAddBill.DisabledState.BorderColor = Color.DarkGray;
            btnAddBill.DisabledState.CustomBorderColor = Color.DarkGray;
            btnAddBill.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnAddBill.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnAddBill.FillColor = Color.DarkCyan;
            btnAddBill.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnAddBill.ForeColor = Color.White;
            btnAddBill.Location = new Point(200, 260);
            btnAddBill.Name = "btnAddBill";
            btnAddBill.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btnAddBill.Size = new Size(134, 51);
            btnAddBill.TabIndex = 8;
            btnAddBill.Text = "Add Bill";
            // 
            // txtPrice
            // 
            txtPrice.BorderColor = Color.DarkCyan;
            txtPrice.BorderRadius = 10;
            txtPrice.CustomizableEdges = customizableEdges5;
            txtPrice.DefaultText = "";
            txtPrice.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPrice.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPrice.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPrice.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPrice.FillColor = Color.Azure;
            txtPrice.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPrice.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtPrice.ForeColor = Color.Black;
            txtPrice.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPrice.Location = new Point(338, 192);
            txtPrice.Name = "txtPrice";
            txtPrice.PasswordChar = '\0';
            txtPrice.PlaceholderText = "";
            txtPrice.SelectedText = "";
            txtPrice.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtPrice.Size = new Size(176, 37);
            txtPrice.TabIndex = 11;
            // 
            // lblPrice
            // 
            lblPrice.AutoSize = true;
            lblPrice.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblPrice.Location = new Point(338, 163);
            lblPrice.Name = "lblPrice";
            lblPrice.Size = new Size(53, 25);
            lblPrice.TabIndex = 10;
            lblPrice.Text = "Price";
            // 
            // guna2TextBox2
            // 
            guna2TextBox2.BorderColor = Color.DarkCyan;
            guna2TextBox2.BorderRadius = 10;
            guna2TextBox2.CustomizableEdges = customizableEdges7;
            guna2TextBox2.DefaultText = "";
            guna2TextBox2.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            guna2TextBox2.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            guna2TextBox2.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox2.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox2.FillColor = Color.Azure;
            guna2TextBox2.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2TextBox2.ForeColor = Color.Black;
            guna2TextBox2.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox2.Location = new Point(338, 114);
            guna2TextBox2.Name = "guna2TextBox2";
            guna2TextBox2.PasswordChar = '\0';
            guna2TextBox2.PlaceholderText = "";
            guna2TextBox2.SelectedText = "";
            guna2TextBox2.ShadowDecoration.CustomizableEdges = customizableEdges8;
            guna2TextBox2.Size = new Size(176, 37);
            guna2TextBox2.TabIndex = 9;
            // 
            // lblLabour
            // 
            lblLabour.AutoSize = true;
            lblLabour.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblLabour.Location = new Point(338, 86);
            lblLabour.Name = "lblLabour";
            lblLabour.Size = new Size(109, 25);
            lblLabour.TabIndex = 8;
            lblLabour.Text = "Labour cost";
            // 
            // txtQuantity
            // 
            txtQuantity.BorderColor = Color.DarkCyan;
            txtQuantity.BorderRadius = 10;
            txtQuantity.CustomizableEdges = customizableEdges9;
            txtQuantity.DefaultText = "";
            txtQuantity.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtQuantity.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtQuantity.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtQuantity.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtQuantity.FillColor = Color.Azure;
            txtQuantity.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtQuantity.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtQuantity.ForeColor = Color.Black;
            txtQuantity.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtQuantity.Location = new Point(338, 38);
            txtQuantity.Name = "txtQuantity";
            txtQuantity.PasswordChar = '\0';
            txtQuantity.PlaceholderText = "";
            txtQuantity.SelectedText = "";
            txtQuantity.ShadowDecoration.CustomizableEdges = customizableEdges10;
            txtQuantity.Size = new Size(176, 37);
            txtQuantity.TabIndex = 7;
            txtQuantity.TextChanged += txtQuantity_TextChanged;
            // 
            // lblQuantity
            // 
            lblQuantity.AutoSize = true;
            lblQuantity.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblQuantity.Location = new Point(338, 10);
            lblQuantity.Name = "lblQuantity";
            lblQuantity.Size = new Size(85, 25);
            lblQuantity.TabIndex = 6;
            lblQuantity.Text = "Quantity";
            // 
            // cbCategory
            // 
            cbCategory.BackColor = Color.Transparent;
            cbCategory.BorderColor = Color.DarkCyan;
            cbCategory.BorderRadius = 10;
            cbCategory.CustomizableEdges = customizableEdges11;
            cbCategory.DrawMode = DrawMode.OwnerDrawFixed;
            cbCategory.DropDownStyle = ComboBoxStyle.DropDownList;
            cbCategory.FillColor = Color.Azure;
            cbCategory.FocusedColor = Color.FromArgb(94, 148, 255);
            cbCategory.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            cbCategory.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            cbCategory.ForeColor = Color.FromArgb(68, 88, 112);
            cbCategory.ItemHeight = 30;
            cbCategory.Location = new Point(17, 192);
            cbCategory.Name = "cbCategory";
            cbCategory.ShadowDecoration.CustomizableEdges = customizableEdges12;
            cbCategory.Size = new Size(250, 36);
            cbCategory.TabIndex = 5;
            // 
            // lblCategory
            // 
            lblCategory.AutoSize = true;
            lblCategory.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblCategory.Location = new Point(17, 163);
            lblCategory.Name = "lblCategory";
            lblCategory.Size = new Size(92, 25);
            lblCategory.TabIndex = 4;
            lblCategory.Text = "Category:";
            // 
            // guna2TextBox1
            // 
            guna2TextBox1.BorderColor = Color.DarkCyan;
            guna2TextBox1.BorderRadius = 10;
            guna2TextBox1.CustomizableEdges = customizableEdges13;
            guna2TextBox1.DefaultText = "";
            guna2TextBox1.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            guna2TextBox1.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            guna2TextBox1.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox1.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            guna2TextBox1.FillColor = Color.Azure;
            guna2TextBox1.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            guna2TextBox1.ForeColor = Color.Black;
            guna2TextBox1.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            guna2TextBox1.Location = new Point(17, 114);
            guna2TextBox1.Name = "guna2TextBox1";
            guna2TextBox1.PasswordChar = '\0';
            guna2TextBox1.PlaceholderText = "";
            guna2TextBox1.SelectedText = "";
            guna2TextBox1.ShadowDecoration.CustomizableEdges = customizableEdges14;
            guna2TextBox1.Size = new Size(250, 37);
            guna2TextBox1.TabIndex = 3;
            // 
            // lblCustomerName
            // 
            lblCustomerName.AutoSize = true;
            lblCustomerName.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblCustomerName.Location = new Point(17, 86);
            lblCustomerName.Name = "lblCustomerName";
            lblCustomerName.Size = new Size(147, 25);
            lblCustomerName.TabIndex = 2;
            lblCustomerName.Text = "Customer Name";
            // 
            // txtProductName
            // 
            txtProductName.BorderColor = Color.DarkCyan;
            txtProductName.BorderRadius = 10;
            txtProductName.CustomizableEdges = customizableEdges15;
            txtProductName.DefaultText = "";
            txtProductName.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtProductName.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtProductName.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtProductName.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtProductName.FillColor = Color.Azure;
            txtProductName.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtProductName.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtProductName.ForeColor = Color.Black;
            txtProductName.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtProductName.ImeMode = ImeMode.NoControl;
            txtProductName.Location = new Point(17, 38);
            txtProductName.Name = "txtProductName";
            txtProductName.PasswordChar = '\0';
            txtProductName.PlaceholderText = "";
            txtProductName.SelectedText = "";
            txtProductName.ShadowDecoration.CustomizableEdges = customizableEdges16;
            txtProductName.Size = new Size(250, 37);
            txtProductName.TabIndex = 1;
            // 
            // lblProductName
            // 
            lblProductName.AutoSize = true;
            lblProductName.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblProductName.Location = new Point(17, 10);
            lblProductName.Name = "lblProductName";
            lblProductName.Size = new Size(132, 25);
            lblProductName.TabIndex = 0;
            lblProductName.Text = "Product Name";
            // 
            // FPaying
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1290, 767);
            Controls.Add(panel1);
            Controls.Add(btnPrint);
            Controls.Add(lblProduct);
            Controls.Add(lblCustomer);
            Controls.Add(lblBill);
            Controls.Add(dgBill);
            Controls.Add(dgProduct);
            Controls.Add(dgCustomer);
            FormBorderStyle = FormBorderStyle.None;
            Name = "FPaying";
            Text = "FPaying";
            ((System.ComponentModel.ISupportInitialize)dgCustomer).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgProduct).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgBill).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgCustomer;
        private DataGridView dgProduct;
        private DataGridView dgBill;
        private Label lblBill;
        private Label lblCustomer;
        private Label lblProduct;
        private Guna.UI2.WinForms.Guna2Button btnPrint;
        private Panel panel1;
        private Guna.UI2.WinForms.Guna2TextBox txtProductName;
        private Label lblProductName;
        private Guna.UI2.WinForms.Guna2TextBox txtQuantity;
        private Label lblQuantity;
        private Guna.UI2.WinForms.Guna2ComboBox cbCategory;
        private Label lblCategory;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox1;
        private Label lblCustomerName;
        private Guna.UI2.WinForms.Guna2Button btnAddBill;
        private Guna.UI2.WinForms.Guna2TextBox txtPrice;
        private Label lblPrice;
        private Guna.UI2.WinForms.Guna2TextBox guna2TextBox2;
        private Label lblLabour;
    }
}