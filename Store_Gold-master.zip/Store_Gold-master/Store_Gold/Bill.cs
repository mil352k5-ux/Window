﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store_Gold
{
    public class Bill
    {
        string billid;
        string customerid;
        string staffid;
        string productid;
        decimal totalcost;
        int quantity_product;
        DateTime datebuy;
        public string Billid 
        { 
            get { return billid; }
            set { billid = value; } 
        }
        public string Customerid
        { 
            get { return customerid; } 
            set { customerid = value; }
        }
        public string Staffid
        {
            get { return staffid; }
            set { staffid = value; }
        }
        public string Productid
        {
            get { return productid; }
            set { productid = value; }
        }
        public decimal Totalcost
        { 
            get { return totalcost; }
            set { totalcost = value; } 
        }

        public DateTime Datebuy
        {
            get { return datebuy; } 
            set { datebuy = value; }
        }

        public int Quantity_product 
        {
            get { return quantity_product; }
            set { quantity_product = value; } 
        }

        public Bill(string Billid , string Customerid , string Staffid , string Productid,Decimal Totalcost , DateTime Datebuy, int Quantity_product)
        {
            this.Billid = Billid;
            this.Customerid = Customerid;
            this.Staffid = Staffid;
            this.Productid = Productid;
            this.Datebuy = Datebuy;
            this.Quantity_product = Quantity_product;
            this.Totalcost = Totalcost;
         
                 
        }
        public Bill ()
        { }

    }
}
