﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Store_Gold
{
    public class PersonDAO
    {
        DBConnection db = new DBConnection();
        Person person = new Person();
        public string tableName;
        public PersonDAO()
        {

        }
        public PersonDAO(Person person)
        {
            this.person = person;
        }
        public bool IsValidMail()
        {
            try
            {
                MailAddress m = new MailAddress(person.Email);
                return true;
            }
            catch (FormatException)
            {
                return false;
            }
        }

        public virtual DataTable Load()
        {
            string SQL = string.Format("SELECT * FROM " + tableName);
            DataTable dt = db.Load(SQL);
            return dt;
        }
        //Check id hoc sinh khong bi trung
        public bool CheckID()
        {
            string lenhSQL = string.Format("SELECT * FROM " + tableName + " WHERE customer_id = '{0}'", person.CMND);
            DataTable resultTable = db.Load(lenhSQL);
            if (resultTable.Rows.Count > 0)
                return false;
            return true;
        }
        public bool IsValidID()
        {
            foreach (Char r in person.CMND)
            {
                if (!Char.IsDigit(r))
                {
                    return false;
                }
            }

            return true;
        }
        public bool IsValidPhone()
        {
            if (person.PhoneNumber.Length != 12)
                return false;
            for (int i = 0; i < 12; i++)
            {
                if ((i == 3 || i == 8) && person.PhoneNumber[i] != '-')
                    return false;
                if ((i != 3 && i != 8) && (person.PhoneNumber[i] < '0' || person.PhoneNumber[i] > '9'))
                    return false;
            }
            return true;
        }
        public virtual void Add()
        {
            if (CheckID() == false)
            {
                MessageBox.Show("MaKH is used.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (!IsValidMail())
            {
                MessageBox.Show("Mail is not valid.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (!IsValidID())
            {
                MessageBox.Show("MaKH is not valid.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (!IsValidPhone())
            {
                MessageBox.Show("Your phone is not valid", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    SqlParameter[] parameters =
                    {
                new SqlParameter("@NewCustomer_id", SqlDbType.VarChar, 10) { Value = person.CMND },
                new SqlParameter("@NewCustomer_Name", SqlDbType.VarChar, 50) { Value = person.FullName },
                new SqlParameter("@NewCustomer_Address", SqlDbType.VarChar, 100) { Value = person.Address },
                new SqlParameter("@NewCustomer_Phone", SqlDbType.VarChar, 50) { Value = person.PhoneNumber },
                new SqlParameter("@NewCustomer_Birthday", SqlDbType.Date) { Value = person.Birthday },
                new SqlParameter("@NewCustomer_Email", SqlDbType.VarChar, 50) { Value = person.Email }
            };

                    // Thực thi stored procedure
                    db.ExecuteProcedure("AddCustomer3", parameters); // Đã sửa tên stored procedure thành "AddCustomer"
                    MessageBox.Show("Customer added successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    // Hiển thị thông điệp lỗi khi có lỗi xảy ra
                    MessageBox.Show("An error occurred while adding the customer: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        public virtual void Delete()
        {
            
            // Tiến hành xóa nếu khách hàng tồn tại
            try
            {
                // Thực thi stored procedure để xóa khách hàng
                SqlParameter[] parameters =
                {
            new SqlParameter("@Customer_id", SqlDbType.VarChar, 10) { Value = person.CMND }
        };
                db.ExecuteProcedure("DeleteCustomer2", parameters);

                MessageBox.Show("Customer deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                // Hiển thị thông điệp lỗi khi có lỗi xảy ra
                MessageBox.Show("An error occurred while deleting the customer: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public virtual void Update()
        {
            if (!IsValidMail())
            {
                MessageBox.Show("Mail is not valid.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (!IsValidID())
            {
                MessageBox.Show("MaKH is not valid.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (!IsValidPhone())
            {
                MessageBox.Show("Your phone is not valid", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                try
                {
                    SqlParameter[] parameters =
                    {
                new SqlParameter("@Customer_id", SqlDbType.VarChar, 10) { Value = person.CMND },
                new SqlParameter("@NewCustomer_Name", SqlDbType.VarChar, 50) { Value = person.FullName },
                new SqlParameter("@NewCustomer_Address", SqlDbType.VarChar, 100) { Value = person.Address },
                new SqlParameter("@NewCustomer_Phone", SqlDbType.VarChar, 50) { Value = person.PhoneNumber },
                new SqlParameter("@NewCustomer_Birthday", SqlDbType.Date) { Value = person.Birthday },
                new SqlParameter("@NewCustomer_Email", SqlDbType.VarChar, 50) { Value = person.Email }
            };

                    db.ExecuteProcedure("EditCustomer1", parameters); 
                    MessageBox.Show("Customer updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    // Hiển thị thông điệp lỗi khi có lỗi xảy ra
                    MessageBox.Show("An error occurred while updating the customer: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        public virtual bool CheckInforValid()
        {
            if (string.IsNullOrEmpty(person.FullName) || string.IsNullOrEmpty(person.Address) || string.IsNullOrEmpty(person.PhoneNumber)
                 || string.IsNullOrEmpty(person.Email) || string.IsNullOrEmpty(person.CMND))
            {
                MessageBox.Show("Have empty textbox. Please input the data!!", "Warnning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }
    }
}
