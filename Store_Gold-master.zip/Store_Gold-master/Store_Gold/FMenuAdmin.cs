﻿using Guna.UI2.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Store_Gold
{
    public partial class FMenuAdmin : Form
    {
        private Button currentButton;
        private Random random;
        private int tempIndex;
        private Form activeForm;
        public FMenuAdmin()
        {
            InitializeComponent();
            random = new Random();
            ucMenuadmin1.panelAccount.MouseHover += ucMenuadmin1.panelAccount_MouseHover;
            GetInforItem();
            ucMenuadmin1.btnbutton1.Click += btnHomepage_Click;
            ucMenuadmin1.btnbutton2.Click += btnManageCustomer_Click;
            ucMenuadmin1.btnbutton3.Click += btnManageProduct_Click;
            ucMenuadmin1.btnbutton4.Click += btnManageSupplier_Click;
            ucMenuadmin1.btnbutton5.Click += btnManageListProduct_Click;
            ucMenuadmin1.btnbutton6.Click += btnManageBill_Click;
        }
        private void Btnbutton5_Click(object? sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void GetInforItem()
        {
            ucMenuadmin1.lblNameAccount.Text = "Xin chào, " + Form1.currentAccount.UserName;
            ucMenuadmin1.btnbutton1.Text = "HOME";
            ucMenuadmin1.btnbutton2.Text = "CUSTOMER";
            ucMenuadmin1.btnbutton3.Text = "PRODUCT";
            ucMenuadmin1.btnbutton4.Text = "SUPPLIER";
            ucMenuadmin1.btnbutton5.Text = "Order Product";
            ucMenuadmin1.btnbutton6.Text = "Bill";
        }
        private Color SelectThemeColor()
        {
            int index = random.Next(ThemeColor.ColorList.Count);
            while (tempIndex == index)
            {
                index = random.Next(ThemeColor.ColorList.Count);

            }
            tempIndex = index;
            string color = ThemeColor.ColorList[index];
            return ColorTranslator.FromHtml(color);
        }
        private void ActivateButton(object btnsender)
        {
            if (btnsender != null)
            {
                if (currentButton != (Button)btnsender)
                {
                    DisableButton();
                    //Color color = SelectThemeColor();
                    currentButton = (Button)btnsender;
                    //currentButton.BackColor = color;
                    currentButton.ForeColor = Color.White;
                    currentButton.Font = new Font("Century Gothic", 11.5F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
                }
            }
        }
        private void DisableButton()
        {
            foreach (Control previousBtn in ucMenuadmin1.panelbtnmenu.Controls)
            {
                if (previousBtn.GetType() == typeof(Button))
                {
                    previousBtn.BackColor = Color.White;
                    previousBtn.ForeColor = Color.Gainsboro;
                    previousBtn.Font = new Font("Segoe UI", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
                }
            }
        }
        private void OpenChildForm(Form childForm, object btnSender)
        {
            if (activeForm != null)
                activeForm.Close();
            ActivateButton(btnSender);
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            ucMenuadmin1.panelDesktoppane.Controls.Add(childForm);
            ucMenuadmin1.panelDesktoppane.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }
        private void btnHomepage_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FHome(), sender);
        }
        private void btnManageCustomer_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FManageCustomer(), sender);
        }
        private void btnManageProduct_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FManageProduct(), sender);
        }

        private void btnManageSupplier_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FSupplier(), sender);
        }
        private void btnManageListProduct_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FListProduct(), sender);
        }
        private void btnManageBill_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FManageBill(), sender);
        }
    }
}
