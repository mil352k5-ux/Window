﻿namespace Store_Gold
{
    partial class FforgotPassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panelResetPassword = new Panel();
            btnsendmypassword = new Guna.UI2.WinForms.Guna2Button();
            txtResetPassword = new Guna.UI2.WinForms.Guna2TextBox();
            paneltitleRSPW = new Panel();
            lblsubtitleofRSPW = new Label();
            label1 = new Label();
            pblogoresetpassword = new PictureBox();
            epResetpassword = new Guna.UI2.WinForms.Guna2Elipse(components);
            panelResetPassword.SuspendLayout();
            paneltitleRSPW.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pblogoresetpassword).BeginInit();
            SuspendLayout();
            // 
            // panelResetPassword
            // 
            panelResetPassword.BackColor = Color.Linen;
            panelResetPassword.Controls.Add(btnsendmypassword);
            panelResetPassword.Controls.Add(txtResetPassword);
            panelResetPassword.Controls.Add(paneltitleRSPW);
            panelResetPassword.Controls.Add(pblogoresetpassword);
            panelResetPassword.Location = new Point(181, 120);
            panelResetPassword.Name = "panelResetPassword";
            panelResetPassword.Size = new Size(835, 530);
            panelResetPassword.TabIndex = 0;
            panelResetPassword.Paint += panelResetPassword_Paint;
            // 
            // btnsendmypassword
            // 
            btnsendmypassword.BackColor = Color.Thistle;
            btnsendmypassword.CustomizableEdges = customizableEdges1;
            btnsendmypassword.DisabledState.BorderColor = Color.DarkGray;
            btnsendmypassword.DisabledState.CustomBorderColor = Color.DarkGray;
            btnsendmypassword.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnsendmypassword.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnsendmypassword.FillColor = Color.Thistle;
            btnsendmypassword.Font = new Font("Century Gothic", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            btnsendmypassword.ForeColor = Color.White;
            btnsendmypassword.Location = new Point(298, 297);
            btnsendmypassword.Name = "btnsendmypassword";
            btnsendmypassword.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnsendmypassword.Size = new Size(237, 56);
            btnsendmypassword.TabIndex = 3;
            btnsendmypassword.Text = "Send my password";
            btnsendmypassword.Click += btnsendmypassword_Click;
            // 
            // txtResetPassword
            // 
            txtResetPassword.BorderRadius = 20;
            txtResetPassword.CustomizableEdges = customizableEdges3;
            txtResetPassword.DefaultText = "Email address";
            txtResetPassword.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtResetPassword.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtResetPassword.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtResetPassword.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtResetPassword.FillColor = SystemColors.Window;
            txtResetPassword.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtResetPassword.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtResetPassword.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtResetPassword.Location = new Point(298, 246);
            txtResetPassword.Name = "txtResetPassword";
            txtResetPassword.PasswordChar = '\0';
            txtResetPassword.PlaceholderText = "";
            txtResetPassword.SelectedText = "";
            txtResetPassword.ShadowDecoration.CustomizableEdges = customizableEdges4;
            txtResetPassword.Size = new Size(250, 45);
            txtResetPassword.TabIndex = 2;
            // 
            // paneltitleRSPW
            // 
            paneltitleRSPW.Controls.Add(lblsubtitleofRSPW);
            paneltitleRSPW.Controls.Add(label1);
            paneltitleRSPW.Location = new Point(209, 177);
            paneltitleRSPW.Name = "paneltitleRSPW";
            paneltitleRSPW.Size = new Size(434, 63);
            paneltitleRSPW.TabIndex = 1;
            // 
            // lblsubtitleofRSPW
            // 
            lblsubtitleofRSPW.AutoSize = true;
            lblsubtitleofRSPW.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblsubtitleofRSPW.Location = new Point(0, 34);
            lblsubtitleofRSPW.Name = "lblsubtitleofRSPW";
            lblsubtitleofRSPW.Size = new Size(339, 21);
            lblsubtitleofRSPW.TabIndex = 1;
            lblsubtitleofRSPW.Text = "YOU CAN RESET YOUR PASSWORD HERE";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(0, 0);
            label1.Name = "label1";
            label1.Size = new Size(438, 34);
            label1.TabIndex = 0;
            label1.Text = "YOU FOGOT YOUR PASSWORD?";
            // 
            // pblogoresetpassword
            // 
            //pblogoresetpassword.Image = Properties.Resources.reset_password;
            pblogoresetpassword.Location = new Point(321, 18);
            pblogoresetpassword.Name = "pblogoresetpassword";
            pblogoresetpassword.Size = new Size(199, 153);
            pblogoresetpassword.SizeMode = PictureBoxSizeMode.StretchImage;
            pblogoresetpassword.TabIndex = 0;
            pblogoresetpassword.TabStop = false;
            // 
            // epResetpassword
            // 
            epResetpassword.BorderRadius = 100;
            epResetpassword.TargetControl = panelResetPassword;
            // 
            // FforgotPassword
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1182, 853);
            Controls.Add(panelResetPassword);
            Name = "FforgotPassword";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FforgotPassword";
            panelResetPassword.ResumeLayout(false);
            paneltitleRSPW.ResumeLayout(false);
            paneltitleRSPW.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pblogoresetpassword).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelResetPassword;
        private Panel paneltitleRSPW;
        private Label lblsubtitleofRSPW;
        private Label label1;
        private PictureBox pblogoresetpassword;
        private Guna.UI2.WinForms.Guna2Button btnsendmypassword;
        private Guna.UI2.WinForms.Guna2TextBox txtResetPassword;
        private Guna.UI2.WinForms.Guna2Elipse epResetpassword;
    }
}