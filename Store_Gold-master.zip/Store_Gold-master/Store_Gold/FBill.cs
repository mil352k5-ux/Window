﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Store_Gold
{
    public partial class FBill : Form
    {
        public static Bill currentBill = new Bill();

        public FBill()
        {
            InitializeComponent();
        }
        private void FBill_Load(object sender, EventArgs e)
        {
            lblStaffID.Text = Form1.currentStaff.CMND;
            lblStaffName.Text = Form1.currentStaff.FullName;
            lblCustomerID.Text = FDetailCustomerInformation.currentcustomer.CMND;
            lblCustomerName.Text = FDetailCustomerInformation.currentcustomer.FullName;
            ProductDAO productDao = new ProductDAO();
            dgvSeletedProducts.DataSource = productDao.GetSelectedProducts();
            dgvSeletedProducts.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }
        private void panelBill1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnAddbill_Click(object sender, EventArgs e)
        {
            string productID = FListProduct.selectedProduct.productID;
            string billID = txtIDBill.Text;
            string customerID = FDetailCustomerInformation.currentcustomer.CMND;
            string staffID = lblStaffID.Text;
            int quantity = currentBill.Quantity_product; 
            decimal cost = ((decimal)FListProduct.selectedProduct.price) * quantity;
            DateTime datebuy = dtpBill.Value;

            currentBill = new Bill()
            {
                Billid = billID,
                Productid = productID,
                Customerid = customerID,
                Staffid = staffID,
                Totalcost = cost,
                Quantity_product = quantity,
                Datebuy = datebuy
            };

            BillDAO billDao = new BillDAO();
            billDao.Add(billID, productID, customerID, staffID, cost, quantity,datebuy);
            this.Hide();
            FPrintBill subbill = new FPrintBill();
            subbill.ShowDialog();
        }

    }
}
