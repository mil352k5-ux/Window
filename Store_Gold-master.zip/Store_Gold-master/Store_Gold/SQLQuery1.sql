﻿
CREATE TRIGGER CreateSQLAccount_OnInsert
ON LOGININFO
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @UserID VARCHAR(10);
    DECLARE @Password VARCHAR(20);
    DECLARE @sqlString NVARCHAR(2000);
    -- Chọn thông tin tài khoản từ bản ghi được chèn vào
    SELECT @UserID = inserted.UserID, @Password = inserted.Password
    FROM inserted;

    -- Tạo tài khoản login cho người dùng
    SET @sqlString = 'CREATE LOGIN [' + @UserID +'] WITH PASSWORD='''+ @Password +''', 
			DEFAULT_DATABASE=[Store_gold], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF';
	EXEC (@sqlString);

	-- Tạo tài khoản người dùng đối với người dùng đó trên database
	SET @sqlString = 'CREATE USER ' + @UserID +' FOR LOGIN '+ @UserID;
	EXEC (@sqlString);

    PRINT ('Tài khoản SQL đã được tạo thành công.');
END;


Create TRIGGER [dbo].[CreateSQLAccount] ON [dbo].[LOGININFO]   -- triger tạo tài khoản hệ thống
AFTER INSERT 
AS  
DECLARE @userName nvarchar(30), @passWord nvarchar(10) 
SELECT @userName=nl.username, @passWord=nl.password 
FROM inserted nl 
BEGIN 
 DECLARE @sqlString nvarchar(2000) 
 SET @sqlString= 'CREATE LOGIN [' + @userName +'] WITH PASSWORD='''+ @passWord 
+''', DEFAULT_DATABASE=[Store_gold], CHECK_EXPIRATION=OFF, 
CHECK_POLICY=OFF' 
 EXEC (@sqlString) 
 SET @sqlString= 'CREATE USER ' + @userName +' FOR LOGIN '+ @userName 
 EXEC (@sqlString) 
END

CREATE TRIGGER CreateProductAfterSupplierProvides
ON PROVIDES
AFTER INSERT
AS
BEGIN
    -- Insert new products into PRODUCT table based on the provided supplies
    INSERT INTO PRODUCT (Product_ID, Product_Name, Category_ID, Date_In, Quantity, Mass, Bill_ID, customer_id, Staff_ID)
    SELECT i.Product_ID, s.Product_Name, c.Category_ID, GETDATE(), 0, 0.0, NULL, NULL, NULL
    FROM inserted i
    INNER JOIN SUPPLIER s ON i.Supplier_ID = s.Supplier_ID
    INNER JOIN CATEGORY c ON s.Product_ID = c.Product_ID;
END;
--------------------------------------------------------------------
GO

DROP TRIGGER create_Login_staff;
GO 
CREATE TRIGGER create_Login_staff
ON staff
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @Staff_id VARCHAR(10);
    DECLARE @Staff_name_login VARCHAR(10);
    DECLARE @pass_login VARCHAR(30);
    Declare @sqlString varchar(1000);

    SELECT @Staff_id = inserted.Staff_ID FROM inserted;
    SET @Staff_name_login = CONCAT('EMP', RIGHT(@Staff_id, 3));
    SET @pass_login = '123456';

    INSERT INTO LOGININFO (UserID, Password, UserName)
    VALUES (@Staff_id, @pass_login, @Staff_name_login);
    SET @sqlString = 'ALTER ROLE '+'StaffRolene3' +' ADD MEMBER ' + @Staff_name_login; 
   exec (@sqlString) 
    PRINT ('Successful');
END;
GO
-----------------------------------------------------
GO
CREATE TRIGGER create_Login_admin
ON Admin
AFTER INSERT
AS 
BEGIN
    SET NOCOUNT ON;

    DECLARE @Admin_id VARCHAR(10);
    DECLARE @Admin_name_login VARCHAR(10);
    DECLARE @pass_login VARCHAR(30);
    Declare @sqlString varchar(1000);
    
    -- Lấy giá trị của admin mới được chèn vào
    SELECT @Admin_id = inserted.admin_id FROM inserted;
    -- Tạo tên đăng nhập cho admin
    SET @Admin_name_login = CONCAT('ADM', RIGHT(@Admin_id, 3));
    SET @pass_login = '0123';
    -- Tiến hành chèn dữ liệu vào bảng LOGININFO với UserType là 'A'
    INSERT INTO LOGININFO (UserID, Password, UserName)
    VALUES (@Admin_id, @pass_login, @Admin_name_login);

    SET @sqlString = 'ALTER SERVER ROLE '+'sysadmin'+' ADD MEMBER ' + 
@Admin_name_login;  
    exec (@sqlString) 
    PRINT ('Tài khoản quản trị đã được tạo thành công.');
END;
GO
------------------------
CREATE TRIGGER UpdateTransactionHistory    -- update history of bill ( create table history)
ON BILL
AFTER INSERT
AS
BEGIN
    -- Insert a new record into TRANSACTION_HISTORY table for each inserted record in BILL table
    INSERT INTO TRANSACTION_HISTORY (Transaction_Date, Customer_ID, Staff_ID, Product_ID, Total_Amount)
    SELECT 
        GETDATE(), -- Current date
        inserted.customer_id,
        inserted.Staff_ID,
        inserted.Product_ID,
        inserted.Total_Amount
    FROM 
        inserted;
END;

CREATE TABLE staff (
    staff_ID VARCHAR(10) PRIMARY KEY,
    Staff_Name VARCHAR(50) NOT NULL,
    Staff_Address VARCHAR(100) NOT NULL,
    admin_id VARCHAR(10),
    FOREIGN KEY (admin_id) REFERENCES ADMIN(admin_id),

);

CREATE TABLE staff_phone (
    staff_ID VARCHAR(10),
    staff_Phone VARCHAR(50),
    admin_ID VARCHAR(10),
    FOREIGN KEY (staff_id) REFERENCES staff(staff_ID),
    FOREIGN KEY (admin_id) REFERENCES admin(admin_ID),
    PRIMARY KEY (staff_id, staff_Phone)
);
CREATE TABLE Staff_Email (
    staff_ID VARCHAR(10),
    staff_Email VARCHAR(50),
    admin_ID VARCHAR(10),
    FOREIGN KEY (staff_id) REFERENCES staff(Staff_ID),
    FOREIGN KEY (admin_id) REFERENCES admin(admin_id),
    PRIMARY KEY (Staff_ID, Staff_Email)
);

CREATE TABLE ADMIN (
    admin_id VARCHAR(10) PRIMARY KEY,
    Ad_Name VARCHAR(50) NOT NULL,
    Ad_Address VARCHAR(100) NOT NULL
 
);

CREATE TABLE ADMIN_Phone (
    admin_id VARCHAR(10),
    admin_phone VARCHAR(50) NOT NULL,
    FOREIGN KEY (admin_id) REFERENCES ADMIN(admin_id),
    PRIMARY KEY (admin_id, admin_phone)
);

CREATE TABLE ADMIN_Email (
    admin_id VARCHAR(10),
    admin_email VARCHAR(50) NOT NULL,
    FOREIGN KEY (admin_id) REFERENCES ADMIN(admin_id),
    PRIMARY KEY (admin_id, admin_email)
);
CREATE TABLE LOGININFO (
    UserID VARCHAR(10) PRIMARY KEY,
    Password VARCHAR(20) NOT NULL,
    UserName VARCHAR(20) NOT NULL,

);

CREATE TABLE CUSTOMER (
	customer_id VARCHAR(10) PRIMARY KEY,
    customer_name VARCHAR(50) NOT NULL,
    customer_address VARCHAR(100) NOT NULL,
	customer_birthday DATE
);
GO
CREATE TABLE customer_phone(
   customer_id VARCHAR(10),
   customer_phone VARCHAR(50),
    FOREIGN KEY (customer_id) REFERENCES CUSTOMER(customer_id),
    PRIMARY KEY (customer_id, Customer_Phone)
);
CREATE TABLE customer_email(
   customer_id VARCHAR(10),
   customer_email VARCHAR(50),
    FOREIGN KEY (customer_id) REFERENCES CUSTOMER(customer_id),
    PRIMARY KEY (customer_id, Customer_Email)
);

GO

CREATE TABLE PRODUCT (
    Product_ID VARCHAR(10) PRIMARY KEY,
    Product_Name VARCHAR(50) NOT NULL,
    Category_ID VARCHAR(10),
    Date_In DATE,
    Date_Out DATE,
    Quantity INT,
    Mace DECIMAL(10, 2),
    Bill_ID VARCHAR(10),
    customer_id VARCHAR(10),
    Staff_ID VARCHAR(10),
    Price Decimal(10,2),
    --FOREIGN KEY (Category_ID) REFERENCES CATEGORY(Category_ID),
    --FOREIGN KEY (Bill_ID) REFERENCES bill(Bill_ID),
    FOREIGN KEY (customer_id) REFERENCES CUSTOMER(customer_id),
    FOREIGN KEY (Staff_ID) REFERENCES STAFF(Staff_ID)
);
ALTER TABLE product ADD CONSTRAINT fk_categoryid_Product FOREIGN KEY (category_id) REFERENCES Category (category_id);
ALTER TABLE product ADD CONSTRAINT fk_billid_Product FOREIGN KEY (bill_id) REFERENCES bill (bill_id);

CREATE TABLE SelectedProduct (
    SelectedProductID INT PRIMARY KEY IDENTITY,
    ProductID VARCHAR(10) NOT NULL,
    ProductName VARCHAR(50) NOT NULL,
    CategoryID VARCHAR(10) NOT NULL,
    Price DECIMAL(10, 2) NOT NULL,
    BillID VARCHAR(10) NOT NULL,
    CONSTRAINT FK_SelectedProduct_ProductID FOREIGN KEY (ProductID) REFERENCES PRODUCT(Product_ID),
    CONSTRAINT FK_SelectedProduct_CategoryID FOREIGN KEY (CategoryID) REFERENCES CATEGORY(Category_ID),
);

CREATE TABLE CATEGORY (
    Category_ID VARCHAR(10) PRIMARY KEY,
    Category_Name VARCHAR(50) NOT NULL,
    Category_Price DECIMAL(10, 2)
);

CREATE TABLE SUPPLIER (
    Supplier_ID VARCHAR(10) PRIMARY KEY,
    Supplier_Name VARCHAR(50) NOT NULL,
    Supplier_Address VARCHAR(100),
    --FOREIGN KEY (Product_ID) REFERENCES PRODUCT(Product_ID)
);
ALTER TABLE supplier ADD CONSTRAINT fk_Productid_Supplier FOREIGN KEY (product_id) REFERENCES product (product_id);

CREATE TABLE SUPPLIER_Phone (
    Supplier_ID VARCHAR(10),
    Product_ID VARCHAR(10),
    Supplier_Phone VARCHAR(20),
    FOREIGN KEY (Supplier_ID) REFERENCES SUPPLIER(Supplier_ID),
    FOREIGN KEY (Product_ID) REFERENCES PRODUCT(Product_ID),
    PRIMARY KEY (Supplier_ID, Product_ID, Supplier_Phone)
);

CREATE TABLE SUPPLIER_Email (
    Supplier_ID VARCHAR(10),
    Product_ID VARCHAR(10),
    Supplier_Email VARCHAR(50),
    FOREIGN KEY (Supplier_ID) REFERENCES SUPPLIER(Supplier_ID),
    FOREIGN KEY (Product_ID) REFERENCES PRODUCT(Product_ID),
    PRIMARY KEY (Supplier_ID, Product_ID, Supplier_Email)
);

CREATE TABLE PROVIDES (
    Supplier_ID VARCHAR(10),
    Product_ID VARCHAR(10),
    FOREIGN KEY (Supplier_ID) REFERENCES SUPPLIER(Supplier_ID),
    FOREIGN KEY (Product_ID) REFERENCES PRODUCT(Product_ID),
    PRIMARY KEY (Supplier_ID, Product_ID)
);

CREATE TABLE BILL (
    Bill_ID VARCHAR(10) PRIMARY KEY,
    Product_ID VARCHAR(10),
    customer_id VARCHAR(10),
    Staff_ID VARCHAR(10),
    Total_cost DECIMAL(10, 2),
    Quantity_Product int,
    Date_buy Date,
    FOREIGN KEY (Product_ID) REFERENCES PRODUCT(Product_ID),
    FOREIGN KEY (Staff_ID) REFERENCES STAFF(Staff_ID)
);
-------------------------------- Procedure Customer 
go
CREATE PROCEDURE EditCustomer1
    @customer_id VARCHAR(10),
    @NewCustomer_Name VARCHAR(50),
    @NewCustomer_Address VARCHAR(100),
    @NewCustomer_Phone VARCHAR(100),
    @NewCustomer_Birthday DATE,
    @NewCustomer_Email VARCHAR(100)

AS
BEGIN
   -- Cập nhật thông tin trong bảng CUSTOMER
    UPDATE CUSTOMER
    SET customer_name = @NewCustomer_Name,
        customer_address = @NewCustomer_Address,
        customer_birthday = @NewCustomer_Birthday
    WHERE customer_id = @customer_id;

    -- Cập nhật số điện thoại trong bảng customer_phone
    UPDATE customer_phone
    SET customer_phone = @NewCustomer_Phone
    WHERE customer_id = @customer_id;

    -- Cập nhật email trong bảng customer_email
    UPDATE customer_email
    SET customer_email = @NewCustomer_Email
    WHERE customer_id = @customer_id;
    
END;
--------
go
CREATE PROCEDURE DeleteCustomer2
    @Customer_id VARCHAR(10)
AS
BEGIN
     DELETE FROM CUSTOMER
    WHERE customer_id = @Customer_id;

    DELETE FROM customer_phone
    WHERE customer_id = @Customer_id;

    DELETE FROM customer_email
    WHERE customer_id = @Customer_id;
END;
SELECT name
FROM sys.procedures
go
CREATE PROCEDURE AddCustomer3
    @NewCustomer_id VARCHAR(10),
    @NewCustomer_Name VARCHAR(50),
    @NewCustomer_Address VARCHAR(100),
    @NewCustomer_Phone VARCHAR(100),
    @NewCustomer_Birthday DATE,
    @NewCustomer_Email VARCHAR(100)  -- Assuming you have an email parameter

AS
BEGIN
    INSERT INTO CUSTOMER (customer_id, customer_name, customer_address, customer_birthday)
    VALUES (@NewCustomer_id, @NewCustomer_Name, @NewCustomer_Address, @NewCustomer_Birthday);

    -- Chèn dữ liệu mới vào bảng customer_phone
    INSERT INTO customer_phone (customer_id, customer_phone)
    VALUES (@NewCustomer_id, @NewCustomer_Phone);

    -- Chèn dữ liệu mới vào bảng customer_email
    INSERT INTO customer_email (customer_id, customer_email)
    VALUES (@NewCustomer_id, @NewCustomer_Email);
END;

GO
------------------------------------------------------------------
---procedure Product----
CREATE PROCEDURE AddProduct5
    @Product_ID VARCHAR(10),
    @Product_Name VARCHAR(50),
    @Category_ID VARCHAR(10),
    @Date_In DATE,
    @Date_Out DATE,
    @Quantity INT,
    @Mace DECIMAL(10, 2)
AS
BEGIN
    DECLARE @Price DECIMAL(10, 2);

    -- Lấy giá của loại sản phẩm từ bảng CATEGORY
    SELECT @Price = Category_Price
    FROM CATEGORY
    WHERE Category_ID = @Category_ID;

    -- Tính toán giá sản phẩm dựa trên mace và giá của loại sản phẩm
    SET @Price = @Price * @Mace;

    -- Chèn dữ liệu mới vào bảng PRODUCT
    INSERT INTO PRODUCT (Product_ID, Product_Name, Category_ID, Date_In, Date_Out, Quantity, Mace, Price)
    VALUES (@Product_ID, @Product_Name, @Category_ID, @Date_In, @Date_Out, @Quantity, @Mace, @Price);
END;
GO
--delete
CREATE PROCEDURE DeleteProduct
    @Product_ID VARCHAR(10)
AS
BEGIN
    DELETE FROM PRODUCT
    WHERE Product_ID = @Product_ID;
END;
GO
--update
CREATE PROCEDURE UpdateProduct7
    @Product_ID VARCHAR(10),
    @Product_Name VARCHAR(50),
    @Category_ID VARCHAR(10),
    @Date_In DATE,
    @Date_Out DATE,
    @Quantity INT,
    @Mace DECIMAL(10, 2)

AS
BEGIN
    -- Tính toán giá mới dựa trên giá trị mới của Mace
      DECLARE @Price DECIMAL(10, 2);

    -- Lấy giá của loại sản phẩm từ bảng CATEGORY
    SELECT @Price = Category_Price
    FROM CATEGORY
    WHERE Category_ID = @Category_ID;

    -- Tính toán giá sản phẩm dựa trên mace và giá của loại sản phẩm
    SET @Price = @Price * @Mace;
    -- Update các trường thông tin sản phẩm
    UPDATE PRODUCT
    SET Product_Name = @Product_Name,
        Category_ID = @Category_ID,
        Date_In = @Date_In,
        Date_Out = @Date_Out,
        Quantity = @Quantity,
        Mace = @Mace,
        Price = @Price
    WHERE Product_ID = @Product_ID;
END;
GO
---search Product
CREATE PROCEDURE SearchProduct1
    @SearchType VARCHAR(50),
    @SearchText VARCHAR(100)
AS
BEGIN
    IF @SearchType = 'Product_ID'
    BEGIN
        SELECT * FROM PRODUCT WHERE Product_ID = @SearchText;
    END
    ELSE IF @SearchType = 'Product_Name'
    BEGIN
        SELECT * FROM PRODUCT WHERE Product_Name LIKE '%' + @SearchText + '%';
    END
    ELSE IF @SearchType = 'Category_ID'
    BEGIN
        SELECT * FROM PRODUCT WHERE Category_ID = @SearchText;
    END
    ELSE IF @SearchType = 'Date_In'
    BEGIN
        SELECT * FROM PRODUCT WHERE Date_In = @SearchText;
    END
    ELSE IF @SearchType = 'None'  -- Thêm điều kiện mới
    BEGIN
        SELECT * FROM PRODUCT;  -- Hiển thị tất cả sản phẩm
    END
END;
GO
------------------------------------ searchFilter
CREATE PROCEDURE SearchFilter
    @CategoryName VARCHAR(50)
AS
BEGIN
    SELECT P.*
    FROM PRODUCT P
    INNER JOIN CATEGORY C ON P.Category_ID = C.Category_ID
    WHERE C.Category_Name = @CategoryName;
END;
GO
-------------------------------------- Getstaff inffor
CREATE PROCEDURE GetStaffInfo2
    @Staff_ID VARCHAR(10)
AS
BEGIN
    SELECT Staff_Id, Staff_Name, Staff_Address
    FROM Staff
    WHERE Staff_ID = @Staff_ID;
END;
GO
-------------------------------------- selectedProducts
CREATE PROCEDURE selectedProducts
AS
BEGIN
    SELECT *
    FROM SelectedProduct;
END;
GO
-------------------------------------- add to selected products
CREATE PROCEDURE AddToSelectedProducts2
    @ProductID VARCHAR(10),
    @ProductName VARCHAR(50),
    @CategoryID VARCHAR(10),
    @Price DECIMAL(10, 2)
AS
BEGIN
    INSERT INTO SelectedProduct (ProductID, ProductName, CategoryID, Price)
    VALUES (@ProductID, @ProductName, @CategoryID, @Price);
END;
GO
------------------------------------- clear selected products
CREATE PROCEDURE ClearSelectedProducts
AS
BEGIN
    DELETE FROM SelectedProduct;
END;
GO
------------------------------------- addbill
CREATE PROCEDURE AddBill5
    @Bill_ID VARCHAR(10),
    @Product_ID VARCHAR(10),
    @Customer_ID VARCHAR(10),
    @Staff_ID VARCHAR(10),
    @Quantity_product int,
    @Total_cost Decimal(10,2),
    @Date_buy date
AS
BEGIN
    INSERT INTO BILL (Bill_ID, Product_ID, Customer_ID, Staff_ID ,Quantity_product,Total_cost, Date_buy)
    VALUES (@Bill_ID, @Product_ID, @Customer_ID, @Staff_ID ,@Quantity_product,@Total_cost, @Date_buy);
END;
-------------------------------------- deleteBIll
CREATE PROCEDURE DeleteBill
    @Bill_ID VARCHAR(10)
AS
BEGIN
    -- Xóa bản ghi từ bảng BILL
    DELETE FROM BILL
    WHERE Bill_ID = @Bill_ID;
END;
------------------------------------- UpdateBill
CREATE PROCEDURE UpdateBill
    @Bill_ID VARCHAR(10),
    @Product_ID VARCHAR(10),
    @Customer_ID VARCHAR(10),
    @Staff_ID VARCHAR(10),
    @Labour_Cost DECIMAL(10, 2),
    @Quantity_Product INT,
    @Date_out DATE
AS
BEGIN
    -- Cập nhật thông tin của hóa đơn trong bảng BILL
    UPDATE BILL
    SET Product_ID = @Product_ID,
        Customer_ID = @Customer_ID,
        Staff_ID = @Staff_ID,
        Labour_Cost = @Labour_Cost,
        Quantity_Product = @Quantity_Product,
        Date_out = @Date_out
    WHERE Bill_ID = @Bill_ID;
END;

-------------------------------------- getbillbyid
CREATE PROCEDURE GetBillByID
    @Bill_ID VARCHAR(10)
AS
BEGIN
    SELECT * FROM Bill WHERE Bill_ID = @Bill_ID;
END;
GO
--------------------------------------- reduce quantity
CREATE PROCEDURE DeductProductQuantity
    @ProductId INT,
    @QuantityToDeduct INT
AS
BEGIN
    UPDATE Products
    SET Quantity = Quantity - @QuantityToDeduct
    WHERE ProductId = @ProductId
END
-----------------------------------------
go
CREATE VIEW CustomerInfo AS
SELECT 
    c.customer_id,
    c.customer_name,
    c.customer_address,
    c.customer_birthday,
    cp.customer_phone,
    ce.customer_email
FROM 
    CUSTOMER c
LEFT JOIN customer_phone cp ON c.customer_id = cp.customer_id
LEFT JOIN customer_email ce ON c.customer_id = ce.customer_id;
SELECT * FROM sys.views;
------------------------------------------- staffinfo
go
CREATE VIEW StaffDetailsInfo AS
SELECT 
    s.staff_ID,
    s.Staff_Name,
    s.Staff_Address,
    s.admin_id,
    sp.staff_Phone,
    se.staff_Email
FROM 
    staff s
LEFT JOIN staff_phone sp ON s.staff_ID = sp.staff_ID
LEFT JOIN staff_email se ON s.staff_ID = se.staff_ID;
go
--------------------------------------------  supplier
CREATE VIEW SupplierInfo AS
SELECT 
    s.Supplier_ID,
    s.Supplier_Name,
    s.Supplier_Address,
    sp.Supplier_Phone,
    se.Supplier_Email
FROM 
    SUPPLIER s
LEFT JOIN SUPPLIER_Phone sp ON s.Supplier_ID = sp.Supplier_ID
LEFT JOIN SUPPLIER_Email se ON s.Supplier_ID = se.Supplier_ID;
------------------------------------------- BestSelling sản phẩm
go
CREATE VIEW BestSellingProducts AS
SELECT 
    p.Product_ID,
    p.Product_Name,
    p.Category_ID,
    c.Category_Name,
    SUM(b.Quantity_Product) AS TotalQuantitySold,
    ROW_NUMBER() OVER (ORDER BY SUM(b.Quantity_Product) DESC) AS Rank
FROM 
    BILL b
JOIN 
    PRODUCT p ON b.Product_ID = p.Product_ID
JOIN 
    CATEGORY c ON p.Category_ID = c.Category_ID
GROUP BY 
    p.Product_ID,
    p.Product_Name,
    p.Category_ID,
    c.Category_Name;
------------------------------------------------ SẢn phẩm tồn khoa
CREATE VIEW InventoryProducts AS
SELECT 
    p.Product_ID,
    p.Product_Name,
    p.Category_ID,
    c.Category_Name,
    p.Quantity AS Quantity_In_Stock,
    p.Mace AS Mass_Per_Unit,
    p.Price AS Unit_Price,
    p.Date_In AS Date_Added
FROM 
    PRODUCT p
JOIN 
    CATEGORY c ON p.Category_ID = c.Category_ID;
-------------------------------------------------- Revenue
CREATE VIEW Revenue AS
SELECT 
    b.Bill_ID,
    b.Product_ID,
    p.Product_Name,
    p.Price AS Unit_Price,
    b.Quantity_Product AS Quantity_Sold,
    (p.Price * b.Quantity_Product) AS Total_Revenue,
    b.Date_out AS Date_Sold
FROM 
    BILL b
JOIN 
    PRODUCT p ON b.Product_ID = p.Product_ID;
---------------------------------------------------- revenue of category id
CREATE VIEW TotalRevenueByCategory AS
SELECT 
    c.Category_ID,
    c.Category_Name,
    SUM(p.Price * b.Quantity_Product) AS Total_Revenue
FROM 
    BILL b
JOIN 
    PRODUCT p ON b.Product_ID = p.Product_ID
JOIN 
    CATEGORY c ON p.Category_ID = c.Category_ID
GROUP BY 
    c.Category_ID,
    c.Category_Name;

    --------------------------------------------------- procedure top Customers 
go
CREATE PROCEDURE GetTopCustomers
AS
BEGIN
    WITH CustomerSpending AS (
        SELECT 
            c.customer_id,
            c.customer_name,
            c.customer_address,
            SUM(b.Labour_Cost + (p.Price * b.Quantity_Product)) AS Total_Spending 
        FROM 
            BILL b
        JOIN 
            CUSTOMER c ON b.customer_id = c.customer_id
        JOIN 
            PRODUCT p ON b.Product_ID = p.Product_ID
        GROUP BY 
            c.customer_id,
            c.customer_name,
            c.customer_address
    )
    SELECT TOP 10
        customer_id,
        customer_name,
        customer_address,
        Total_Spending
    FROM 
        CustomerSpending
    ORDER BY 
        Total_Spending DESC;
END;
-----------------------------------------ROLE STaff

Create ROLE StaffRolene3
Grant select , insert on product to StaffRolene3;

GRANT EXECUTE ON AddProduct5 TO StaffRolene3;
Deny  execute on DeleteProduct1 to staffrolene3;
GRANT EXECUTE ON UpdateProduct1 TO StaffRolene3;
GRANT EXECUTE ON SearchProduct1 TO StaffRolene3;
GRANT EXECUTE ON SearchFilter TO StaffRolene3;
GRANT EXECUTE ON ClearSelectedProducts TO StaffRolene3;
GRANT EXECUTE ON AddToSelectedProducts2 TO StaffRolene3;
GRANT EXECUTE ON AddCustomer3 TO StaffRolene3;
GRANT EXECUTE ON DeductProductQuantity1 TO StaffRolene3;
GRANT EXECUTE ON selectedProducts TO StaffRolene3;

GRANT SELECT, INSERT, UPDATE ON logininfo TO StaffRolene3;
GRANT SELECT, INSERT, UPDATE ON customer TO StaffRolene3;
GRANT SELECT, INSERT, UPDATE ON customer_phone TO StaffRolene3;
GRANT SELECT, INSERT, UPDATE ON customer_email TO StaffRolene3;
GRANT SELECT, INSERT, UPDATE ON product TO StaffRolene3;
DENY DELETE ON Product TO StaffRolene3;
GRANT SELECT, INSERT, UPDATE ON selectedproduct TO StaffRolene3;
GRANT SELECT, INSERT, UPDATE ON category TO StaffRolene3;
GRANT SELECT, INSERT, UPDATE ON supplier TO StaffRolene3;
GRANT SELECT, INSERT, UPDATE ON supplier_phone TO StaffRolene3;
GRANT SELECT, INSERT, UPDATE ON supplier_email TO StaffRolene3;
GRANT SELECT, INSERT, UPDATE ON provides TO StaffRolene3;
GRANT SELECT, INSERT, UPDATE ON bill TO StaffRolene3;
GRANT SELECT ON CustomerInfo TO StaffRolene3;
GRANT SELECT ON StaffDetailsInfo TO StaffRolene3;
GRANT SELECT ON SupplierInfo TO StaffRolene3;
GRANT SELECT ON BestSellingProducts TO StaffRolene3;
GRANT SELECT ON InventoryProducts TO StaffRolene3;
GRANT SELECT ON Revenue TO StaffRolene3;
GRANT SELECT ON TotalRevenueByCategory TO StaffRolene3;
GRANT EXECUTE ON EditCustomer1 TO StaffRolene3;
GRANT EXECUTE ON AddCustomer3 TO StaffRolene3;
GRANT EXECUTE ON AddProduct5 TO StaffRolene3;
Deny  execute on Deleteproduct1 to StaffRolene3;
GRANT EXECUTE ON UpdateProduct1 TO StaffRolene3;
GRANT EXECUTE ON SearchProduct1 TO StaffRolene3;
GRANT EXECUTE ON SearchFilter TO StaffRolene3;
GRANT EXECUTE ON GetStaffInfo2 TO StaffRolene3;
GRANT EXECUTE ON selectedProducts TO StaffRolene3;
GRANT EXECUTE ON AddToSelectedProducts2 TO StaffRolene3;
GRANT EXECUTE ON ClearSelectedProducts TO StaffRolene3;
GRANT EXECUTE ON AddBill3 TO StaffRolene3;
GRANT EXECUTE ON AddBill4 TO StaffRolene3;
GRANT EXECUTE ON AddBill5 TO StaffRolene3;
GRANT EXECUTE ON UpdateBill TO StaffRolene3;
GRANT EXECUTE ON GetBillByID TO StaffRolene3;
GRANT EXECUTE ON DeductProductQuantity1 TO StaffRolene3;
GRANT EXECUTE ON GetTopCustomers TO StaffRolene3;





INSERT INTO Staff (staff_id, staff_Name, staff_Address, admin_id)
VALUES ('EMP003', 'vy', 'LONG AN', 'ADMIN001');
INSERT INTO Admin (admin_id, ad_Name, ad_Address)
VALUES ('ADM010', 'Khoa', 'LONG AN');
SELECT * FROM BILL;
INSERT INTO Staff (staff_id, staff_Name, staff_Address, admin_id)
VALUES ('EMP022', 'tobeynguyen', 'LONG AN', 'ADMIN001');
USE Store_gold
GO

SELECT 
    dp.name AS [Login Name],
    r.name AS [Role Name]
FROM 
    sys.database_role_members drm
INNER JOIN 
    sys.database_principals dp ON drm.member_principal_id = dp.principal_id
INNER JOIN 
    sys.database_principals r ON drm.role_principal_id = r.principal_id
WHERE 
    dp.type_desc IN ('WINDOWS_USER', 'WINDOWS_GROUP', 'SQL_USER', 'SQL_ROLE') -- Chỉ hiển thị các đăng nhập và vai trò của cơ sở dữ liệu
ORDER BY 
    dp.name, r.name;

 DROP ROLE StaffRolene3;
 ALTER ROLE StaffRolene3 DROP MEMBER EMP020;
