﻿namespace Store_Gold
{
    partial class FBill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            lblInvoice = new Label();
            pictureBox1 = new PictureBox();
            ptbiconBill = new PictureBox();
            lblDate = new Label();
            lblCustomer = new Label();
            lblCustomerName = new Label();
            lblCustomerID = new Label();
            lblStaff = new Label();
            lblStaffID = new Label();
            lblStaffName = new Label();
            lblAddress = new Label();
            label1 = new Label();
            panelBill1 = new Panel();
            txtIDBill = new Guna.UI2.WinForms.Guna2TextBox();
            dtpBill = new Guna.UI2.WinForms.Guna2DateTimePicker();
            panel2 = new Panel();
            dgvSeletedProducts = new DataGridView();
            btnAddbill = new Guna.UI2.WinForms.Guna2Button();
            btnExit = new Guna.UI2.WinForms.Guna2Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ptbiconBill).BeginInit();
            panelBill1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvSeletedProducts).BeginInit();
            SuspendLayout();
            // 
            // lblInvoice
            // 
            lblInvoice.AutoSize = true;
            lblInvoice.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point);
            lblInvoice.ForeColor = Color.IndianRed;
            lblInvoice.Location = new Point(131, 20);
            lblInvoice.Name = "lblInvoice";
            lblInvoice.Size = new Size(119, 41);
            lblInvoice.TabIndex = 0;
            lblInvoice.Text = "Invoice";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.icons8_print_48;
            pictureBox1.Location = new Point(619, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(68, 58);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // ptbiconBill
            // 
            ptbiconBill.Image = Properties.Resources.icons8_bill_64;
            ptbiconBill.Location = new Point(37, 9);
            ptbiconBill.Name = "ptbiconBill";
            ptbiconBill.Size = new Size(88, 78);
            ptbiconBill.SizeMode = PictureBoxSizeMode.StretchImage;
            ptbiconBill.TabIndex = 2;
            ptbiconBill.TabStop = false;
            // 
            // lblDate
            // 
            lblDate.AutoSize = true;
            lblDate.Font = new Font("Segoe UI Semilight", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblDate.ForeColor = Color.DimGray;
            lblDate.Location = new Point(37, 112);
            lblDate.Name = "lblDate";
            lblDate.Size = new Size(49, 23);
            lblDate.TabIndex = 4;
            lblDate.Text = "Date:";
            // 
            // lblCustomer
            // 
            lblCustomer.AutoSize = true;
            lblCustomer.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lblCustomer.ForeColor = Color.DarkRed;
            lblCustomer.Location = new Point(37, 176);
            lblCustomer.Name = "lblCustomer";
            lblCustomer.Size = new Size(105, 25);
            lblCustomer.TabIndex = 7;
            lblCustomer.Text = "Customer";
            // 
            // lblCustomerName
            // 
            lblCustomerName.AutoSize = true;
            lblCustomerName.Font = new Font("Segoe UI Semilight", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblCustomerName.ForeColor = Color.Black;
            lblCustomerName.Location = new Point(42, 239);
            lblCustomerName.Name = "lblCustomerName";
            lblCustomerName.Size = new Size(101, 23);
            lblCustomerName.TabIndex = 8;
            lblCustomerName.Text = "John Smiths.";
            // 
            // lblCustomerID
            // 
            lblCustomerID.AutoSize = true;
            lblCustomerID.Font = new Font("Segoe UI Semilight", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblCustomerID.ForeColor = Color.Black;
            lblCustomerID.Location = new Point(40, 211);
            lblCustomerID.Name = "lblCustomerID";
            lblCustomerID.Size = new Size(61, 23);
            lblCustomerID.TabIndex = 9;
            lblCustomerID.Text = "123456";
            // 
            // lblStaff
            // 
            lblStaff.AutoSize = true;
            lblStaff.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lblStaff.ForeColor = Color.DarkRed;
            lblStaff.Location = new Point(216, 176);
            lblStaff.Name = "lblStaff";
            lblStaff.Size = new Size(57, 25);
            lblStaff.TabIndex = 10;
            lblStaff.Text = "Staff";
            // 
            // lblStaffID
            // 
            lblStaffID.AutoSize = true;
            lblStaffID.Font = new Font("Segoe UI Semilight", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblStaffID.ForeColor = Color.Black;
            lblStaffID.Location = new Point(217, 211);
            lblStaffID.Name = "lblStaffID";
            lblStaffID.Size = new Size(61, 23);
            lblStaffID.TabIndex = 11;
            lblStaffID.Text = "123456";
            // 
            // lblStaffName
            // 
            lblStaffName.AutoSize = true;
            lblStaffName.Font = new Font("Segoe UI Semilight", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblStaffName.ForeColor = Color.Black;
            lblStaffName.Location = new Point(217, 239);
            lblStaffName.Name = "lblStaffName";
            lblStaffName.Size = new Size(104, 23);
            lblStaffName.TabIndex = 12;
            lblStaffName.Text = "David Brown";
            // 
            // lblAddress
            // 
            lblAddress.AutoSize = true;
            lblAddress.Font = new Font("Segoe UI Semilight", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblAddress.ForeColor = Color.DimGray;
            lblAddress.Location = new Point(37, 144);
            lblAddress.Name = "lblAddress";
            lblAddress.Size = new Size(74, 23);
            lblAddress.TabIndex = 13;
            lblAddress.Text = "Address:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semilight", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.DimGray;
            label1.Location = new Point(109, 144);
            label1.Name = "label1";
            label1.Size = new Size(296, 23);
            label1.TabIndex = 14;
            label1.Text = "1912 Harvest Lane, New York, NY 12210";
            // 
            // panelBill1
            // 
            panelBill1.Controls.Add(btnExit);
            panelBill1.Controls.Add(txtIDBill);
            panelBill1.Controls.Add(dtpBill);
            panelBill1.Controls.Add(lblInvoice);
            panelBill1.Controls.Add(pictureBox1);
            panelBill1.Controls.Add(label1);
            panelBill1.Controls.Add(ptbiconBill);
            panelBill1.Controls.Add(lblAddress);
            panelBill1.Controls.Add(lblStaffName);
            panelBill1.Controls.Add(lblDate);
            panelBill1.Controls.Add(lblStaffID);
            panelBill1.Controls.Add(lblStaff);
            panelBill1.Controls.Add(lblCustomerID);
            panelBill1.Controls.Add(lblCustomer);
            panelBill1.Controls.Add(lblCustomerName);
            panelBill1.Dock = DockStyle.Top;
            panelBill1.Location = new Point(0, 0);
            panelBill1.Name = "panelBill1";
            panelBill1.Size = new Size(741, 274);
            panelBill1.TabIndex = 14;
            panelBill1.Paint += panelBill1_Paint;
            // 
            // txtIDBill
            // 
            txtIDBill.BorderColor = Color.LightSlateGray;
            txtIDBill.BorderRadius = 15;
            txtIDBill.Cursor = Cursors.IBeam;
            txtIDBill.CustomizableEdges = customizableEdges3;
            txtIDBill.DefaultText = "Ex: 01";
            txtIDBill.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtIDBill.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtIDBill.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtIDBill.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtIDBill.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtIDBill.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtIDBill.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtIDBill.Location = new Point(600, 69);
            txtIDBill.Margin = new Padding(3, 5, 3, 5);
            txtIDBill.Name = "txtIDBill";
            txtIDBill.PasswordChar = '\0';
            txtIDBill.PlaceholderText = "";
            txtIDBill.SelectedText = "";
            txtIDBill.ShadowDecoration.CustomizableEdges = customizableEdges4;
            txtIDBill.Size = new Size(99, 38);
            txtIDBill.TabIndex = 18;
            // 
            // dtpBill
            // 
            dtpBill.BorderRadius = 15;
            dtpBill.Checked = true;
            dtpBill.CustomizableEdges = customizableEdges5;
            dtpBill.FillColor = Color.White;
            dtpBill.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            dtpBill.Format = DateTimePickerFormat.Long;
            dtpBill.Location = new Point(92, 103);
            dtpBill.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dtpBill.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dtpBill.Name = "dtpBill";
            dtpBill.ShadowDecoration.CustomizableEdges = customizableEdges6;
            dtpBill.Size = new Size(243, 38);
            dtpBill.TabIndex = 17;
            dtpBill.Value = new DateTime(2024, 4, 17, 14, 15, 31, 910);
            // 
            // panel2
            // 
            panel2.Controls.Add(dgvSeletedProducts);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 274);
            panel2.Name = "panel2";
            panel2.Size = new Size(741, 223);
            panel2.TabIndex = 16;
            panel2.Paint += panel2_Paint;
            // 
            // dgvSeletedProducts
            // 
            dgvSeletedProducts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvSeletedProducts.Dock = DockStyle.Fill;
            dgvSeletedProducts.Location = new Point(0, 0);
            dgvSeletedProducts.Name = "dgvSeletedProducts";
            dgvSeletedProducts.RowHeadersVisible = false;
            dgvSeletedProducts.RowHeadersWidth = 100;
            dgvSeletedProducts.RowTemplate.Height = 29;
            dgvSeletedProducts.Size = new Size(741, 223);
            dgvSeletedProducts.TabIndex = 16;
            // 
            // btnAddbill
            // 
            btnAddbill.BorderRadius = 10;
            btnAddbill.CustomizableEdges = customizableEdges7;
            btnAddbill.DisabledState.BorderColor = Color.DarkGray;
            btnAddbill.DisabledState.CustomBorderColor = Color.DarkGray;
            btnAddbill.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnAddbill.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnAddbill.FillColor = Color.Teal;
            btnAddbill.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnAddbill.ForeColor = Color.White;
            btnAddbill.Location = new Point(274, 683);
            btnAddbill.Name = "btnAddbill";
            btnAddbill.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnAddbill.Size = new Size(164, 56);
            btnAddbill.TabIndex = 17;
            btnAddbill.Text = "Create";
            btnAddbill.Click += btnAddbill_Click;
            // 
            // btnExit
            // 
            btnExit.CustomizableEdges = customizableEdges1;
            btnExit.DisabledState.BorderColor = Color.DarkGray;
            btnExit.DisabledState.CustomBorderColor = Color.DarkGray;
            btnExit.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnExit.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnExit.FillColor = Color.Transparent;
            btnExit.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnExit.ForeColor = Color.White;
            btnExit.Image = Properties.Resources.refresh;
            btnExit.Location = new Point(532, 3);
            btnExit.Name = "btnExit";
            btnExit.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnExit.Size = new Size(71, 53);
            btnExit.TabIndex = 19;
            // 
            // FBill
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(741, 793);
            Controls.Add(btnAddbill);
            Controls.Add(panel2);
            Controls.Add(panelBill1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "FBill";
            Text = "FBill";
            Load += FBill_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)ptbiconBill).EndInit();
            panelBill1.ResumeLayout(false);
            panelBill1.PerformLayout();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvSeletedProducts).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label lblInvoice;
        private PictureBox pictureBox1;
        private PictureBox ptbiconBill;
        private Label lblDate;
        private Label lblCustomer;
        private Label lblCustomerName;
        private Label lblCustomerID;
        private Label lblStaff;
        private Label lblStaffID;
        private Label lblStaffName;
        private Label lblAddress;
        private Label label1;
        private Panel panelBill1;
        private Panel panel2;
        private DataGridView dgvSeletedProducts;
        private Guna.UI2.WinForms.Guna2Button btnAddbill;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpBill;
        public Guna.UI2.WinForms.Guna2TextBox txtIDBill;
        private Guna.UI2.WinForms.Guna2Button btnExit;
    }
}