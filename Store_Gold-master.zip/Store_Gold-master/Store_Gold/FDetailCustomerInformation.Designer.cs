﻿namespace Store_Gold
{
    partial class FDetailCustomerInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panelInformation = new Panel();
            btnClose = new Button();
            btnCreate = new Guna.UI2.WinForms.Guna2Button();
            label1 = new Label();
            pnInformation = new Panel();
            dtpBirtday = new Guna.UI2.WinForms.Guna2DateTimePicker();
            lblBirthday = new Label();
            txtIDCustomer = new Guna.UI2.WinForms.Guna2TextBox();
            lblID = new Label();
            txtYourMessage = new Guna.UI2.WinForms.Guna2TextBox();
            label3 = new Label();
            label2 = new Label();
            txtYourAddress = new Guna.UI2.WinForms.Guna2TextBox();
            lblAddress = new Label();
            txtPhoneNumber = new Guna.UI2.WinForms.Guna2TextBox();
            txtNameContact = new Guna.UI2.WinForms.Guna2TextBox();
            lblPhoneNumber = new Label();
            lblNameContact = new Label();
            txtEmail = new Guna.UI2.WinForms.Guna2TextBox();
            lblEmail = new Label();
            lblYourContact = new Label();
            panelBookingSummary = new Panel();
            lblEmailAdmin = new Label();
            label9 = new Label();
            lblPhoneAdmin = new Label();
            pictureBox2 = new PictureBox();
            pictureBox1 = new PictureBox();
            panel2 = new Panel();
            btnPayingNow = new Guna.UI2.WinForms.Guna2Button();
            lblPrice = new Label();
            label7 = new Label();
            label4 = new Label();
            panel1 = new Panel();
            label8 = new Label();
            txtquantitytobuy = new Guna.UI2.WinForms.Guna2TextBox();
            lblNameCustomer = new Label();
            lblIDCustomer = new Label();
            lblDayofBook = new Label();
            lblType = new Label();
            lblIDProduct = new Label();
            label6 = new Label();
            label5 = new Label();
            lblBookingSummary = new Label();
            lblRoom = new Label();
            panelInformation.SuspendLayout();
            pnInformation.SuspendLayout();
            panelBookingSummary.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panelInformation
            // 
            panelInformation.BackColor = SystemColors.ButtonHighlight;
            panelInformation.Controls.Add(btnClose);
            panelInformation.Controls.Add(btnCreate);
            panelInformation.Controls.Add(label1);
            panelInformation.Controls.Add(pnInformation);
            panelInformation.Controls.Add(lblYourContact);
            panelInformation.Dock = DockStyle.Left;
            panelInformation.Location = new Point(0, 0);
            panelInformation.Name = "panelInformation";
            panelInformation.Size = new Size(713, 553);
            panelInformation.TabIndex = 0;
            // 
            // btnClose
            // 
            btnClose.BackColor = Color.Transparent;
            btnClose.BackgroundImage = Properties.Resources.back_detailinformation;
            btnClose.BackgroundImageLayout = ImageLayout.Stretch;
            btnClose.ForeColor = Color.Transparent;
            btnClose.Location = new Point(29, 12);
            btnClose.Name = "btnClose";
            btnClose.Size = new Size(40, 41);
            btnClose.TabIndex = 124;
            btnClose.UseVisualStyleBackColor = false;
            btnClose.Click += btnClose_Click;
            // 
            // btnCreate
            // 
            btnCreate.BorderRadius = 10;
            btnCreate.CustomizableEdges = customizableEdges1;
            btnCreate.DisabledState.BorderColor = Color.DarkGray;
            btnCreate.DisabledState.CustomBorderColor = Color.DarkGray;
            btnCreate.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnCreate.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnCreate.FillColor = Color.Teal;
            btnCreate.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnCreate.ForeColor = Color.White;
            btnCreate.Location = new Point(220, 481);
            btnCreate.Name = "btnCreate";
            btnCreate.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnCreate.Size = new Size(293, 56);
            btnCreate.TabIndex = 10;
            btnCreate.Text = "Create";
            btnCreate.Click += btnCreate_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 7.8F, FontStyle.Italic | FontStyle.Underline, GraphicsUnit.Point);
            label1.ForeColor = Color.DarkGreen;
            label1.Location = new Point(288, 35);
            label1.Name = "label1";
            label1.Size = new Size(134, 16);
            label1.TabIndex = 9;
            label1.Text = "Fill out your deatails";
            label1.Click += label1_Click;
            // 
            // pnInformation
            // 
            pnInformation.BackColor = Color.AliceBlue;
            pnInformation.BorderStyle = BorderStyle.Fixed3D;
            pnInformation.Controls.Add(dtpBirtday);
            pnInformation.Controls.Add(lblBirthday);
            pnInformation.Controls.Add(txtIDCustomer);
            pnInformation.Controls.Add(lblID);
            pnInformation.Controls.Add(txtYourMessage);
            pnInformation.Controls.Add(label3);
            pnInformation.Controls.Add(label2);
            pnInformation.Controls.Add(txtYourAddress);
            pnInformation.Controls.Add(lblAddress);
            pnInformation.Controls.Add(txtPhoneNumber);
            pnInformation.Controls.Add(txtNameContact);
            pnInformation.Controls.Add(lblPhoneNumber);
            pnInformation.Controls.Add(lblNameContact);
            pnInformation.Controls.Add(txtEmail);
            pnInformation.Controls.Add(lblEmail);
            pnInformation.Location = new Point(29, 85);
            pnInformation.Margin = new Padding(3, 4, 3, 4);
            pnInformation.Name = "pnInformation";
            pnInformation.Size = new Size(654, 408);
            pnInformation.TabIndex = 8;
            // 
            // dtpBirtday
            // 
            dtpBirtday.BorderRadius = 15;
            dtpBirtday.Checked = true;
            dtpBirtday.CustomizableEdges = customizableEdges3;
            dtpBirtday.FillColor = Color.FromArgb(192, 255, 192);
            dtpBirtday.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            dtpBirtday.Format = DateTimePickerFormat.Long;
            dtpBirtday.Location = new Point(364, 60);
            dtpBirtday.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dtpBirtday.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dtpBirtday.Name = "dtpBirtday";
            dtpBirtday.ShadowDecoration.CustomizableEdges = customizableEdges4;
            dtpBirtday.Size = new Size(243, 38);
            dtpBirtday.TabIndex = 16;
            dtpBirtday.Value = new DateTime(2024, 4, 17, 14, 15, 31, 910);
            // 
            // lblBirthday
            // 
            lblBirthday.AutoSize = true;
            lblBirthday.Font = new Font("Century Gothic", 7.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblBirthday.ForeColor = Color.DarkGreen;
            lblBirthday.Location = new Point(383, 39);
            lblBirthday.Name = "lblBirthday";
            lblBirthday.Size = new Size(66, 16);
            lblBirthday.TabIndex = 15;
            lblBirthday.Text = "Birthday:";
            // 
            // txtIDCustomer
            // 
            txtIDCustomer.BorderColor = Color.LightSlateGray;
            txtIDCustomer.BorderRadius = 15;
            txtIDCustomer.Cursor = Cursors.IBeam;
            txtIDCustomer.CustomizableEdges = customizableEdges5;
            txtIDCustomer.DefaultText = "Ex: 0123";
            txtIDCustomer.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtIDCustomer.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtIDCustomer.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtIDCustomer.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtIDCustomer.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtIDCustomer.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtIDCustomer.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtIDCustomer.Location = new Point(51, 60);
            txtIDCustomer.Margin = new Padding(3, 5, 3, 5);
            txtIDCustomer.Name = "txtIDCustomer";
            txtIDCustomer.PasswordChar = '\0';
            txtIDCustomer.PlaceholderText = "";
            txtIDCustomer.SelectedText = "";
            txtIDCustomer.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtIDCustomer.Size = new Size(243, 38);
            txtIDCustomer.TabIndex = 14;
            // 
            // lblID
            // 
            lblID.AutoSize = true;
            lblID.Font = new Font("Century Gothic", 7.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblID.ForeColor = Color.DarkGreen;
            lblID.Location = new Point(75, 39);
            lblID.Name = "lblID";
            lblID.Size = new Size(89, 16);
            lblID.TabIndex = 13;
            lblID.Text = "ID Customer:";
            // 
            // txtYourMessage
            // 
            txtYourMessage.BorderColor = Color.LightSlateGray;
            txtYourMessage.BorderRadius = 15;
            txtYourMessage.Cursor = Cursors.IBeam;
            txtYourMessage.CustomizableEdges = customizableEdges7;
            txtYourMessage.DefaultText = "Let me know what you need ";
            txtYourMessage.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtYourMessage.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtYourMessage.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtYourMessage.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtYourMessage.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtYourMessage.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtYourMessage.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtYourMessage.Location = new Point(51, 285);
            txtYourMessage.Margin = new Padding(3, 5, 3, 5);
            txtYourMessage.Multiline = true;
            txtYourMessage.Name = "txtYourMessage";
            txtYourMessage.PasswordChar = '\0';
            txtYourMessage.PlaceholderText = "";
            txtYourMessage.SelectedText = "";
            txtYourMessage.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtYourMessage.Size = new Size(556, 101);
            txtYourMessage.TabIndex = 12;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 7.8F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.DarkGreen;
            label3.Location = new Point(75, 262);
            label3.Name = "label3";
            label3.Size = new Size(106, 16);
            label3.TabIndex = 11;
            label3.Text = "Your Message: ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.DarkGreen;
            label2.Location = new Point(51, 10);
            label2.Name = "label2";
            label2.Size = new Size(400, 17);
            label2.TabIndex = 10;
            label2.Text = "The more details you provide, the better service we can offer";
            // 
            // txtYourAddress
            // 
            txtYourAddress.BorderColor = Color.LightSlateGray;
            txtYourAddress.BorderRadius = 15;
            txtYourAddress.Cursor = Cursors.IBeam;
            txtYourAddress.CustomizableEdges = customizableEdges9;
            txtYourAddress.DefaultText = "HCMC";
            txtYourAddress.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtYourAddress.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtYourAddress.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtYourAddress.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtYourAddress.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtYourAddress.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtYourAddress.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtYourAddress.Location = new Point(364, 218);
            txtYourAddress.Margin = new Padding(3, 5, 3, 5);
            txtYourAddress.Name = "txtYourAddress";
            txtYourAddress.PasswordChar = '\0';
            txtYourAddress.PlaceholderText = "";
            txtYourAddress.SelectedText = "";
            txtYourAddress.ShadowDecoration.CustomizableEdges = customizableEdges10;
            txtYourAddress.Size = new Size(243, 38);
            txtYourAddress.TabIndex = 8;
            // 
            // lblAddress
            // 
            lblAddress.AutoSize = true;
            lblAddress.Font = new Font("Century Gothic", 7.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblAddress.ForeColor = Color.DarkGreen;
            lblAddress.Location = new Point(383, 197);
            lblAddress.Name = "lblAddress";
            lblAddress.Size = new Size(97, 16);
            lblAddress.TabIndex = 3;
            lblAddress.Text = "Your Address:";
            // 
            // txtPhoneNumber
            // 
            txtPhoneNumber.BorderColor = Color.LightSlateGray;
            txtPhoneNumber.BorderRadius = 15;
            txtPhoneNumber.Cursor = Cursors.IBeam;
            txtPhoneNumber.CustomizableEdges = customizableEdges11;
            txtPhoneNumber.DefaultText = "999-9999-999";
            txtPhoneNumber.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPhoneNumber.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPhoneNumber.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPhoneNumber.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPhoneNumber.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPhoneNumber.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtPhoneNumber.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPhoneNumber.Location = new Point(51, 218);
            txtPhoneNumber.Margin = new Padding(3, 5, 3, 5);
            txtPhoneNumber.Name = "txtPhoneNumber";
            txtPhoneNumber.PasswordChar = '\0';
            txtPhoneNumber.PlaceholderText = "";
            txtPhoneNumber.SelectedText = "";
            txtPhoneNumber.ShadowDecoration.CustomizableEdges = customizableEdges12;
            txtPhoneNumber.Size = new Size(243, 38);
            txtPhoneNumber.TabIndex = 7;
            // 
            // txtNameContact
            // 
            txtNameContact.BorderColor = Color.LightSlateGray;
            txtNameContact.BorderRadius = 15;
            txtNameContact.Cursor = Cursors.IBeam;
            txtNameContact.CustomizableEdges = customizableEdges13;
            txtNameContact.DefaultText = "Ex: Nguyen Le Tung Chi";
            txtNameContact.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtNameContact.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtNameContact.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtNameContact.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtNameContact.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNameContact.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtNameContact.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNameContact.Location = new Point(51, 134);
            txtNameContact.Margin = new Padding(3, 5, 3, 5);
            txtNameContact.Name = "txtNameContact";
            txtNameContact.PasswordChar = '\0';
            txtNameContact.PlaceholderText = "";
            txtNameContact.SelectedText = "";
            txtNameContact.ShadowDecoration.CustomizableEdges = customizableEdges14;
            txtNameContact.Size = new Size(243, 38);
            txtNameContact.TabIndex = 2;
            // 
            // lblPhoneNumber
            // 
            lblPhoneNumber.AutoSize = true;
            lblPhoneNumber.Font = new Font("Century Gothic", 7.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblPhoneNumber.ForeColor = Color.DarkGreen;
            lblPhoneNumber.Location = new Point(75, 197);
            lblPhoneNumber.Name = "lblPhoneNumber";
            lblPhoneNumber.Size = new Size(106, 16);
            lblPhoneNumber.TabIndex = 4;
            lblPhoneNumber.Text = "Phone Number:";
            // 
            // lblNameContact
            // 
            lblNameContact.AutoSize = true;
            lblNameContact.Font = new Font("Century Gothic", 7.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblNameContact.ForeColor = Color.DarkGreen;
            lblNameContact.Location = new Point(75, 113);
            lblNameContact.Name = "lblNameContact";
            lblNameContact.Size = new Size(109, 16);
            lblNameContact.TabIndex = 1;
            lblNameContact.Text = "Name Contact: ";
            // 
            // txtEmail
            // 
            txtEmail.BorderColor = Color.LightSlateGray;
            txtEmail.BorderRadius = 15;
            txtEmail.Cursor = Cursors.IBeam;
            txtEmail.CustomizableEdges = customizableEdges15;
            txtEmail.DefaultText = "Ex: abc123@gmail.com";
            txtEmail.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtEmail.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtEmail.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtEmail.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Location = new Point(364, 130);
            txtEmail.Margin = new Padding(3, 5, 3, 5);
            txtEmail.Name = "txtEmail";
            txtEmail.PasswordChar = '\0';
            txtEmail.PlaceholderText = "";
            txtEmail.SelectedText = "";
            txtEmail.ShadowDecoration.CustomizableEdges = customizableEdges16;
            txtEmail.Size = new Size(243, 38);
            txtEmail.TabIndex = 6;
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Font = new Font("Century Gothic", 7.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblEmail.ForeColor = Color.DarkGreen;
            lblEmail.Location = new Point(383, 111);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(47, 16);
            lblEmail.TabIndex = 5;
            lblEmail.Text = "Email:";
            // 
            // lblYourContact
            // 
            lblYourContact.AutoSize = true;
            lblYourContact.Font = new Font("Microsoft Sans Serif", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblYourContact.ForeColor = Color.SeaGreen;
            lblYourContact.Location = new Point(248, 9);
            lblYourContact.Name = "lblYourContact";
            lblYourContact.Size = new Size(206, 29);
            lblYourContact.TabIndex = 0;
            lblYourContact.Text = "YOUR CONTACT";
            // 
            // panelBookingSummary
            // 
            panelBookingSummary.BackColor = SystemColors.ControlLightLight;
            panelBookingSummary.Controls.Add(lblEmailAdmin);
            panelBookingSummary.Controls.Add(label9);
            panelBookingSummary.Controls.Add(lblPhoneAdmin);
            panelBookingSummary.Controls.Add(pictureBox2);
            panelBookingSummary.Controls.Add(pictureBox1);
            panelBookingSummary.Controls.Add(panel2);
            panelBookingSummary.Controls.Add(panel1);
            panelBookingSummary.Dock = DockStyle.Fill;
            panelBookingSummary.Location = new Point(713, 0);
            panelBookingSummary.Name = "panelBookingSummary";
            panelBookingSummary.Size = new Size(469, 553);
            panelBookingSummary.TabIndex = 1;
            // 
            // lblEmailAdmin
            // 
            lblEmailAdmin.AutoSize = true;
            lblEmailAdmin.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            lblEmailAdmin.ForeColor = Color.DarkGreen;
            lblEmailAdmin.Location = new Point(273, 517);
            lblEmailAdmin.Name = "lblEmailAdmin";
            lblEmailAdmin.Size = new Size(130, 20);
            lblEmailAdmin.TabIndex = 8;
            lblEmailAdmin.Text = "KVC@gmail.com";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point);
            label9.ForeColor = Color.DarkGreen;
            label9.Location = new Point(273, 517);
            label9.Name = "label9";
            label9.Size = new Size(0, 18);
            label9.TabIndex = 7;
            // 
            // lblPhoneAdmin
            // 
            lblPhoneAdmin.AutoSize = true;
            lblPhoneAdmin.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            lblPhoneAdmin.ForeColor = Color.DarkGreen;
            lblPhoneAdmin.Location = new Point(273, 473);
            lblPhoneAdmin.Name = "lblPhoneAdmin";
            lblPhoneAdmin.Size = new Size(99, 20);
            lblPhoneAdmin.TabIndex = 6;
            lblPhoneAdmin.Text = "0123-333-444";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.email;
            pictureBox2.Location = new Point(232, 508);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(35, 35);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 5;
            pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.phone;
            pictureBox1.Location = new Point(232, 465);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(35, 35);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(btnPayingNow);
            panel2.Controls.Add(lblPrice);
            panel2.Controls.Add(label7);
            panel2.Controls.Add(label4);
            panel2.Location = new Point(41, 272);
            panel2.Name = "panel2";
            panel2.Size = new Size(383, 180);
            panel2.TabIndex = 3;
            // 
            // btnPayingNow
            // 
            btnPayingNow.CustomizableEdges = customizableEdges17;
            btnPayingNow.DisabledState.BorderColor = Color.DarkGray;
            btnPayingNow.DisabledState.CustomBorderColor = Color.DarkGray;
            btnPayingNow.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnPayingNow.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnPayingNow.Dock = DockStyle.Bottom;
            btnPayingNow.FillColor = Color.Teal;
            btnPayingNow.Font = new Font("Segoe UI Black", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnPayingNow.ForeColor = Color.White;
            btnPayingNow.Location = new Point(0, 122);
            btnPayingNow.Name = "btnPayingNow";
            btnPayingNow.ShadowDecoration.CustomizableEdges = customizableEdges18;
            btnPayingNow.Size = new Size(381, 56);
            btnPayingNow.TabIndex = 4;
            btnPayingNow.Text = "Paying Now";
            btnPayingNow.Click += btnPayingNow_Click;
            // 
            // lblPrice
            // 
            lblPrice.AutoSize = true;
            lblPrice.Font = new Font("Georgia", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblPrice.ForeColor = Color.DarkGreen;
            lblPrice.Location = new Point(273, 59);
            lblPrice.Name = "lblPrice";
            lblPrice.Size = new Size(57, 21);
            lblPrice.TabIndex = 12;
            lblPrice.Text = "Total";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.DarkGreen;
            label7.Location = new Point(40, 16);
            label7.Name = "label7";
            label7.Size = new Size(186, 29);
            label7.TabIndex = 11;
            label7.Text = "Payment Details";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Georgia", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.DarkGreen;
            label4.Location = new Point(40, 59);
            label4.Name = "label4";
            label4.Size = new Size(57, 21);
            label4.TabIndex = 10;
            label4.Text = "Total";
            // 
            // panel1
            // 
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(label8);
            panel1.Controls.Add(txtquantitytobuy);
            panel1.Controls.Add(lblNameCustomer);
            panel1.Controls.Add(lblIDCustomer);
            panel1.Controls.Add(lblDayofBook);
            panel1.Controls.Add(lblType);
            panel1.Controls.Add(lblIDProduct);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(lblBookingSummary);
            panel1.Controls.Add(lblRoom);
            panel1.Location = new Point(41, 35);
            panel1.Name = "panel1";
            panel1.Size = new Size(383, 231);
            panel1.TabIndex = 2;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = Color.LightSeaGreen;
            label8.Location = new Point(51, 190);
            label8.Name = "label8";
            label8.Size = new Size(96, 20);
            label8.TabIndex = 12;
            label8.Text = "Quantity:";
            // 
            // txtquantitytobuy
            // 
            txtquantitytobuy.BorderColor = Color.LightSlateGray;
            txtquantitytobuy.BorderRadius = 15;
            txtquantitytobuy.Cursor = Cursors.IBeam;
            txtquantitytobuy.CustomizableEdges = customizableEdges19;
            txtquantitytobuy.DefaultText = "How many ?";
            txtquantitytobuy.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtquantitytobuy.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtquantitytobuy.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtquantitytobuy.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtquantitytobuy.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtquantitytobuy.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtquantitytobuy.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtquantitytobuy.Location = new Point(152, 181);
            txtquantitytobuy.Margin = new Padding(3, 5, 3, 5);
            txtquantitytobuy.Name = "txtquantitytobuy";
            txtquantitytobuy.PasswordChar = '\0';
            txtquantitytobuy.PlaceholderText = "";
            txtquantitytobuy.SelectedText = "";
            txtquantitytobuy.ShadowDecoration.CustomizableEdges = customizableEdges20;
            txtquantitytobuy.Size = new Size(146, 38);
            txtquantitytobuy.TabIndex = 11;
            txtquantitytobuy.TextChanged += txtquantitytobuy_TextChanged;
            // 
            // lblNameCustomer
            // 
            lblNameCustomer.AutoSize = true;
            lblNameCustomer.Font = new Font("Georgia", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblNameCustomer.ForeColor = Color.DarkGreen;
            lblNameCustomer.Location = new Point(36, 75);
            lblNameCustomer.Name = "lblNameCustomer";
            lblNameCustomer.Size = new Size(189, 21);
            lblNameCustomer.TabIndex = 10;
            lblNameCustomer.Text = "Dinh Thi Thanh Vy";
            // 
            // lblIDCustomer
            // 
            lblIDCustomer.AutoSize = true;
            lblIDCustomer.Font = new Font("Georgia", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblIDCustomer.ForeColor = Color.DarkGreen;
            lblIDCustomer.Location = new Point(39, 46);
            lblIDCustomer.Name = "lblIDCustomer";
            lblIDCustomer.Size = new Size(99, 21);
            lblIDCustomer.TabIndex = 9;
            lblIDCustomer.Text = "22110093";
            // 
            // lblDayofBook
            // 
            lblDayofBook.AutoSize = true;
            lblDayofBook.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblDayofBook.ForeColor = Color.LightSeaGreen;
            lblDayofBook.Location = new Point(45, 159);
            lblDayofBook.Name = "lblDayofBook";
            lblDayofBook.Size = new Size(108, 20);
            lblDayofBook.TabIndex = 7;
            lblDayofBook.Text = "DayofBook";
            // 
            // lblType
            // 
            lblType.AutoSize = true;
            lblType.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblType.ForeColor = Color.LightSeaGreen;
            lblType.Location = new Point(45, 129);
            lblType.Name = "lblType";
            lblType.Size = new Size(52, 20);
            lblType.TabIndex = 6;
            lblType.Text = "Ring";
            // 
            // lblIDProduct
            // 
            lblIDProduct.AutoSize = true;
            lblIDProduct.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblIDProduct.ForeColor = Color.LightSeaGreen;
            lblIDProduct.Location = new Point(91, 102);
            lblIDProduct.Name = "lblIDProduct";
            lblIDProduct.Size = new Size(57, 20);
            lblIDProduct.TabIndex = 5;
            lblIDProduct.Text = "V006";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Georgia", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.DarkGreen;
            label6.Location = new Point(51, 122);
            label6.Name = "label6";
            label6.Size = new Size(0, 21);
            label6.TabIndex = 4;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Georgia", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.DarkGreen;
            label5.Location = new Point(24, 59);
            label5.Name = "label5";
            label5.Size = new Size(0, 21);
            label5.TabIndex = 3;
            // 
            // lblBookingSummary
            // 
            lblBookingSummary.AutoSize = true;
            lblBookingSummary.Font = new Font("Microsoft Sans Serif", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            lblBookingSummary.ForeColor = Color.DarkGreen;
            lblBookingSummary.Location = new Point(40, 8);
            lblBookingSummary.Name = "lblBookingSummary";
            lblBookingSummary.Size = new Size(209, 29);
            lblBookingSummary.TabIndex = 1;
            lblBookingSummary.Text = "Booking Summary";
            // 
            // lblRoom
            // 
            lblRoom.AutoSize = true;
            lblRoom.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblRoom.ForeColor = Color.LightSeaGreen;
            lblRoom.Location = new Point(45, 102);
            lblRoom.Name = "lblRoom";
            lblRoom.Size = new Size(40, 20);
            lblRoom.TabIndex = 2;
            lblRoom.Text = "No.";
            // 
            // FDetailCustomerInformation
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1182, 553);
            ControlBox = false;
            Controls.Add(panelBookingSummary);
            Controls.Add(panelInformation);
            ImeMode = ImeMode.Off;
            Name = "FDetailCustomerInformation";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FDetailCustomerInformation";
            Load += FDetailCustomerInformation_Load;
            panelInformation.ResumeLayout(false);
            panelInformation.PerformLayout();
            pnInformation.ResumeLayout(false);
            pnInformation.PerformLayout();
            panelBookingSummary.ResumeLayout(false);
            panelBookingSummary.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelInformation;
        private Panel panelBookingSummary;
        private Label lblYourContact;
        private Label label1;
        private Panel pnInformation;
        private Guna.UI2.WinForms.Guna2TextBox txtYourAddress;
        private Label lblAddress;
        private Guna.UI2.WinForms.Guna2TextBox txtPhoneNumber;
        private Guna.UI2.WinForms.Guna2TextBox txtNameContact;
        private Label lblPhoneNumber;
        private Label lblNameContact;
        private Guna.UI2.WinForms.Guna2TextBox txtEmail;
        private Label lblEmail;
        private Label label2;
        private Guna.UI2.WinForms.Guna2TextBox txtYourMessage;
        private Label label3;
        private Panel panel1;
        private Label lblBookingSummary;
        private Panel panel2;
        private Label lblIDProduct;
        private Label label6;
        private Label label5;
        private Label lblRoom;
        private Label lblDayofBook;
        private Label lblType;
        private Label lblNameCustomer;
        private Label lblIDCustomer;
        private Guna.UI2.WinForms.Guna2Button btnPayingNow;
        private Label lblPrice;
        private Label label7;
        private Label label4;
        private Label label9;
        private Label lblPhoneAdmin;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private Label lblEmailAdmin;
        private Guna.UI2.WinForms.Guna2Button btnCreate;
        private Button btnClose;
        private Guna.UI2.WinForms.Guna2TextBox txtIDCustomer;
        private Label lblID;
        private Label lblBirthday;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpBirtday;
        private Label label8;
        private Guna.UI2.WinForms.Guna2TextBox txtquantitytobuy;
    }
}