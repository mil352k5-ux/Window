﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Store_Gold
{
    public partial class UCMenu : UserControl
    {
        public UCMenu()
        {
            InitializeComponent();
        }
        public void panelAccount_MouseHover(object sender, EventArgs e)
        {
            mtAccount.Show(panelAccount, new Point(0, panelAccount.Height));
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnbutton6_Click(object sender, EventArgs e)
        {

        }
    }
}
