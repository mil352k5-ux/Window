﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store_Gold
{
    internal class ProductDAO
    {
        DBConnection db = new DBConnection();
        public  DataTable Load()
        {
            string SQL = string.Format("SELECT * FROM Product " );
            DataTable dt = db.Load(SQL);
            return dt;
        }
        public DataTable LoadMonthlyRevenue()
        {
            string SQL = string.Format("SELECT * FROM CalculateMonthlyRevenue");
            DataTable dt = db.Load(SQL);
            return dt;
        }
        public void Add(string productID, string productName, string categoryID, DateTime dateIn ,int quantity, decimal mace)
        {
            string procedureName = "AddProduct5"; 
            SqlParameter[] parameters = new SqlParameter[6];
            parameters[0] = new SqlParameter("@Product_ID", productID);
            parameters[1] = new SqlParameter("@Product_Name", productName);
            parameters[2] = new SqlParameter("@Category_ID", categoryID);
            parameters[3] = new SqlParameter("@Date_In", dateIn);
            parameters[4] = new SqlParameter("@Quantity", quantity);
            parameters[5] = new SqlParameter("@Mace", mace);
            db.ExecuteProcedure(procedureName, parameters);
        }
        public void Delete(string productID)
        {
            string procedureName = "DeleteProduct1"; 
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@Product_ID", productID);
            db.ExecuteProcedure(procedureName, parameters);
        }
        public void Update(string productID, string newProductName, string newCategoryID, DateTime newDateIn,DateTime newdateexpire, int newQuantity, decimal newMace)
        {
            string procedureName = "UpdateProduct7"; 
            SqlParameter[] parameters = new SqlParameter[7];
            parameters[0] = new SqlParameter("@Product_ID", productID);
            parameters[1] = new SqlParameter("@Product_Name", newProductName);
            parameters[2] = new SqlParameter("@Category_ID", newCategoryID);
            parameters[3] = new SqlParameter("@Date_In", newDateIn);
            parameters[4] = new SqlParameter("@Date_out", newdateexpire);
            parameters[5] = new SqlParameter("@Quantity", newQuantity);
            parameters[6] = new SqlParameter("@Mace", newMace);
            db.ExecuteProcedure(procedureName, parameters);
        }
        public void AddSelectedProducts(string productID, string productName, string categoryID, double price)
        {
            string procedureName = "AddToSelectedProducts2";
            SqlParameter[] parameters = new SqlParameter[4];
            parameters[0] = new SqlParameter("@ProductID", productID);
            parameters[1] = new SqlParameter("@ProductName", productName);
            parameters[2] = new SqlParameter("@CategoryID", categoryID);
            parameters[3] = new SqlParameter("@Price", price);
            db.ExecuteProcedure(procedureName, parameters);
        }
        public DataTable SearchProduct(string searchType, string searchText)
        {
            string procedureName = "SearchProduct1";
            SqlParameter[] parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("@SearchType", searchType);
            parameters[1] = new SqlParameter("@SearchText", searchText);
            return db.ExecuteProcedureWithResult(procedureName, parameters);
        }
        public DataTable SearchFilterProduct(string categoryName)
        {
            string procedureName = "SearchFilter";
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@CategoryName", categoryName);
            return db.ExecuteProcedureWithResult(procedureName, parameters);
        }
        public DataTable GetSelectedProducts()
        {
            string procedureName = "selectedProducts";
            return db.ExecuteProcedureWithResult(procedureName, null);
        }
        public void ClearSelectedProducts()
        {
            string procedureName = "ClearSelectedProducts";
            db.ExecuteProcedure(procedureName, null);
        }

        public void DeductProductQuantity(string productId, int quantityToDeduct)
        {
            string procedureName = "DeductProductQuantity1";
            SqlParameter[] parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("@ProductId", productId);
            parameters[1] = new SqlParameter("@QuantityToDeduct", quantityToDeduct);
            db.ExecuteProcedure(procedureName, parameters);
        }



    }
}
