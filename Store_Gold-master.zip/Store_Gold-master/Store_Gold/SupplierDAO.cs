﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store_Gold
{
    public class SupplierDAO
    {
        DBConnection db = new DBConnection();
        public DataTable Load()
        {
            string SQL = string.Format("SELECT * FROM Provides ");
            DataTable dt = db.Load(SQL);
            return dt;
        }
        public DataTable GetSuppliers()
        {
            string SQL = "EXEC GetSuppliers";
            DataTable dt = db.Load(SQL);
            return dt;
        }
        public DataTable GetProductsBySupplier(string supplierName)
        {
            DataTable dt = new DataTable();

            try
            {
                using (SqlConnection conn = DBConnection.GetSqlConnection())
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("GetProductsBySupplierName", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@SupplierName", supplierName);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    adapter.Fill(dt);
                }
            }
            catch (Exception ex)
            {
                // Xử lý exception nếu có
                Console.WriteLine("Error: " + ex.Message);
            }
            return dt;
        }
        public bool UpdateProductQuantity(string productID, int quantity)
        {
            try
            {
                using (SqlConnection connection = DBConnection.GetSqlConnection())
                {
                    connection.Open(); // Mở kết nối

                    using (SqlCommand cmd = new SqlCommand("UpdateProductQuantity", connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@ProductID", productID);
                        cmd.Parameters.AddWithValue("@Quantity", quantity);


                        int rowsAffected = cmd.ExecuteNonQuery();


                        return rowsAffected > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                // Xử lý các ngoại lệ nếu có
                Console.WriteLine("Error while updating product quantity: " + ex.Message);
                return false;
            }
        }
        public DataTable GetProductByID(string productID)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection conn = DBConnection.GetSqlConnection())
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("GetProductByID", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ProductID", productID);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    adapter.Fill(dt);
                }
            }
            catch (Exception ex)
            {
                // Xử lý exception nếu có
                Console.WriteLine("Error: " + ex.Message);
            }
            return dt;
        }
    }
}
