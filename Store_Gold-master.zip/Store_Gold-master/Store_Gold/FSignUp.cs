﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Data.SqlClient;

namespace ProjectFinalKCVTourism
{
    public partial class FSignUp : Form
    {
        /*Modify modify = new Modify();
        SqlConnection conn = new SqlConnection(Properties.Settings.Default.connStr);
        PersonDao personDao = new PersonDao();*/
        public FSignUp()
        {
            InitializeComponent();
        }
        private void lblNotice_Click(object sender, EventArgs e)
        {
        }
        private void panelSignUp_Paint(object sender, PaintEventArgs e)
        {
        }
        private void FSignUp_Load(object sender, EventArgs e)
        {
        }
        internal bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }
        public bool CheckAccount(string ac)
        {
            return Regex.IsMatch(ac, "^[a-zA-Z0-9]{6,24}$");
        }
        private void btnRegister_Click(object sender, EventArgs e)
        {
            string email = txtContactEmail.Text.Trim();
            string yourname = txtYourName.Text.Trim();
            string cmnd = txtIDCard.Text.Trim();
            string phonenumber = txtPhonenumberregister.Text.Trim();
            string password = txtPassword.Text.Trim();
            string verifyPassword = txtVerifyPassword.Text.Trim();

            // Kiểm tra tính hợp lệ của tên người dùng, mật khẩu và số điện thoại
            if (!CheckAccount(yourname))
            {
                MessageBox.Show("Please enter the account name between 6 and 24 characters!!! ");
                return;
            }
            if (!CheckAccount(password))
            {
                MessageBox.Show("Please enter the password between 6 and 24 characters!!!!");
                return;
            }
            if (verifyPassword != password)
            {
                MessageBox.Show("Please verify your password exactly!!!!");
                return;
            }
            if (!IsValidEmail(email))
            {
                MessageBox.Show("Invalid email format (e.g., toankhoa@gmail.com).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            /*if (!personDao.IsValidPhoneNumber(phonenumber))
            {
                MessageBox.Show("Invalid phone number format(XXX-XXXX-XXX).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }*/
            /*try
            {
                conn.Open();
                // Kiểm tra xem email đã tồn tại trong cơ sở dữ liệu chưa
                string queryCheckEmail = "SELECT COUNT(*) FROM Accounts WHERE user_email = @email";
                SqlCommand cmdCheckEmail = new SqlCommand(queryCheckEmail, conn);
                cmdCheckEmail.Parameters.AddWithValue("@email", email);
                int emailExists = (int)cmdCheckEmail.ExecuteScalar();
                if (emailExists > 0)
                {
                    MessageBox.Show("This email already exists. Please enter another email.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                // Kiểm tra xem số CMND đã tồn tại trong cơ sở dữ liệu chưa
                string queryCheckCMND = "SELECT COUNT(*) FROM Accounts WHERE user_id = @cmnd";
                SqlCommand cmdCheckCMND = new SqlCommand(queryCheckCMND, conn);
                cmdCheckCMND.Parameters.AddWithValue("@cmnd", cmnd);
                int cmndExists = (int)cmdCheckCMND.ExecuteScalar();
                if (cmndExists > 0)
                {
                    MessageBox.Show("This IDCARD already exists. Please enter another IDCARD.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                // Thêm tài khoản mới vào cơ sở dữ liệu
                string queryInsertAccount = "INSERT INTO Accounts VALUES (@yourname, @cmnd, @email, @password)";
                SqlCommand cmdInsertAccount = new SqlCommand(queryInsertAccount, conn);
                cmdInsertAccount.Parameters.AddWithValue("@yourname", yourname);
                cmdInsertAccount.Parameters.AddWithValue("@cmnd", cmnd);
                cmdInsertAccount.Parameters.AddWithValue("@email", email);
                cmdInsertAccount.Parameters.AddWithValue("@password", password);
                cmdInsertAccount.ExecuteNonQuery();
                // Thêm thông tin khách hàng vào bảng Customers
                MessageBox.Show("SignUp successfully !!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (SqlException ex)
            {
                if (ex.Number == 2627) // Error code for unique constraint violation
                {
                    MessageBox.Show("This username or email was registered. Please signup another account", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            finally
            {
                // Đảm bảo rằng kết nối được đóng sau khi sử dụng
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }*/
        }

        private void linkLabelAlreadymember_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            /*Form1 form1 = new Form1();
            form1.ShowDialog();*/
        }
    }
}
