﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store_Gold
{
    public class Admin:Person
    {
        public Admin(string name , string cmnd , string address , string email , string phone,DateTime Birthday) :base (name , cmnd , address, email , phone, Birthday)
        {  }
        public Admin()
        {  }
    }
}
