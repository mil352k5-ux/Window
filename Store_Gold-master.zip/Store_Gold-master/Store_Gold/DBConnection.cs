﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Guna.UI2.WinForms.Suite.Descriptions;

namespace Store_Gold
{
    public class DBConnection
    {
        SqlConnection conn = new SqlConnection(Properties.Settings.Default.cnnstr);
        public static string stringconnection = @"Data Source=(localdb)\mssqllocaldb;Initial Catalog=Store_gold;Integrated Security=True;Encrypt=False";
        private static string connectionstring = @"";

        public static string Connectionstring
        { 
            get { return connectionstring; } 
            set { connectionstring = value; }
        }

        public DataTable Load(string SQL)
        {
            DataTable dt = new DataTable();
            try
            {
                conn.Open();

                SqlDataAdapter adapter = new SqlDataAdapter(SQL, conn);
                adapter.Fill(dt);

            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
            finally
            {
                conn.Close();
            }
            return dt;
        }
        public void Excute(string SQL)
        {
            try
            {
                // Ket noi
                conn.Open();
                SqlCommand cmd = new SqlCommand(SQL, conn);
                if (cmd.ExecuteNonQuery() > 0)
                    MessageBox.Show("SUCCESSFUL");
            }
            catch (Exception ex)
            {
                MessageBox.Show("FAILED" + ex);
            }
            finally
            {
                conn.Close();
            }
        }
        public static SqlConnection GetSqlConnection()
        {
            return new SqlConnection(connectionstring);
        }
        public void ExecuteProcedure(string procedureName, SqlParameter[] parameters)
        {
            using (SqlConnection connection = new SqlConnection(connectionstring))
            {
                using (SqlCommand cmd = new SqlCommand(procedureName, connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    if (parameters != null)
                    {
                        cmd.Parameters.AddRange(parameters);
                    }
                    connection.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }
        public DataTable ExecuteProcedureWithResult(string procedureName, SqlParameter[] parameters)
        {
            DataTable dt = new DataTable();
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionstring))
                {
                    using (SqlCommand cmd = new SqlCommand(procedureName, connection))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        if (parameters != null)
                        {
                            cmd.Parameters.AddRange(parameters);
                        }
                        connection.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                        adapter.Fill(dt);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            return dt;
        }
    }
}
