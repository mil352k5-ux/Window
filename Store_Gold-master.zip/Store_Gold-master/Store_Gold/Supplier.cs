﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store_Gold
{
    internal class Supplier
    {
        string supplier_id;
        string supplier_name;
        string supplier_address;
        string supplier_email;
        string supplier_phone;

        public string Supplier_id
        {
            get { return supplier_id; }
            set { supplier_id = value; }
        }
        public string Supplier_name
        {
            get { return supplier_name; }
            set { supplier_name = value; }
        }

        public string Supplier_address
        {
            get { return supplier_address; }
            set { supplier_address = value; }
        }

        public string Supplier_email
        {
            get { return supplier_email; }
            set { supplier_email = value; }
        }
        public string Supplier_phone
        {
            get { return supplier_phone; }
            set { supplier_phone = value; }
        }

        public Supplier()
        {
            // Khởi tạo mặc định
        }
        public Supplier(string Supplier_ID, string Supplier_name, string Supplier_address, string Supplier_email, string Supplier_phone)
        {
            this.Supplier_id = Supplier_id;
            this.Supplier_name = Supplier_name;
            this.Supplier_address = Supplier_address;
            this.Supplier_email = Supplier_email;
            this.Supplier_phone = Supplier_phone;
        }
    }
}
