﻿namespace Store_Gold
{
    partial class FListProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            panel1 = new Panel();
            lblFilter = new Label();
            comboFilter = new Guna.UI2.WinForms.Guna2ComboBox();
            label5 = new Label();
            comboSearch = new Guna.UI2.WinForms.Guna2ComboBox();
            btnSearchProduct = new Guna.UI2.WinForms.Guna2Button();
            txtSearch = new Guna.UI2.WinForms.Guna2TextBox();
            dgvListProduct = new Guna.UI2.WinForms.Guna2DataGridView();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvListProduct).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.AliceBlue;
            panel1.Controls.Add(lblFilter);
            panel1.Controls.Add(comboFilter);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(comboSearch);
            panel1.Controls.Add(btnSearchProduct);
            panel1.Controls.Add(txtSearch);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1182, 126);
            panel1.TabIndex = 0;
            // 
            // lblFilter
            // 
            lblFilter.AutoSize = true;
            lblFilter.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblFilter.ForeColor = Color.SteelBlue;
            lblFilter.Location = new Point(328, 89);
            lblFilter.Name = "lblFilter";
            lblFilter.Size = new Size(58, 20);
            lblFilter.TabIndex = 35;
            lblFilter.Text = "Filter";
            // 
            // comboFilter
            // 
            comboFilter.BackColor = Color.Transparent;
            comboFilter.BorderColor = Color.FromArgb(64, 64, 64);
            comboFilter.BorderRadius = 15;
            comboFilter.CustomizableEdges = customizableEdges1;
            comboFilter.DrawMode = DrawMode.OwnerDrawFixed;
            comboFilter.DropDownStyle = ComboBoxStyle.DropDownList;
            comboFilter.FocusedColor = Color.FromArgb(94, 148, 255);
            comboFilter.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            comboFilter.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            comboFilter.ForeColor = Color.FromArgb(68, 88, 112);
            comboFilter.ItemHeight = 40;
            comboFilter.Items.AddRange(new object[] { "Gold", "Silver", "Platium", "Top 5 Products Sold the most", "Top 5 Products is the most expensive", "Top 5 Products is cheapest" });
            comboFilter.Location = new Point(392, 75);
            comboFilter.Name = "comboFilter";
            comboFilter.ShadowDecoration.CustomizableEdges = customizableEdges2;
            comboFilter.Size = new Size(421, 46);
            comboFilter.TabIndex = 34;
            comboFilter.SelectedIndexChanged += comboFilter_SelectedIndexChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(389, 50);
            label5.Name = "label5";
            label5.Size = new Size(0, 20);
            label5.TabIndex = 33;
            // 
            // comboSearch
            // 
            comboSearch.BackColor = Color.Transparent;
            comboSearch.BorderColor = Color.FromArgb(64, 64, 64);
            comboSearch.BorderRadius = 20;
            comboSearch.CustomizableEdges = customizableEdges3;
            comboSearch.DrawMode = DrawMode.OwnerDrawFixed;
            comboSearch.DropDownStyle = ComboBoxStyle.DropDownList;
            comboSearch.FocusedColor = Color.FromArgb(94, 148, 255);
            comboSearch.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            comboSearch.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            comboSearch.ForeColor = Color.FromArgb(68, 88, 112);
            comboSearch.ItemHeight = 40;
            comboSearch.Items.AddRange(new object[] { "Product_Name", "Product_ID", "category_id", "none" });
            comboSearch.Location = new Point(289, 12);
            comboSearch.Name = "comboSearch";
            comboSearch.ShadowDecoration.CustomizableEdges = customizableEdges4;
            comboSearch.Size = new Size(97, 46);
            comboSearch.TabIndex = 32;
            comboSearch.TextAlign = HorizontalAlignment.Center;
            // 
            // btnSearchProduct
            // 
            btnSearchProduct.BackColor = Color.Transparent;
            btnSearchProduct.BackgroundImage = Properties.Resources.search;
            btnSearchProduct.BackgroundImageLayout = ImageLayout.Stretch;
            btnSearchProduct.CustomizableEdges = customizableEdges5;
            btnSearchProduct.DisabledState.BorderColor = Color.DarkGray;
            btnSearchProduct.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSearchProduct.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSearchProduct.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSearchProduct.FillColor = Color.Transparent;
            btnSearchProduct.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnSearchProduct.ForeColor = Color.White;
            btnSearchProduct.Location = new Point(829, 17);
            btnSearchProduct.Name = "btnSearchProduct";
            btnSearchProduct.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btnSearchProduct.Size = new Size(37, 37);
            btnSearchProduct.TabIndex = 31;
            btnSearchProduct.Click += btnSearchProduct_Click;
            // 
            // txtSearch
            // 
            txtSearch.BorderColor = Color.FromArgb(64, 64, 64);
            txtSearch.BorderRadius = 15;
            txtSearch.CustomizableEdges = customizableEdges7;
            txtSearch.DefaultText = "";
            txtSearch.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtSearch.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtSearch.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtSearch.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtSearch.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSearch.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtSearch.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSearch.Location = new Point(392, 11);
            txtSearch.Margin = new Padding(3, 4, 3, 4);
            txtSearch.Name = "txtSearch";
            txtSearch.PasswordChar = '\0';
            txtSearch.PlaceholderText = "";
            txtSearch.SelectedText = "";
            txtSearch.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtSearch.Size = new Size(421, 47);
            txtSearch.TabIndex = 30;
            // 
            // dgvListProduct
            // 
            dataGridViewCellStyle1.BackColor = Color.White;
            dgvListProduct.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(100, 88, 255);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dgvListProduct.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dgvListProduct.ColumnHeadersHeight = 4;
            dgvListProduct.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dgvListProduct.DefaultCellStyle = dataGridViewCellStyle3;
            dgvListProduct.Dock = DockStyle.Fill;
            dgvListProduct.GridColor = Color.FromArgb(231, 229, 255);
            dgvListProduct.Location = new Point(0, 126);
            dgvListProduct.Name = "dgvListProduct";
            dgvListProduct.RowHeadersVisible = false;
            dgvListProduct.RowHeadersWidth = 51;
            dgvListProduct.RowTemplate.Height = 29;
            dgvListProduct.Size = new Size(1182, 527);
            dgvListProduct.TabIndex = 1;
            dgvListProduct.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dgvListProduct.ThemeStyle.AlternatingRowsStyle.Font = null;
            dgvListProduct.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dgvListProduct.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dgvListProduct.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dgvListProduct.ThemeStyle.BackColor = Color.White;
            dgvListProduct.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            dgvListProduct.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dgvListProduct.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dgvListProduct.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgvListProduct.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dgvListProduct.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgvListProduct.ThemeStyle.HeaderStyle.Height = 4;
            dgvListProduct.ThemeStyle.ReadOnly = false;
            dgvListProduct.ThemeStyle.RowsStyle.BackColor = Color.White;
            dgvListProduct.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvListProduct.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgvListProduct.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            dgvListProduct.ThemeStyle.RowsStyle.Height = 29;
            dgvListProduct.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dgvListProduct.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dgvListProduct.CellContentClick += dgvListProduct_CellContentClick;
            // 
            // FListProduct
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1182, 653);
            Controls.Add(dgvListProduct);
            Controls.Add(panel1);
            Name = "FListProduct";
            Text = "FListProduct";
            Load += FListProduct_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvListProduct).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Guna.UI2.WinForms.Guna2ComboBox comboSearch;
        private Guna.UI2.WinForms.Guna2Button btnSearchProduct;
        private Guna.UI2.WinForms.Guna2TextBox txtSearch;
        private Label lblFilter;
        private Guna.UI2.WinForms.Guna2ComboBox comboFilter;
        private Label label5;
        private Guna.UI2.WinForms.Guna2DataGridView dgvListProduct;
    }
}