﻿namespace Store_Gold
{
    partial class FSupplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            pictureBox1 = new PictureBox();
            dgvSupplier = new DataGridView();
            lblSupplier = new Label();
            panel1 = new Panel();
            cbCompany = new Guna.UI2.WinForms.Guna2ComboBox();
            panel2 = new Panel();
            btnImportgoods = new Guna.UI2.WinForms.Guna2Button();
            txtProductID = new Guna.UI2.WinForms.Guna2TextBox();
            lblProductID = new Label();
            txtSupplierAddress = new Guna.UI2.WinForms.Guna2TextBox();
            lblSupplierAddress = new Label();
            txtSupplierID = new Guna.UI2.WinForms.Guna2TextBox();
            lblSupplierID = new Label();
            lblSupplierName = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvSupplier).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.outlets;
            pictureBox1.Location = new Point(430, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(77, 83);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // dgvSupplier
            // 
            dgvSupplier.BackgroundColor = Color.White;
            dgvSupplier.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvSupplier.Location = new Point(613, 120);
            dgvSupplier.Name = "dgvSupplier";
            dgvSupplier.RowHeadersWidth = 51;
            dgvSupplier.RowTemplate.Height = 29;
            dgvSupplier.Size = new Size(529, 678);
            dgvSupplier.TabIndex = 1;
            dgvSupplier.CellContentClick += dgvSupplier_CellContentClick;
            dgvSupplier.SelectionChanged += dgvSupplier_SelectionChanged;
            // 
            // lblSupplier
            // 
            lblSupplier.AutoSize = true;
            lblSupplier.Font = new Font("Microsoft Sans Serif", 24F, FontStyle.Regular, GraphicsUnit.Point);
            lblSupplier.ForeColor = Color.CadetBlue;
            lblSupplier.Location = new Point(513, 31);
            lblSupplier.Name = "lblSupplier";
            lblSupplier.Size = new Size(166, 46);
            lblSupplier.TabIndex = 2;
            lblSupplier.Text = "Supplier";
            // 
            // panel1
            // 
            panel1.Controls.Add(cbCompany);
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(btnImportgoods);
            panel1.Controls.Add(txtProductID);
            panel1.Controls.Add(lblProductID);
            panel1.Controls.Add(txtSupplierAddress);
            panel1.Controls.Add(lblSupplierAddress);
            panel1.Controls.Add(txtSupplierID);
            panel1.Controls.Add(lblSupplierID);
            panel1.Controls.Add(lblSupplierName);
            panel1.Location = new Point(38, 120);
            panel1.Name = "panel1";
            panel1.Size = new Size(555, 678);
            panel1.TabIndex = 7;
            // 
            // cbCompany
            // 
            cbCompany.BackColor = Color.Transparent;
            cbCompany.BorderColor = Color.IndianRed;
            cbCompany.BorderRadius = 15;
            cbCompany.CustomizableEdges = customizableEdges1;
            cbCompany.DrawMode = DrawMode.OwnerDrawFixed;
            cbCompany.DropDownStyle = ComboBoxStyle.DropDownList;
            cbCompany.FocusedColor = Color.FromArgb(94, 148, 255);
            cbCompany.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            cbCompany.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            cbCompany.ForeColor = Color.FromArgb(68, 88, 112);
            cbCompany.ItemHeight = 30;
            cbCompany.Items.AddRange(new object[] { "Tobey\t", "Vy", "Cheese", "None" });
            cbCompany.Location = new Point(220, 22);
            cbCompany.Name = "cbCompany";
            cbCompany.ShadowDecoration.CustomizableEdges = customizableEdges2;
            cbCompany.Size = new Size(175, 36);
            cbCompany.TabIndex = 0;
            cbCompany.SelectedIndexChanged += cbCompany_SelectedIndexChanged;
            // 
            // panel2
            // 
            panel2.Location = new Point(0, 379);
            panel2.Name = "panel2";
            panel2.Size = new Size(555, 299);
            panel2.TabIndex = 16;
            // 
            // btnImportgoods
            // 
            btnImportgoods.BorderRadius = 15;
            btnImportgoods.CustomizableEdges = customizableEdges3;
            btnImportgoods.DisabledState.BorderColor = Color.DarkGray;
            btnImportgoods.DisabledState.CustomBorderColor = Color.DarkGray;
            btnImportgoods.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnImportgoods.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnImportgoods.FillColor = Color.IndianRed;
            btnImportgoods.Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnImportgoods.ForeColor = Color.White;
            btnImportgoods.Location = new Point(3, 276);
            btnImportgoods.Name = "btnImportgoods";
            btnImportgoods.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btnImportgoods.Size = new Size(549, 56);
            btnImportgoods.TabIndex = 13;
            btnImportgoods.Text = "Import goods";
            btnImportgoods.Click += btnImportgoods_Click;
            // 
            // txtProductID
            // 
            txtProductID.BorderColor = Color.IndianRed;
            txtProductID.BorderRadius = 15;
            txtProductID.CustomizableEdges = customizableEdges5;
            txtProductID.DefaultText = "1234";
            txtProductID.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtProductID.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtProductID.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtProductID.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtProductID.FillColor = Color.Snow;
            txtProductID.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtProductID.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtProductID.ForeColor = Color.Gray;
            txtProductID.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtProductID.Location = new Point(275, 192);
            txtProductID.Margin = new Padding(4, 3, 4, 3);
            txtProductID.Name = "txtProductID";
            txtProductID.PasswordChar = '\0';
            txtProductID.PlaceholderText = "";
            txtProductID.SelectedText = "";
            txtProductID.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtProductID.Size = new Size(246, 43);
            txtProductID.TabIndex = 12;
            // 
            // lblProductID
            // 
            lblProductID.AutoSize = true;
            lblProductID.Font = new Font("Georgia", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblProductID.ForeColor = Color.IndianRed;
            lblProductID.Location = new Point(28, 208);
            lblProductID.Name = "lblProductID";
            lblProductID.Size = new Size(150, 27);
            lblProductID.TabIndex = 11;
            lblProductID.Text = "Product ID:";
            // 
            // txtSupplierAddress
            // 
            txtSupplierAddress.BorderColor = Color.IndianRed;
            txtSupplierAddress.BorderRadius = 15;
            txtSupplierAddress.CustomizableEdges = customizableEdges7;
            txtSupplierAddress.DefaultText = "TP. HCM";
            txtSupplierAddress.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtSupplierAddress.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtSupplierAddress.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtSupplierAddress.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtSupplierAddress.FillColor = Color.Snow;
            txtSupplierAddress.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSupplierAddress.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtSupplierAddress.ForeColor = Color.Gray;
            txtSupplierAddress.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSupplierAddress.Location = new Point(255, 134);
            txtSupplierAddress.Margin = new Padding(4, 3, 4, 3);
            txtSupplierAddress.Name = "txtSupplierAddress";
            txtSupplierAddress.PasswordChar = '\0';
            txtSupplierAddress.PlaceholderText = "";
            txtSupplierAddress.SelectedText = "";
            txtSupplierAddress.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtSupplierAddress.Size = new Size(266, 43);
            txtSupplierAddress.TabIndex = 10;
            // 
            // lblSupplierAddress
            // 
            lblSupplierAddress.AutoSize = true;
            lblSupplierAddress.Font = new Font("Georgia", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblSupplierAddress.ForeColor = Color.IndianRed;
            lblSupplierAddress.Location = new Point(28, 147);
            lblSupplierAddress.Name = "lblSupplierAddress";
            lblSupplierAddress.Size = new Size(230, 27);
            lblSupplierAddress.TabIndex = 9;
            lblSupplierAddress.Text = "Supplier Address: ";
            lblSupplierAddress.Click += label1_Click;
            // 
            // txtSupplierID
            // 
            txtSupplierID.BorderColor = Color.IndianRed;
            txtSupplierID.BorderRadius = 15;
            txtSupplierID.CustomizableEdges = customizableEdges9;
            txtSupplierID.DefaultText = "12345678";
            txtSupplierID.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtSupplierID.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtSupplierID.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtSupplierID.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtSupplierID.FillColor = Color.Snow;
            txtSupplierID.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSupplierID.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtSupplierID.ForeColor = Color.Gray;
            txtSupplierID.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSupplierID.Location = new Point(220, 75);
            txtSupplierID.Margin = new Padding(4, 3, 4, 3);
            txtSupplierID.Name = "txtSupplierID";
            txtSupplierID.PasswordChar = '\0';
            txtSupplierID.PlaceholderText = "";
            txtSupplierID.SelectedText = "";
            txtSupplierID.ShadowDecoration.CustomizableEdges = customizableEdges10;
            txtSupplierID.Size = new Size(301, 43);
            txtSupplierID.TabIndex = 8;
            // 
            // lblSupplierID
            // 
            lblSupplierID.AutoSize = true;
            lblSupplierID.Font = new Font("Georgia", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblSupplierID.ForeColor = Color.IndianRed;
            lblSupplierID.Location = new Point(28, 85);
            lblSupplierID.Name = "lblSupplierID";
            lblSupplierID.Size = new Size(157, 27);
            lblSupplierID.TabIndex = 7;
            lblSupplierID.Text = "Supplier ID:";
            // 
            // lblSupplierName
            // 
            lblSupplierName.AutoSize = true;
            lblSupplierName.Font = new Font("Georgia", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblSupplierName.ForeColor = Color.IndianRed;
            lblSupplierName.Location = new Point(28, 22);
            lblSupplierName.Name = "lblSupplierName";
            lblSupplierName.Size = new Size(132, 27);
            lblSupplierName.TabIndex = 5;
            lblSupplierName.Text = "Company:";
            // 
            // FSupplier
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.SeaShell;
            ClientSize = new Size(1182, 853);
            Controls.Add(panel1);
            Controls.Add(lblSupplier);
            Controls.Add(dgvSupplier);
            Controls.Add(pictureBox1);
            Name = "FSupplier";
            Text = "FSupplier";
            Load += FSupplier_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvSupplier).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private DataGridView dgvSupplier;
        private Label lblSupplier;
        private Panel panel1;
        private Label lblSupplierName;
        private Label lblProductID;
        private Guna.UI2.WinForms.Guna2TextBox txtProductID;
        private Guna.UI2.WinForms.Guna2Button btnImportgoods;
        private Panel panel2;
        private Guna.UI2.WinForms.Guna2ComboBox cbCompany;
        private Guna.UI2.WinForms.Guna2TextBox txtSupplierAddress;
        private Label lblSupplierAddress;
        private Guna.UI2.WinForms.Guna2TextBox txtSupplierID;
        private Label lblSupplierID;
    }
}