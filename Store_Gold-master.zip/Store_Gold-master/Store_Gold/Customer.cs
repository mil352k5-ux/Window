﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Store_Gold
{
    public class Customer : Person
    {
        public Customer()
        {

        }
        public Customer(string Name, string CMND, string Address, string Email, string PhoneNumber, DateTime Birthday) : base(Name, CMND, Address, Email, PhoneNumber,Birthday)
        {

        }

    }
}
