﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Store_Gold
{
    public partial class FImportgoods : Form
    {
        SupplierDAO supplierDAO = new SupplierDAO();
        private List<string> selectedProductIDs;

        public FImportgoods(List<string> selectedProductIDs)
        {
            InitializeComponent();
            this.selectedProductIDs = selectedProductIDs;
        }

        private void btnConfirm_Click_1(object sender, EventArgs e)
        {
            if (dgvImportsgood.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a product to import.");
                return;
            }

            // Kiểm tra xem người dùng đã nhập số lượng chưa
            if (int.TryParse(txtQuantityImports.Text, out int quantity))
            {
                foreach (DataGridViewRow selectedRow in dgvImportsgood.SelectedRows)
                {
                    string productID = selectedRow.Cells["Product_ID"].Value.ToString();
                    // Cập nhật số lượng sản phẩm trong cửa hàng
                    bool success = supplierDAO.UpdateProductQuantity(productID, quantity);
                    if (!success)
                    {
                        MessageBox.Show("Error while updating product quantity for product ID: " + productID);
                        return;
                    }
                }
                MessageBox.Show("Import successfully.");
            }
            else
            {
                MessageBox.Show("Please type a valid number.");
            }
        }

        private void FImportgoods_Load(object sender, EventArgs e)
        {
            LoadSelectedProducts();
        }
        private void LoadSelectedProducts()
        {
            try
            {
                // Tạo DataTable để lưu thông tin sản phẩm đã chọn
                DataTable dtSelectedProducts = new DataTable();
                // Thêm các cột cho DataTable
                dtSelectedProducts.Columns.Add("Product_ID");
                dtSelectedProducts.Columns.Add("Product_Name");
                // Lặp qua danh sách ID sản phẩm đã chọn và tải thông tin từ cơ sở dữ liệu
                foreach (string productID in selectedProductIDs)
                {
                    // Sử dụng SupplierDAO để lấy thông tin sản phẩm từ cơ sở dữ liệu
                    DataTable productData = supplierDAO.GetProductByID(productID);
                    // Lấy thông tin sản phẩm từ DataTable trả về
                    string productName = productData.Rows[0]["Product_Name"].ToString();
                    // Thêm dòng mới vào DataTable chứa thông tin sản phẩm
                    dtSelectedProducts.Rows.Add(productID, productName);
                }
                // Hiển thị thông tin sản phẩm trên DataGridView
                dgvImportsgood.DataSource = dtSelectedProducts;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while loading selected products: " + ex.Message);
            }
        }

        private void dgvImportsgood_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.RowIndex < dgvImportsgood.Rows.Count)
            {
                DataGridViewRow selectedRow = dgvImportsgood.Rows[e.RowIndex];
                string productID = selectedRow.Cells["Product_ID"].Value.ToString();
                string productName = selectedRow.Cells["Product_Name"].Value.ToString();
                // Hiển thị thông tin sản phẩm lên textbox hoặc label
                txtProductIDImport.Text = productID;
                txtProvidesNameImport.Text = productName;
            }
        }
    }
}
