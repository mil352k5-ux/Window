﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Store_Gold
{
    public partial class FManageBill : Form
    {
        public FManageBill()
        {
            InitializeComponent();
        }

        private void FManageBill_Load(object sender, EventArgs e)
        {
            BillDAO billDAO = new BillDAO();
            dgvbill.DataSource = billDAO.Load();
            dgvbill.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }
    }
}
