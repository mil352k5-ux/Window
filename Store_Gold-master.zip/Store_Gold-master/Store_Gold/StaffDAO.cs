﻿    using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store_Gold
{
    internal class StaffDAO:PersonDAO
    {
        public StaffDAO() : base()
        {
            this.tableName = "Staff";
        }
        public StaffDAO(Staff staff) : base(staff)
        {
            this.tableName = "Staff";
        }
        public Staff GetStaffInfo(string staffID)
        {
            Staff staff = null;
            try
            {
                using (SqlConnection conn = DBConnection.GetSqlConnection())
                {
                    conn.Open();
                    string procedureName = "GetStaffInfo2"; // Thay thế bằng tên thực sự của stored procedure
                    SqlParameter[] parameters = {
                        new SqlParameter("@Staff_ID", staffID)
                    };
                    using (SqlCommand cmd = new SqlCommand(procedureName, conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddRange(parameters);
                        SqlDataReader reader = cmd.ExecuteReader();
                        if (reader.Read())
                        {
                            staff = new Staff();
                            staff.CMND = reader["Staff_ID"].ToString();
                            staff.FullName = reader["Staff_Name"].ToString();
                            staff.Address = reader["Staff_Address"].ToString();
                        }
                        reader.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            return staff;
        }
    }
}
