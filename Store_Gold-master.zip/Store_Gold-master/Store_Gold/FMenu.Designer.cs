﻿using Guna.UI2.WinForms;

namespace Store_Gold
{
    partial class FMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing && (components != null))
        //    {
        //        components.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            btnManageInformation = new Button();
            elPlaces1 = new Guna2Elipse(components);
            timerofnavigatorCustomer = new System.Windows.Forms.Timer(components);
            UCMenucustomer = new UCMenu();
            SuspendLayout();
            // 
            // btnManageInformation
            // 
            btnManageInformation.Dock = DockStyle.Fill;
            btnManageInformation.FlatAppearance.BorderSize = 0;
            btnManageInformation.FlatStyle = FlatStyle.Flat;
            btnManageInformation.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnManageInformation.ForeColor = Color.White;
            btnManageInformation.ImageAlign = ContentAlignment.MiddleLeft;
            btnManageInformation.Location = new Point(0, 0);
            btnManageInformation.Name = "btnManageInformation";
            btnManageInformation.RightToLeft = RightToLeft.No;
            btnManageInformation.Size = new Size(134, 48);
            btnManageInformation.TabIndex = 4;
            btnManageInformation.Text = "CONTACT";
            btnManageInformation.UseVisualStyleBackColor = true;
            btnManageInformation.Click += btnManageInformation_Click;
            // 
            // elPlaces1
            // 
            elPlaces1.BorderRadius = 30;
            elPlaces1.TargetControl = this;
            // 
            // timerofnavigatorCustomer
            // 
            timerofnavigatorCustomer.Interval = 10;
            timerofnavigatorCustomer.Tick += timerofnavigatorCustomer_Tick;
            // 
            // UCMenucustomer
            // 
            UCMenucustomer.Dock = DockStyle.Fill;
            UCMenucustomer.Location = new Point(0, 0);
            UCMenucustomer.Name = "UCMenucustomer";
            UCMenucustomer.Size = new Size(1200, 900);
            UCMenucustomer.TabIndex = 0;
            // 
            // FMenu
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoValidate = AutoValidate.EnableAllowFocusChange;
            ClientSize = new Size(1200, 900);
            Controls.Add(UCMenucustomer);
            FormBorderStyle = FormBorderStyle.None;
            Name = "FMenu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FMenu";
            Load += FMenu_Load;
            ResumeLayout(false);
        }

        #endregion
        private Button btnManageInformation;
        private Panel panelPlaces1;
        private Label lblPlaces1;
        private Label lblPlaces3;
        private Label lblPlaces2;
        private Label lblPlaces4;
        private Label lblDecripton4;
        private Label lblDecripton3;
        private Label lblDecripton2;
        private Label lblDecripton1;
        private Label lblDecripton6;
        private Label lblDecripton5;
        private Label lblcostofticket;
        private Guna.UI2.WinForms.Guna2Elipse elPlaces1;
        private System.Windows.Forms.Timer timerofnavigatorCustomer;
        private UCMenu UCMenucustomer;
    }
}