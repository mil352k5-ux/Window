﻿namespace Store_Gold
{
    partial class FManageCategory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            dgvCategoryList = new Guna.UI2.WinForms.Guna2DataGridView();
            lblCategoryPrice = new Label();
            txtCategoryQuantity = new Guna.UI2.WinForms.Guna2TextBox();
            txtCategoryID = new Guna.UI2.WinForms.Guna2TextBox();
            lblPhone = new Label();
            lblMass = new Label();
            txtNameCategory = new Guna.UI2.WinForms.Guna2TextBox();
            lblCategoryName = new Label();
            label1 = new Label();
            txtCategoryPrice = new Guna.UI2.WinForms.Guna2TextBox();
            ((System.ComponentModel.ISupportInitialize)dgvCategoryList).BeginInit();
            SuspendLayout();
            // 
            // dgvCategoryList
            // 
            dataGridViewCellStyle1.BackColor = Color.White;
            dgvCategoryList.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dgvCategoryList.BorderStyle = BorderStyle.Fixed3D;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(100, 88, 255);
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dgvCategoryList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dgvCategoryList.ColumnHeadersHeight = 4;
            dgvCategoryList.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dataGridViewCellStyle3.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            dgvCategoryList.DefaultCellStyle = dataGridViewCellStyle3;
            dgvCategoryList.Dock = DockStyle.Right;
            dgvCategoryList.GridColor = Color.FromArgb(231, 229, 255);
            dgvCategoryList.Location = new Point(511, 0);
            dgvCategoryList.Name = "dgvCategoryList";
            dgvCategoryList.RowHeadersVisible = false;
            dgvCategoryList.RowHeadersWidth = 51;
            dgvCategoryList.RowTemplate.Height = 29;
            dgvCategoryList.Size = new Size(671, 801);
            dgvCategoryList.TabIndex = 0;
            dgvCategoryList.ThemeStyle.AlternatingRowsStyle.BackColor = Color.White;
            dgvCategoryList.ThemeStyle.AlternatingRowsStyle.Font = null;
            dgvCategoryList.ThemeStyle.AlternatingRowsStyle.ForeColor = Color.Empty;
            dgvCategoryList.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = Color.Empty;
            dgvCategoryList.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = Color.Empty;
            dgvCategoryList.ThemeStyle.BackColor = Color.White;
            dgvCategoryList.ThemeStyle.GridColor = Color.FromArgb(231, 229, 255);
            dgvCategoryList.ThemeStyle.HeaderStyle.BackColor = Color.FromArgb(100, 88, 255);
            dgvCategoryList.ThemeStyle.HeaderStyle.BorderStyle = DataGridViewHeaderBorderStyle.None;
            dgvCategoryList.ThemeStyle.HeaderStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgvCategoryList.ThemeStyle.HeaderStyle.ForeColor = Color.White;
            dgvCategoryList.ThemeStyle.HeaderStyle.HeaightSizeMode = DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            dgvCategoryList.ThemeStyle.HeaderStyle.Height = 4;
            dgvCategoryList.ThemeStyle.ReadOnly = false;
            dgvCategoryList.ThemeStyle.RowsStyle.BackColor = Color.White;
            dgvCategoryList.ThemeStyle.RowsStyle.BorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dgvCategoryList.ThemeStyle.RowsStyle.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dgvCategoryList.ThemeStyle.RowsStyle.ForeColor = Color.FromArgb(71, 69, 94);
            dgvCategoryList.ThemeStyle.RowsStyle.Height = 29;
            dgvCategoryList.ThemeStyle.RowsStyle.SelectionBackColor = Color.FromArgb(231, 229, 255);
            dgvCategoryList.ThemeStyle.RowsStyle.SelectionForeColor = Color.FromArgb(71, 69, 94);
            dgvCategoryList.CellContentClick += dgvCategoryList_CellContentClick;
            // 
            // lblCategoryPrice
            // 
            lblCategoryPrice.AutoSize = true;
            lblCategoryPrice.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblCategoryPrice.ForeColor = Color.SteelBlue;
            lblCategoryPrice.Location = new Point(287, 250);
            lblCategoryPrice.Name = "lblCategoryPrice";
            lblCategoryPrice.Size = new Size(145, 20);
            lblCategoryPrice.TabIndex = 43;
            lblCategoryPrice.Text = "Category Price:";
            // 
            // txtCategoryQuantity
            // 
            txtCategoryQuantity.BorderColor = Color.FromArgb(64, 64, 64);
            txtCategoryQuantity.BorderRadius = 20;
            txtCategoryQuantity.CustomizableEdges = customizableEdges1;
            txtCategoryQuantity.DefaultText = "50";
            txtCategoryQuantity.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtCategoryQuantity.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtCategoryQuantity.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtCategoryQuantity.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtCategoryQuantity.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCategoryQuantity.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtCategoryQuantity.ForeColor = Color.CornflowerBlue;
            txtCategoryQuantity.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCategoryQuantity.Location = new Point(20, 274);
            txtCategoryQuantity.Margin = new Padding(3, 4, 3, 4);
            txtCategoryQuantity.Name = "txtCategoryQuantity";
            txtCategoryQuantity.PasswordChar = '\0';
            txtCategoryQuantity.PlaceholderText = "";
            txtCategoryQuantity.SelectedText = "";
            txtCategoryQuantity.ShadowDecoration.CustomizableEdges = customizableEdges2;
            txtCategoryQuantity.Size = new Size(219, 43);
            txtCategoryQuantity.TabIndex = 42;
            txtCategoryQuantity.TextAlign = HorizontalAlignment.Center;
            // 
            // txtCategoryID
            // 
            txtCategoryID.BorderColor = Color.FromArgb(64, 64, 64);
            txtCategoryID.BorderRadius = 20;
            txtCategoryID.CustomizableEdges = customizableEdges3;
            txtCategoryID.DefaultText = "0.6";
            txtCategoryID.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtCategoryID.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtCategoryID.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtCategoryID.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtCategoryID.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCategoryID.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtCategoryID.ForeColor = Color.CornflowerBlue;
            txtCategoryID.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCategoryID.Location = new Point(270, 193);
            txtCategoryID.Margin = new Padding(3, 4, 3, 4);
            txtCategoryID.Name = "txtCategoryID";
            txtCategoryID.PasswordChar = '\0';
            txtCategoryID.PlaceholderText = "";
            txtCategoryID.SelectedText = "";
            txtCategoryID.ShadowDecoration.CustomizableEdges = customizableEdges4;
            txtCategoryID.Size = new Size(221, 43);
            txtCategoryID.TabIndex = 41;
            txtCategoryID.TextAlign = HorizontalAlignment.Center;
            // 
            // lblPhone
            // 
            lblPhone.AutoSize = true;
            lblPhone.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblPhone.ForeColor = Color.SteelBlue;
            lblPhone.Location = new Point(36, 250);
            lblPhone.Name = "lblPhone";
            lblPhone.Size = new Size(96, 20);
            lblPhone.TabIndex = 40;
            lblPhone.Text = "Quantity:";
            // 
            // lblMass
            // 
            lblMass.AutoSize = true;
            lblMass.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblMass.ForeColor = Color.SteelBlue;
            lblMass.Location = new Point(287, 169);
            lblMass.Name = "lblMass";
            lblMass.Size = new Size(0, 20);
            lblMass.TabIndex = 39;
            // 
            // txtNameCategory
            // 
            txtNameCategory.BorderColor = Color.FromArgb(64, 64, 64);
            txtNameCategory.BorderRadius = 20;
            txtNameCategory.CustomizableEdges = customizableEdges5;
            txtNameCategory.DefaultText = "Sun Ring";
            txtNameCategory.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtNameCategory.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtNameCategory.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtNameCategory.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtNameCategory.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNameCategory.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtNameCategory.ForeColor = Color.CornflowerBlue;
            txtNameCategory.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNameCategory.Location = new Point(20, 192);
            txtNameCategory.Margin = new Padding(3, 4, 3, 4);
            txtNameCategory.Name = "txtNameCategory";
            txtNameCategory.PasswordChar = '\0';
            txtNameCategory.PlaceholderText = "";
            txtNameCategory.SelectedText = "";
            txtNameCategory.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtNameCategory.Size = new Size(219, 43);
            txtNameCategory.TabIndex = 37;
            txtNameCategory.TextAlign = HorizontalAlignment.Center;
            // 
            // lblCategoryName
            // 
            lblCategoryName.AutoSize = true;
            lblCategoryName.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblCategoryName.ForeColor = Color.SteelBlue;
            lblCategoryName.Location = new Point(36, 169);
            lblCategoryName.Name = "lblCategoryName";
            lblCategoryName.Size = new Size(155, 20);
            lblCategoryName.TabIndex = 36;
            lblCategoryName.Text = "Category Name: ";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.SteelBlue;
            label1.Location = new Point(287, 169);
            label1.Name = "label1";
            label1.Size = new Size(126, 20);
            label1.TabIndex = 45;
            label1.Text = "Category ID: ";
            // 
            // txtCategoryPrice
            // 
            txtCategoryPrice.BorderColor = Color.FromArgb(64, 64, 64);
            txtCategoryPrice.BorderRadius = 20;
            txtCategoryPrice.CustomizableEdges = customizableEdges7;
            txtCategoryPrice.DefaultText = "0.6";
            txtCategoryPrice.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtCategoryPrice.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtCategoryPrice.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtCategoryPrice.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtCategoryPrice.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCategoryPrice.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtCategoryPrice.ForeColor = Color.CornflowerBlue;
            txtCategoryPrice.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCategoryPrice.Location = new Point(270, 274);
            txtCategoryPrice.Margin = new Padding(3, 4, 3, 4);
            txtCategoryPrice.Name = "txtCategoryPrice";
            txtCategoryPrice.PasswordChar = '\0';
            txtCategoryPrice.PlaceholderText = "";
            txtCategoryPrice.SelectedText = "";
            txtCategoryPrice.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtCategoryPrice.Size = new Size(221, 43);
            txtCategoryPrice.TabIndex = 46;
            txtCategoryPrice.TextAlign = HorizontalAlignment.Center;
            // 
            // FManageCategory
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1182, 801);
            Controls.Add(txtCategoryPrice);
            Controls.Add(label1);
            Controls.Add(lblCategoryPrice);
            Controls.Add(txtCategoryQuantity);
            Controls.Add(txtCategoryID);
            Controls.Add(lblPhone);
            Controls.Add(lblMass);
            Controls.Add(txtNameCategory);
            Controls.Add(lblCategoryName);
            Controls.Add(dgvCategoryList);
            Name = "FManageCategory";
            Text = "FManageCategory";
            Load += FManageCategory_Load;
            ((System.ComponentModel.ISupportInitialize)dgvCategoryList).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2DataGridView dgvCategoryList;
        private Guna.UI2.WinForms.Guna2ComboBox comboCategory;
        private Label lblCategoryPrice;
        private Guna.UI2.WinForms.Guna2TextBox txtCategoryQuantity;
        private Guna.UI2.WinForms.Guna2TextBox txtCategoryID;
        private Label lblPhone;
        private Label lblMass;
        private Guna.UI2.WinForms.Guna2TextBox txtNameCategory;
        private Label lblCategoryName;
        private Label label1;
        private Guna.UI2.WinForms.Guna2TextBox txtCategoryPrice;
    }
}