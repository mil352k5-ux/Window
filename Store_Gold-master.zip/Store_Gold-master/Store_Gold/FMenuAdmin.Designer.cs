﻿namespace Store_Gold
{
    partial class FMenuAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        //protected override void Dispose(bool disposing)
        //{
        //    if (disposing && (components != null))
        //    {
        //        components.Dispose();
        //    }
        //    base.Dispose(disposing);
        //}

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            elMenuAdmin = new Guna.UI2.WinForms.Guna2Elipse(components);
            UCMenuAdmin = new UCMenu();
            ucMenuadmin1 = new UCMenu();
            SuspendLayout();
            // 
            // elMenuAdmin
            // 
            elMenuAdmin.BorderRadius = 10;
            // 
            // UCMenuAdmin
            // 
            UCMenuAdmin.Dock = DockStyle.Fill;
            UCMenuAdmin.Location = new Point(0, 0);
            UCMenuAdmin.Name = "UCMenuAdmin";
            UCMenuAdmin.Size = new Size(1182, 853);
            UCMenuAdmin.TabIndex = 0;
            // 
            // ucMenuadmin1
            // 
            ucMenuadmin1.Dock = DockStyle.Fill;
            ucMenuadmin1.Location = new Point(0, 0);
            ucMenuadmin1.Name = "ucMenuadmin1";
            ucMenuadmin1.Size = new Size(1182, 853);
            ucMenuadmin1.TabIndex = 0;
            // 
            // FMenuAdmin
            // 
            ClientSize = new Size(1182, 853);
            Controls.Add(ucMenuadmin1);
            Name = "FMenuAdmin";
            ResumeLayout(false);
        }

        #endregion
        private Guna.UI2.WinForms.Guna2Elipse elMenuAdmin;
        private UCMenu UCMenuAdmin;
        private UCMenu ucMenuadmin1;
    }
}