﻿namespace Store_Gold
{
    partial class FManageBill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panel1 = new Panel();
            lblCustomerIDBIll = new Label();
            txtCusidbill = new Guna.UI2.WinForms.Guna2TextBox();
            lblD = new Label();
            txtIDBIill = new Guna.UI2.WinForms.Guna2TextBox();
            lblstaffidbill = new Label();
            lblproductidbill = new Label();
            txtStaffidbill = new Guna.UI2.WinForms.Guna2TextBox();
            txtPhone = new Guna.UI2.WinForms.Guna2TextBox();
            dtpDayBuying = new Guna.UI2.WinForms.Guna2DateTimePicker();
            label2 = new Label();
            txtlabourcost = new Guna.UI2.WinForms.Guna2TextBox();
            lblabourcostbill = new Label();
            panel2 = new Panel();
            btnTopCustomer = new Guna.UI2.WinForms.Guna2Button();
     
            btnDeleteBill = new Guna.UI2.WinForms.Guna2Button();
            comboSearch = new Guna.UI2.WinForms.Guna2ComboBox();
            btnSearch = new Guna.UI2.WinForms.Guna2Button();
            txtSearch = new Guna.UI2.WinForms.Guna2TextBox();
            lblFilter = new Label();
            comboFilter = new Guna.UI2.WinForms.Guna2ComboBox();
            label5 = new Label();
            panel3 = new Panel();
            dgvbill = new DataGridView();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvbill).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(btnTopCustomer);
        
            panel1.Controls.Add(btnDeleteBill);
            panel1.Controls.Add(comboSearch);
            panel1.Controls.Add(btnSearch);
            panel1.Controls.Add(txtSearch);
            panel1.Controls.Add(lblFilter);
            panel1.Controls.Add(comboFilter);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(544, 553);
            panel1.TabIndex = 0;
            // 
            // lblCustomerIDBIll
            // 
            lblCustomerIDBIll.AutoSize = true;
            lblCustomerIDBIll.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblCustomerIDBIll.ForeColor = Color.SteelBlue;
            lblCustomerIDBIll.Location = new Point(12, 89);
            lblCustomerIDBIll.Name = "lblCustomerIDBIll";
            lblCustomerIDBIll.Size = new Size(72, 20);
            lblCustomerIDBIll.TabIndex = 17;
            lblCustomerIDBIll.Text = "CusID:";
            // 
            // txtCusidbill
            // 
            txtCusidbill.BorderColor = Color.FromArgb(64, 64, 64);
            txtCusidbill.BorderRadius = 20;
            txtCusidbill.CustomizableEdges = customizableEdges25;
            txtCusidbill.DefaultText = "Nguyen Nguyen Toan Khoa";
            txtCusidbill.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtCusidbill.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtCusidbill.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtCusidbill.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtCusidbill.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCusidbill.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtCusidbill.ForeColor = Color.CornflowerBlue;
            txtCusidbill.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtCusidbill.Location = new Point(7, 112);
            txtCusidbill.Margin = new Padding(3, 4, 3, 4);
            txtCusidbill.Name = "txtCusidbill";
            txtCusidbill.PasswordChar = '\0';
            txtCusidbill.PlaceholderText = "";
            txtCusidbill.SelectedText = "";
            txtCusidbill.ShadowDecoration.CustomizableEdges = customizableEdges26;
            txtCusidbill.Size = new Size(219, 43);
            txtCusidbill.TabIndex = 18;
            txtCusidbill.TextAlign = HorizontalAlignment.Center;
            // 
            // lblD
            // 
            lblD.AutoSize = true;
            lblD.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblD.ForeColor = Color.SteelBlue;
            lblD.Location = new Point(10, 31);
            lblD.Name = "lblD";
            lblD.Size = new Size(38, 20);
            lblD.TabIndex = 19;
            lblD.Text = "ID:";
            // 
            // txtIDBIill
            // 
            txtIDBIill.BorderColor = Color.FromArgb(64, 64, 64);
            txtIDBIill.BorderRadius = 20;
            txtIDBIill.CustomizableEdges = customizableEdges23;
            txtIDBIill.DefaultText = "012";
            txtIDBIill.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtIDBIill.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtIDBIill.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtIDBIill.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtIDBIill.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtIDBIill.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtIDBIill.ForeColor = Color.CornflowerBlue;
            txtIDBIill.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtIDBIill.Location = new Point(51, 22);
            txtIDBIill.Margin = new Padding(3, 4, 3, 4);
            txtIDBIill.Name = "txtIDBIill";
            txtIDBIill.PasswordChar = '\0';
            txtIDBIill.PlaceholderText = "";
            txtIDBIill.SelectedText = "";
            txtIDBIill.ShadowDecoration.CustomizableEdges = customizableEdges24;
            txtIDBIill.Size = new Size(85, 46);
            txtIDBIill.TabIndex = 20;
            txtIDBIill.TextAlign = HorizontalAlignment.Center;
            // 
            // lblstaffidbill
            // 
            lblstaffidbill.AutoSize = true;
            lblstaffidbill.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblstaffidbill.ForeColor = Color.SteelBlue;
            lblstaffidbill.Location = new Point(274, 89);
            lblstaffidbill.Name = "lblstaffidbill";
            lblstaffidbill.Size = new Size(81, 20);
            lblstaffidbill.TabIndex = 21;
            lblstaffidbill.Text = "StaffID:";
            // 
            // lblproductidbill
            // 
            lblproductidbill.AutoSize = true;
            lblproductidbill.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblproductidbill.ForeColor = Color.SteelBlue;
            lblproductidbill.Location = new Point(23, 170);
            lblproductidbill.Name = "lblproductidbill";
            lblproductidbill.Size = new Size(106, 20);
            lblproductidbill.TabIndex = 22;
            lblproductidbill.Text = "Productid:";
            // 
            // txtStaffidbill
            // 
            txtStaffidbill.BorderColor = Color.FromArgb(64, 64, 64);
            txtStaffidbill.BorderRadius = 20;
            txtStaffidbill.CustomizableEdges = customizableEdges21;
            txtStaffidbill.DefaultText = "ToanKhoa@gmail.com";
            txtStaffidbill.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtStaffidbill.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtStaffidbill.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtStaffidbill.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtStaffidbill.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtStaffidbill.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtStaffidbill.ForeColor = Color.CornflowerBlue;
            txtStaffidbill.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtStaffidbill.Location = new Point(257, 113);
            txtStaffidbill.Margin = new Padding(3, 4, 3, 4);
            txtStaffidbill.Name = "txtStaffidbill";
            txtStaffidbill.PasswordChar = '\0';
            txtStaffidbill.PlaceholderText = "";
            txtStaffidbill.SelectedText = "";
            txtStaffidbill.ShadowDecoration.CustomizableEdges = customizableEdges22;
            txtStaffidbill.Size = new Size(221, 43);
            txtStaffidbill.TabIndex = 25;
            txtStaffidbill.TextAlign = HorizontalAlignment.Center;
            // 
            // txtPhone
            // 
            txtPhone.BorderColor = Color.FromArgb(64, 64, 64);
            txtPhone.BorderRadius = 20;
            txtPhone.CustomizableEdges = customizableEdges19;
            txtPhone.DefaultText = "999-9999-999";
            txtPhone.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtPhone.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtPhone.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtPhone.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtPhone.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPhone.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtPhone.ForeColor = Color.CornflowerBlue;
            txtPhone.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtPhone.Location = new Point(7, 194);
            txtPhone.Margin = new Padding(3, 4, 3, 4);
            txtPhone.Name = "txtPhone";
            txtPhone.PasswordChar = '\0';
            txtPhone.PlaceholderText = "";
            txtPhone.SelectedText = "";
            txtPhone.ShadowDecoration.CustomizableEdges = customizableEdges20;
            txtPhone.Size = new Size(219, 43);
            txtPhone.TabIndex = 26;
            txtPhone.TextAlign = HorizontalAlignment.Center;
            // 
            // dtpDayBuying
            // 
            dtpDayBuying.BorderRadius = 20;
            dtpDayBuying.Checked = true;
            dtpDayBuying.CustomizableEdges = customizableEdges17;
            dtpDayBuying.FillColor = Color.FromArgb(192, 192, 255);
            dtpDayBuying.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            dtpDayBuying.Format = DateTimePickerFormat.Long;
            dtpDayBuying.Location = new Point(258, 22);
            dtpDayBuying.MaxDate = new DateTime(9998, 12, 31, 0, 0, 0, 0);
            dtpDayBuying.MinDate = new DateTime(1753, 1, 1, 0, 0, 0, 0);
            dtpDayBuying.Name = "dtpDayBuying";
            dtpDayBuying.ShadowDecoration.CustomizableEdges = customizableEdges18;
            dtpDayBuying.Size = new Size(220, 46);
            dtpDayBuying.TabIndex = 29;
            dtpDayBuying.Value = new DateTime(2024, 4, 16, 17, 49, 34, 508);
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.SteelBlue;
            label2.Location = new Point(162, 34);
            label2.Name = "label2";
            label2.Size = new Size(90, 20);
            label2.TabIndex = 30;
            label2.Text = "Day Buy:";
            // 
            // txtlabourcost
            // 
            txtlabourcost.BorderColor = Color.FromArgb(64, 64, 64);
            txtlabourcost.BorderRadius = 20;
            txtlabourcost.CustomizableEdges = customizableEdges15;
            txtlabourcost.DefaultText = "HCMC";
            txtlabourcost.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtlabourcost.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtlabourcost.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtlabourcost.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtlabourcost.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtlabourcost.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            txtlabourcost.ForeColor = Color.CornflowerBlue;
            txtlabourcost.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtlabourcost.Location = new Point(253, 194);
            txtlabourcost.Margin = new Padding(3, 4, 3, 4);
            txtlabourcost.Name = "txtlabourcost";
            txtlabourcost.PasswordChar = '\0';
            txtlabourcost.PlaceholderText = "";
            txtlabourcost.SelectedText = "";
            txtlabourcost.ShadowDecoration.CustomizableEdges = customizableEdges16;
            txtlabourcost.Size = new Size(225, 43);
            txtlabourcost.TabIndex = 31;
            txtlabourcost.TextAlign = HorizontalAlignment.Center;
            // 
            // lblabourcostbill
            // 
            lblabourcostbill.AutoSize = true;
            lblabourcostbill.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblabourcostbill.ForeColor = Color.SteelBlue;
            lblabourcostbill.Location = new Point(274, 170);
            lblabourcostbill.Name = "lblabourcostbill";
            lblabourcostbill.Size = new Size(54, 20);
            lblabourcostbill.TabIndex = 32;
            lblabourcostbill.Text = "Cost:";
            // 
            // panel2
            // 
            panel2.Controls.Add(lblabourcostbill);
            panel2.Controls.Add(txtlabourcost);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(dtpDayBuying);
            panel2.Controls.Add(txtPhone);
            panel2.Controls.Add(txtStaffidbill);
            panel2.Controls.Add(lblproductidbill);
            panel2.Controls.Add(lblstaffidbill);
            panel2.Controls.Add(txtIDBIill);
            panel2.Controls.Add(lblD);
            panel2.Controls.Add(txtCusidbill);
            panel2.Controls.Add(lblCustomerIDBIll);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(544, 269);
            panel2.TabIndex = 18;
            // 
            // btnTopCustomer
            // 
            btnTopCustomer.BorderRadius = 20;
            btnTopCustomer.CustomizableEdges = customizableEdges1;
            btnTopCustomer.DisabledState.BorderColor = Color.DarkGray;
            btnTopCustomer.DisabledState.CustomBorderColor = Color.DarkGray;
            btnTopCustomer.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnTopCustomer.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnTopCustomer.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnTopCustomer.ForeColor = Color.White;
            btnTopCustomer.Location = new Point(79, 389);
            btnTopCustomer.Name = "btnTopCustomer";
            btnTopCustomer.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnTopCustomer.Size = new Size(147, 56);
            btnTopCustomer.TabIndex = 42;
            btnTopCustomer.Text = "TopCustomer";
            // 
          
            // 
            // btnDeleteBill
            // 
            btnDeleteBill.BorderRadius = 20;
            btnDeleteBill.CustomizableEdges = customizableEdges5;
            btnDeleteBill.DisabledState.BorderColor = Color.DarkGray;
            btnDeleteBill.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDeleteBill.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDeleteBill.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDeleteBill.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            btnDeleteBill.ForeColor = Color.White;
            btnDeleteBill.Location = new Point(258, 389);
            btnDeleteBill.Name = "btnDeleteBill";
            btnDeleteBill.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btnDeleteBill.Size = new Size(103, 56);
            btnDeleteBill.TabIndex = 40;
            btnDeleteBill.Text = "DELETE";
            // 
            // comboSearch
            // 
            comboSearch.BackColor = Color.Transparent;
            comboSearch.BorderColor = Color.FromArgb(64, 64, 64);
            comboSearch.BorderRadius = 20;
            comboSearch.CustomizableEdges = customizableEdges7;
            comboSearch.DrawMode = DrawMode.OwnerDrawFixed;
            comboSearch.DropDownStyle = ComboBoxStyle.DropDownList;
            comboSearch.FocusedColor = Color.FromArgb(94, 148, 255);
            comboSearch.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            comboSearch.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            comboSearch.ForeColor = Color.FromArgb(68, 88, 112);
            comboSearch.ItemHeight = 40;
            comboSearch.Items.AddRange(new object[] { "Product_Name", "Product_ID", "Date_In", "Category_ID" });
            comboSearch.Location = new Point(34, 275);
            comboSearch.Name = "comboSearch";
            comboSearch.ShadowDecoration.CustomizableEdges = customizableEdges8;
            comboSearch.Size = new Size(101, 46);
            comboSearch.TabIndex = 39;
            comboSearch.TextAlign = HorizontalAlignment.Center;
            // 
            // btnSearch
            // 
            btnSearch.BackColor = Color.Transparent;
            btnSearch.BackgroundImage = Properties.Resources.search;
            btnSearch.BackgroundImageLayout = ImageLayout.Stretch;
            btnSearch.CustomizableEdges = customizableEdges9;
            btnSearch.DisabledState.BorderColor = Color.DarkGray;
            btnSearch.DisabledState.CustomBorderColor = Color.DarkGray;
            btnSearch.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnSearch.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnSearch.FillColor = Color.Transparent;
            btnSearch.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            btnSearch.ForeColor = Color.White;
            btnSearch.Location = new Point(447, 284);
            btnSearch.Name = "btnSearch";
            btnSearch.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnSearch.Size = new Size(39, 37);
            btnSearch.TabIndex = 38;
            // 
            // txtSearch
            // 
            txtSearch.BorderColor = Color.FromArgb(64, 64, 64);
            txtSearch.BorderRadius = 15;
            txtSearch.CustomizableEdges = customizableEdges11;
            txtSearch.DefaultText = "";
            txtSearch.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtSearch.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtSearch.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtSearch.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtSearch.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSearch.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point);
            txtSearch.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSearch.Location = new Point(141, 276);
            txtSearch.Margin = new Padding(3, 4, 3, 4);
            txtSearch.Name = "txtSearch";
            txtSearch.PasswordChar = '\0';
            txtSearch.PlaceholderText = "";
            txtSearch.SelectedText = "";
            txtSearch.ShadowDecoration.CustomizableEdges = customizableEdges12;
            txtSearch.Size = new Size(300, 47);
            txtSearch.TabIndex = 37;
            // 
            // lblFilter
            // 
            lblFilter.AutoSize = true;
            lblFilter.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            lblFilter.ForeColor = Color.SteelBlue;
            lblFilter.Location = new Point(34, 341);
            lblFilter.Name = "lblFilter";
            lblFilter.Size = new Size(58, 20);
            lblFilter.TabIndex = 36;
            lblFilter.Text = "Filter";
            // 
            // comboFilter
            // 
            comboFilter.BackColor = Color.Transparent;
            comboFilter.BorderColor = Color.FromArgb(64, 64, 64);
            comboFilter.BorderRadius = 20;
            comboFilter.CustomizableEdges = customizableEdges13;
            comboFilter.DrawMode = DrawMode.OwnerDrawFixed;
            comboFilter.DropDownStyle = ComboBoxStyle.DropDownList;
            comboFilter.FocusedColor = Color.FromArgb(94, 148, 255);
            comboFilter.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            comboFilter.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            comboFilter.ForeColor = Color.FromArgb(68, 88, 112);
            comboFilter.ItemHeight = 40;
            comboFilter.Items.AddRange(new object[] { "Top 5 Customers buying the MOST(Quatity)", "Top 5 Customers  buying the MOST(Money)" });
            comboFilter.Location = new Point(98, 330);
            comboFilter.Name = "comboFilter";
            comboFilter.ShadowDecoration.CustomizableEdges = customizableEdges14;
            comboFilter.Size = new Size(388, 46);
            comboFilter.TabIndex = 35;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Georgia", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(56, 389);
            label5.Name = "label5";
            label5.Size = new Size(0, 20);
            label5.TabIndex = 34;
            // 
            // panel3
            // 
            panel3.Controls.Add(dgvbill);
            panel3.Dock = DockStyle.Fill;
            panel3.Location = new Point(544, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(638, 553);
            panel3.TabIndex = 1;
            // 
            // dgvbill
            // 
            dgvbill.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvbill.Dock = DockStyle.Fill;
            dgvbill.Location = new Point(0, 0);
            dgvbill.Name = "dgvbill";
            dgvbill.RowHeadersWidth = 51;
            dgvbill.RowTemplate.Height = 29;
            dgvbill.Size = new Size(638, 553);
            dgvbill.TabIndex = 0;
            // 
            // FManageBill
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1182, 553);
            Controls.Add(panel3);
            Controls.Add(panel1);
            Name = "FManageBill";
            Text = "FManageBill";
            Load += FManageBill_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvbill).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Label label3;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpBirthday;
        private Label lblabourcostbill;
        private Guna.UI2.WinForms.Guna2TextBox txtlabourcost;
        private Label label2;
        private Guna.UI2.WinForms.Guna2DateTimePicker dtpDayBuying;
        private Guna.UI2.WinForms.Guna2ComboBox comboSex;
        private Label label1;
        private Guna.UI2.WinForms.Guna2TextBox txtPhone;
        private Guna.UI2.WinForms.Guna2TextBox txtStaffidbill;
        private Guna.UI2.WinForms.Guna2TextBox txtRank;
        private Label lblRank;
        private Label lblproductidbill;
        private Label lblstaffidbill;
        private Guna.UI2.WinForms.Guna2TextBox txtIDBIill;
        private Label lblD;
        private Guna.UI2.WinForms.Guna2TextBox txtCusidbill;
        private Label lblCustomerIDBIll;
        private Guna.UI2.WinForms.Guna2Button btnTopCustomer;
        private Guna.UI2.WinForms.Guna2Button btnUpdate;
        private Guna.UI2.WinForms.Guna2Button btnDeleteBill;
        private Guna.UI2.WinForms.Guna2ComboBox comboSearch;
        private Guna.UI2.WinForms.Guna2Button btnSearch;
        private Guna.UI2.WinForms.Guna2TextBox txtSearch;
        private Label lblFilter;
        private Guna.UI2.WinForms.Guna2ComboBox comboFilter;
        private Label label5;
        private Panel panel3;
        private DataGridView dgvbill;
    }
}