﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store_Gold
{
    public class Person
    {
        private string name;
        private string cmnd;
        private string address;
        private string email;
        private string phone;
        private DateTime birthday;

        public string FullName
        {
            get { return name; }
            set { name = value; }
        }
        public string CMND
        {
            get { return cmnd; }
            set { cmnd = value; }
        }
        public string Address
        {
            get { return address; }
            set { address = value; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }
        public string PhoneNumber
        {
            get { return phone; }
            set { phone = value; }
        }

        public DateTime Birthday {
            get { return birthday; }
            set { birthday = value; } 
        }

        public Person() { }
        public Person(string FullName, string CMND, string Address, string Email, string PhoneNumber,DateTime Birthday)
        {

            this.FullName = FullName;
            this.CMND = CMND;
            this.Address = Address;
            this.Email = Email;
            this.PhoneNumber = PhoneNumber;
            this.Birthday = Birthday;
        }
    }
}
