﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Store_Gold
{
    public partial class FHome : Form
    {
        int index1 = 0;
        int index2 = 0;
        DBConnection db = new DBConnection();
        SqlConnection conn = new SqlConnection(Properties.Settings.Default.cnnstr);

        public FHome()
        {
            InitializeComponent();
            ptbListRing.Image = imagelistRing.Images[index1];
            ptbListOther.Image = imagelistOther.Images[index2];
   
        }

        private void FHome_Load(object sender, EventArgs e)
        {
            dgvrevenue.DataSource = CalculateMonthlyRevenue();
        }


        private void ptbListRing_Click(object sender, EventArgs e)
        {
            index1++;
            if (index1 >= imagelistRing.Images.Count)
            {
                index1 = 0;
            }
            ptbListRing.Image = imagelistRing.Images[index1];
            
        }

        private void ptbListOther_Click(object sender, EventArgs e)
        {
            index2++;
            if (index2 >= imagelistOther.Images.Count)
            {
                index2 = 0;
            }
            ptbListOther.Image = imagelistOther.Images[index2];
        }
        private DataTable CalculateMonthlyRevenue()
        {
            string connectionString = DBConnection.stringconnection;
            DataTable dataTable = new DataTable();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand("SELECT * FROM dbo.CalculateMonthlyRevenue()", connection);
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(dataTable);
            }
            return dataTable;
        }
    }
}
