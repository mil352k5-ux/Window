﻿DECLARE @CategoryID VARCHAR(10);
SELECT @CategoryID = Category_ID FROM CATEGORY WHERE Category_Name = 'Gold';

-- Thêm 10 sản phẩm vàng 24K vào bảng PRODUCT
DECLARE @Category_ID VARCHAR(10)
SET @Category_ID = 'GOLD'

-- Thêm 10 sản phẩm vàng 24K với số lượng cụ thể
-- Thêm 3 sản phẩm vàng 24K
-- Thêm 3 sản phẩm vàng 24K
INSERT INTO PRODUCT (Product_ID, Product_Name, Category_ID, Date_In, Date_Out, Quantity, Mass, Price, Bill_ID, customer_id, Staff_ID)
VALUES 
    ('1', 'Ring', '3', GETDATE(), NULL, 2, 10.0, 10.0 * (SELECT Category_Price FROM CATEGORY WHERE Category_ID = '3'), NULL, NULL, NULL),
    ('2', 'Bracelet', '3', GETDATE(), NULL, 2, 10.0, 10.0 * (SELECT Category_Price FROM CATEGORY WHERE Category_ID = '3'), NULL, NULL, NULL),
    ('3', 'Chain', '3', GETDATE(), NULL, 2, 10.0, 10.0 * (SELECT Category_Price FROM CATEGORY WHERE Category_ID = '3'), NULL, NULL, NULL),
    ('4', 'Earring', '3', GETDATE(), NULL, 2, 10.0, 10.0 * (SELECT Category_Price FROM CATEGORY WHERE Category_ID = '3'), NULL, NULL, NULL),
    ('5', 'Necklaces', '3', GETDATE(), NULL, 2, 10.0, 10.0 * (SELECT Category_Price FROM CATEGORY WHERE Category_ID = '3'), NULL, NULL, NULL);

-- Thêm 3 sản phẩm bạc
INSERT INTO PRODUCT (Product_ID, Product_Name, Category_ID, Date_In, Date_Out, Quantity, Mass, Price, Bill_ID, customer_id, Staff_ID)
VALUES 
      ('6', 'Ring', '2', GETDATE(), NULL, 2, 5.0, 10.0 * (SELECT Category_Price FROM CATEGORY WHERE Category_ID = '2'), NULL, NULL, NULL),
    ('7', 'Bracelet', '2', GETDATE(), NULL, 2, 5.0, 10.0 * (SELECT Category_Price FROM CATEGORY WHERE Category_ID = '2'), NULL, NULL, NULL),
    ('8', 'Chain', '2', GETDATE(), NULL, 2, 5.0, 10.0 * (SELECT Category_Price FROM CATEGORY WHERE Category_ID = '2'), NULL, NULL, NULL),
    ('9', 'Earring', '2', GETDATE(), NULL, 2, 7.0, 10.0 * (SELECT Category_Price FROM CATEGORY WHERE Category_ID = '2'), NULL, NULL, NULL),
    ('10', 'Necklaces', '2', GETDATE(), NULL, 2, 8.0, 10.0 * (SELECT Category_Price FROM CATEGORY WHERE Category_ID = '2'), NULL, NULL, NULL);
    -- Thêm 3 sản phẩm vàng 18k
INSERT INTO PRODUCT (Product_ID, Product_Name, Category_ID, Date_In, Date_Out, Quantity, Mass, Price, Bill_ID, customer_id, Staff_ID)
VALUES 
    ('11', 'Ring', '1', GETDATE(), NULL, 2, 10.0, 10.0 * (SELECT Category_Price FROM CATEGORY WHERE Category_ID = '1'), NULL, NULL, NULL),
    ('12', 'Bracelet', '1', GETDATE(), NULL, 2, 10.0, 10.0 * (SELECT Category_Price FROM CATEGORY WHERE Category_ID = '1'), NULL, NULL, NULL),
    ('13', 'Chain', '1', GETDATE(), NULL, 2, 10.0, 10.0 * (SELECT Category_Price FROM CATEGORY WHERE Category_ID = '1'), NULL, NULL, NULL),
    ('14', 'Earring', '1', GETDATE(), NULL, 2, 10.0, 10.0 * (SELECT Category_Price FROM CATEGORY WHERE Category_ID = '1'), NULL, NULL, NULL),
    ('15', 'Necklaces', '1', GETDATE(), NULL, 2, 10.0, 10.0 * (SELECT Category_Price FROM CATEGORY WHERE Category_ID = '1'), NULL, NULL, NULL);

INSERT INTO CATEGORY (Category_ID, Category_Name, Category_Price)
VALUES ('1', 'Gold18K', 4200000),  -- Ví dụ giá vàng là 1000.00
       ('2', 'Silver', 6100000 ),  -- Ví dụ giá bạc là 500.00
       ('3', 'Gold24k',  100000); 
DELETE from PRODUCT where Product_ID < '33' 
-- Thêm các nhà cung cấp
INSERT INTO SUPPLIER (Supplier_ID, Supplier_Name, Supplier_Address)
VALUES 
    ('1', 'Tobey ', 'Long An'),
    ('2',  'Vy', 'Nhon Trach Dong Nai'),
    ('3',  'Cheese', 'Binh Dinh');

------------------- Sản phẩm

INSERT INTO PROVIDES (Supplier_ID, Product_ID, Provide_Name)
VALUES 
    ('1', '11', 'Ring'),
    ('1', '12', 'Bracelet'),
    ('1', '13', 'Chain'),
    ('1', '14', 'Earring'),
    ('1', '15', 'Necklaces'),
    ('2', '6', 'Ring'),
    ('2', '7', 'Bracelet'),
    ('2', '8', 'Chain'),
    ('2', '9', 'Earring'),
    ('2', '10', 'Necklaces'),
    ('3', '1', 'Ring'),
    ('3', '2', 'Bracelet'),
    ('3', '3', 'Chain'),
    ('3', '4', 'Earring'),
    ('3', '5', 'Necklaces');
