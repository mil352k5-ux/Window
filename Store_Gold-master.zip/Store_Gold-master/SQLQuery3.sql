﻿CREATE TRIGGER CreateProductAfterSupplierProvides
ON PROVIDES
AFTER INSERT
AS
BEGIN
    -- Insert new products into PRODUCT table based on the provided supplies
    INSERT INTO PRODUCT (Product_ID, Product_Name, Category_ID, Date_In, Quantity, Mass, Bill_ID, customer_id, Staff_ID)
    SELECT i.Product_ID, s.Product_Name, c.Category_ID, GETDATE(), 0, 0.0, NULL, NULL, NULL
    FROM inserted i
    INNER JOIN SUPPLIER s ON i.Supplier_ID = s.Supplier_ID
    INNER JOIN CATEGORY c ON s.Product_ID = c.Product_ID;
END;
------------------------
CREATE TRIGGER UpdateTransactionHistory    -- update history of bill ( create table history)
ON BILL
AFTER INSERT
AS
BEGIN
    -- Insert a new record into TRANSACTION_HISTORY table for each inserted record in BILL table
    INSERT INTO TRANSACTION_HISTORY (Transaction_Date, Customer_ID, Staff_ID, Product_ID, Total_Amount)
    SELECT 
        GETDATE(), -- Current date
        inserted.customer_id,
        inserted.Staff_ID,
        inserted.Product_ID,
        inserted.Total_Amount
    FROM 
        inserted;
END;

CREATE TABLE staff (
    staff_ID VARCHAR(10) PRIMARY KEY,
    Staff_Name VARCHAR(50) NOT NULL,
    Staff_Address VARCHAR(100) NOT NULL,
    admin_id VARCHAR(10),
    FOREIGN KEY (admin_id) REFERENCES ADMIN(admin_id),
    FOREIGN KEY (staff_id) REFERENCES LogininFo(userid)
);

CREATE TABLE staff_phone (
    staff_ID VARCHAR(10),
    staff_Phone VARCHAR(50),
    admin_ID VARCHAR(10),
    FOREIGN KEY (staff_id) REFERENCES staff(staff_ID),
    FOREIGN KEY (admin_id) REFERENCES admin(admin_ID),
    PRIMARY KEY (staff_id, staff_Phone)
);
CREATE TABLE Staff_Email (
    staff_ID VARCHAR(10),
    staff_Email VARCHAR(50),
    admin_ID VARCHAR(10),
    FOREIGN KEY (staff_id) REFERENCES staff(Staff_ID),
    FOREIGN KEY (admin_id) REFERENCES admin(admin_id),
    PRIMARY KEY (Staff_ID, Staff_Email)
);

CREATE TABLE ADMIN (
    admin_id VARCHAR(10) PRIMARY KEY,
    Ad_Name VARCHAR(50) NOT NULL,
    Ad_Address VARCHAR(100) NOT NULL
    FOREIGN KEY (Admin_id) REFERENCES LogininFO(userid) ON DELETE CASCADE,
);

CREATE TABLE ADMIN_Phone (
    admin_id VARCHAR(10),
    admin_phone VARCHAR(50) NOT NULL,
    FOREIGN KEY (admin_id) REFERENCES ADMIN(admin_id),
    PRIMARY KEY (admin_id, admin_phone)
);

CREATE TABLE ADMIN_Email (
    admin_id VARCHAR(10),
    admin_email VARCHAR(50) NOT NULL,
    FOREIGN KEY (admin_id) REFERENCES ADMIN(admin_id),
    PRIMARY KEY (admin_id, admin_email)
);
CREATE TABLE LOGININFO (
    UserID VARCHAR(10) PRIMARY KEY,
    Password VARCHAR(20) NOT NULL,
    UserName VARCHAR(20) NOT NULL,
   

);

CREATE TABLE CUSTOMER (
	customer_id VARCHAR(10) PRIMARY KEY,
    customer_name VARCHAR(50) NOT NULL,
    customer_address VARCHAR(100) NOT NULL,
	customer_birthday DATE
);
GO
CREATE TABLE customer_phone(
   customer_id VARCHAR(10),
   customer_phone VARCHAR(50),
    FOREIGN KEY (customer_id) REFERENCES CUSTOMER(customer_id),
    PRIMARY KEY (customer_id, Customer_Phone)
);
CREATE TABLE CustomerDetails (
    customer_id VARCHAR(10) primary key,
    customer_name VARCHAR(50),
    customer_address VARCHAR(100),
    customer_birthday DATE,
    customer_phone VARCHAR(50),
    customer_email VARCHAR(50)
);

INSERT INTO CustomerDetails (customer_id, customer_name, customer_address, customer_birthday, customer_phone, customer_email)
SELECT c.customer_id, c.customer_name, c.customer_address, c.customer_birthday,
       cp.customer_phone, ce.customer_email
FROM CUSTOMER c
LEFT JOIN customer_phone cp ON c.customer_id = cp.customer_id
LEFT JOIN customer_email ce ON c.customer_id = ce.customer_id;
GO

CREATE TABLE PRODUCT (
    Product_ID VARCHAR(10) PRIMARY KEY,
    Product_Name VARCHAR(50) NOT NULL,
    Category_ID VARCHAR(10),
    Date_In DATE,
    Date_Out DATE,
    Quantity INT,
    Mass DECIMAL(10, 2),
    Bill_ID VARCHAR(10),
    customer_id VARCHAR(10),
    Staff_ID VARCHAR(10),
    --FOREIGN KEY (Category_ID) REFERENCES CATEGORY(Category_ID),
    --FOREIGN KEY (Bill_ID) REFERENCES bill(Bill_ID),
    FOREIGN KEY (customer_id) REFERENCES CUSTOMER(customer_id),
    FOREIGN KEY (Staff_ID) REFERENCES STAFF(Staff_ID)
);
ALTER TABLE product ADD CONSTRAINT fk_categoryid_Product FOREIGN KEY (category_id) REFERENCES Category (category_id);
ALTER TABLE product ADD CONSTRAINT fk_billid_Product FOREIGN KEY (bill_id) REFERENCES bill (bill_id);

CREATE TABLE SelectedProduct (
    SelectedProductID INT PRIMARY KEY IDENTITY,
    ProductID VARCHAR(10) NOT NULL,
    ProductName VARCHAR(50) NOT NULL,
    CategoryID VARCHAR(10) NOT NULL,
    Price DECIMAL(10, 2) NOT NULL,
    BillID VARCHAR(10) NOT NULL,
    CONSTRAINT FK_SelectedProduct_ProductID FOREIGN KEY (ProductID) REFERENCES PRODUCT(Product_ID),
    CONSTRAINT FK_SelectedProduct_CategoryID FOREIGN KEY (CategoryID) REFERENCES CATEGORY(Category_ID),
);

CREATE TABLE CATEGORY (
    Category_ID VARCHAR(10) PRIMARY KEY,
    Category_Name VARCHAR(50) NOT NULL,
    Category_Price DECIMAL(10, 2)
);

CREATE TABLE SUPPLIER (
    Supplier_ID VARCHAR(10) PRIMARY KEY,
    Product_ID VARCHAR(10),
    Supplier_Name VARCHAR(50) NOT NULL,
    Supplier_Address VARCHAR(100),
    --FOREIGN KEY (Product_ID) REFERENCES PRODUCT(Product_ID)
);
ALTER TABLE supplier ADD CONSTRAINT fk_Productid_Supplier FOREIGN KEY (product_id) REFERENCES product (product_id);

CREATE TABLE SUPPLIER_Phone (
    Supplier_ID VARCHAR(10),
    Product_ID VARCHAR(10),
    Supplier_Phone VARCHAR(20),
    FOREIGN KEY (Supplier_ID) REFERENCES SUPPLIER(Supplier_ID),
    FOREIGN KEY (Product_ID) REFERENCES PRODUCT(Product_ID),
    PRIMARY KEY (Supplier_ID, Product_ID, Supplier_Phone)
);

CREATE TABLE SUPPLIER_Email (
    Supplier_ID VARCHAR(10),
    Product_ID VARCHAR(10),
    Supplier_Email VARCHAR(50),
    FOREIGN KEY (Supplier_ID) REFERENCES SUPPLIER(Supplier_ID),
    FOREIGN KEY (Product_ID) REFERENCES PRODUCT(Product_ID),
    PRIMARY KEY (Supplier_ID, Product_ID, Supplier_Email)
);

CREATE TABLE PROVIDES (
    Supplier_ID VARCHAR(10),
    Product_ID VARCHAR(10),
    FOREIGN KEY (Supplier_ID) REFERENCES SUPPLIER(Supplier_ID),
    FOREIGN KEY (Product_ID) REFERENCES PRODUCT(Product_ID),
    PRIMARY KEY (Supplier_ID, Product_ID)
);

CREATE TABLE BILL (
    Bill_ID VARCHAR(10) PRIMARY KEY,
    Product_ID VARCHAR(10),
   customer_id VARCHAR(10),
    Staff_ID VARCHAR(10),
    Labour_Cost DECIMAL(10, 2),
    Date_out Date,
    FOREIGN KEY (Product_ID) REFERENCES PRODUCT(Product_ID),
    FOREIGN KEY (customer_id) REFERENCES  CustomerDetails(customer_id),
    FOREIGN KEY (Staff_ID) REFERENCES STAFF(Staff_ID)
);
-------------------------------- Procedure Customer 
go
CREATE PROCEDURE EditCustomer
    @customer_id VARCHAR(10),
    @NewCustomer_Name VARCHAR(50),
    @NewCustomer_Address VARCHAR(100),
    @NewCustomer_Phone VARCHAR(100),
    @NewCustomer_Birthday DATE,
    @NewCustomer_Email VARCHAR(100)

AS
BEGIN
    UPDATE CustomerDetails
    SET customer_name = @NewCustomer_Name, customer_address = @NewCustomer_Address, customer_birthday = @NewCustomer_Birthday, 
        customer_phone = @NewCustomer_Phone, customer_email = @NewCustomer_Email
    WHERE customer_id = @customer_id;
    
END;
--------
go
CREATE PROCEDURE DeleteCustomer1
    @Customer_id VARCHAR(10)
AS
BEGIN
    DELETE FROM CustomerDetails
    WHERE customer_id = @Customer_id;
END;
SELECT name
FROM sys.procedures
CREATE PROCEDURE AddCustomer2
    @NewCustomer_id VARCHAR(10),
    @NewCustomer_Name VARCHAR(50),
    @NewCustomer_Address VARCHAR(100),
    @NewCustomer_Phone VARCHAR(100),
    @NewCustomer_Birthday DATE,
    @NewCustomer_Email VARCHAR(100)  -- Assuming you have an email parameter

AS
BEGIN
    INSERT INTO CustomerDetails(customer_id, customer_name, customer_address, customer_birthday, customer_phone, customer_email)
    VALUES (@NewCustomer_id , @NewCustomer_Name, @NewCustomer_Address, @NewCustomer_Birthday, @NewCustomer_Phone, @NewCustomer_Email);
END;
------------------------------------------------------------------
---procedure Product----
CREATE PROCEDURE AddProduct5
    @Product_ID VARCHAR(10),
    @Product_Name VARCHAR(50),
    @Category_ID VARCHAR(10),
    @Date_In DATE,
    @Date_Out DATE,
    @Quantity INT,
    @Mace DECIMAL(10, 2)
AS
BEGIN
    DECLARE @Price DECIMAL(10, 2);

    -- Lấy giá của loại sản phẩm từ bảng CATEGORY
    SELECT @Price = Category_Price
    FROM CATEGORY
    WHERE Category_ID = @Category_ID;

    -- Tính toán giá sản phẩm dựa trên mace và giá của loại sản phẩm
    SET @Price = @Price * @Mace;

    -- Chèn dữ liệu mới vào bảng PRODUCT
    INSERT INTO PRODUCT (Product_ID, Product_Name, Category_ID, Date_In, Date_Out, Quantity, Mace, Price)
    VALUES (@Product_ID, @Product_Name, @Category_ID, @Date_In, @Date_Out, @Quantity, @Mace, @Price);
END;

--delete
CREATE PROCEDURE DeleteProduct
    @Product_ID VARCHAR(10)
AS
BEGIN
    DELETE FROM PRODUCT
    WHERE Product_ID = @Product_ID;
END;

--update
CREATE PROCEDURE UpdateProduct1
    @Product_ID VARCHAR(10),
    @Product_Name VARCHAR(50),
    @Category_ID VARCHAR(10),
    @Date_In DATE,
    @Date_Out DATE,
    @Quantity INT,
    @Mace DECIMAL(10, 2),
    @Price DECIMAL(10,2),
    @Bill_ID VARCHAR(10),
    @customer_id VARCHAR(10),
    @Staff_ID VARCHAR(10)
AS
BEGIN
    UPDATE PRODUCT
    SET Product_Name = @Product_Name,
        Category_ID = @Category_ID,
        Date_In = @Date_In,
        Date_Out = @Date_Out,
        Quantity = @Quantity,
        Mace = @Mace,
        Price = @Price,
        Bill_ID = @Bill_ID,
        customer_id = @customer_id,
        Staff_ID = @Staff_ID
    WHERE Product_ID = @Product_ID;
END;

---search Product
CREATE PROCEDURE SearchProduct1
    @SearchType VARCHAR(50),
    @SearchText VARCHAR(100)
AS
BEGIN
    IF @SearchType = 'Product_ID'
    BEGIN
        SELECT * FROM PRODUCT WHERE Product_ID = @SearchText;
    END
    ELSE IF @SearchType = 'Product_Name'
    BEGIN
        SELECT * FROM PRODUCT WHERE Product_Name LIKE '%' + @SearchText + '%';
    END
    ELSE IF @SearchType = 'Category_ID'
    BEGIN
        SELECT * FROM PRODUCT WHERE Category_ID = @SearchText;
    END
    ELSE IF @SearchType = 'Date_In'
    BEGIN
        SELECT * FROM PRODUCT WHERE Date_In = @SearchText;
    END
    ELSE IF @SearchType = 'None'  -- Thêm điều kiện mới
    BEGIN
        SELECT * FROM PRODUCT;  -- Hiển thị tất cả sản phẩm
    END
END;
------------------------------------ searchFilter
CREATE PROCEDURE SearchFilter
    @CategoryName VARCHAR(50)
AS
BEGIN
    SELECT P.*
    FROM PRODUCT P
    INNER JOIN CATEGORY C ON P.Category_ID = C.Category_ID
    WHERE C.Category_Name = @CategoryName;
END;
-------------------------------------- Getstaff inffor
CREATE PROCEDURE GetStaffInfo2
    @Staff_ID VARCHAR(10)
AS
BEGIN
    SELECT Staff_Id, Staff_Name, Staff_Address
    FROM Staff
    WHERE Staff_ID = @Staff_ID;
END;
-------------------------------------- selectedProducts
CREATE PROCEDURE selectedProducts
AS
BEGIN
    SELECT *
    FROM SelectedProduct;
END;
-------------------------------------- add to selected products
CREATE PROCEDURE AddToSelectedProducts2
    @ProductID VARCHAR(10),
    @ProductName VARCHAR(50),
    @CategoryID VARCHAR(10),
    @Price DECIMAL(10, 2)
AS
BEGIN
    INSERT INTO SelectedProduct (ProductID, ProductName, CategoryID, Price)
    VALUES (@ProductID, @ProductName, @CategoryID, @Price);
END;
------------------------------------- clear selected products
CREATE PROCEDURE ClearSelectedProducts
AS
BEGIN
    DELETE FROM SelectedProduct;
END;
------------------------------------- addbill
CREATE PROCEDURE AddBill3
    @Bill_ID VARCHAR(10),
    @Product_ID VARCHAR(10),
    @Customer_ID VARCHAR(10),
    @Staff_ID VARCHAR(10),
    @Date_out date
AS
BEGIN
    INSERT INTO BILL (Bill_ID, Product_ID, Customer_ID, Staff_ID , Date_Out)
    VALUES (@Bill_ID, @Product_ID, @Customer_ID, @Staff_ID , @Date_out );
END;
-------------------------------------- getbillbyid
CREATE PROCEDURE GetBillByID
    @Bill_ID VARCHAR(10)
AS
BEGIN
    SELECT * FROM Bill WHERE Bill_ID = @Bill_ID;
END;
--------------------------------------- reduce quantity
CREATE PROCEDURE DeductProductQuantity1
    @ProductId INT,
    @QuantityToDeduct INT
AS
BEGIN
    UPDATE Product
    SET Quantity = Quantity - @QuantityToDeduct
    WHERE Product_Id = @ProductId
END



