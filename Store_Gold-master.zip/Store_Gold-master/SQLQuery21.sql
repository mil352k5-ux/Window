﻿INSERT INTO staff (staff_ID, Staff_Name, Staff_Address, admin_id)
VALUES ('EMP002', 'Nguyễn Văn B', '123 Đường ABC, Quận XYZ, Thành phố HCM', 'ADM001');
