﻿INSERT INTO ADMIN (admin_id, Ad_Name, Ad_Address)
VALUES ('ADMIN001', 'TOBEY', 'LONG AN');