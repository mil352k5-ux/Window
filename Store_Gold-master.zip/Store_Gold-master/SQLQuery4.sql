﻿INSERT INTO staff (staff_ID, Staff_Name, Staff_Address, admin_id)
VALUES ('STF002', 'John', '123 Main Street', 'ADM001');
INSERT INTO ADMIN (admin_id, Ad_Name, Ad_Address)
VALUES ('ADM001', 'Admin Name', 'Admin Address'); 