﻿DECLARE @CategoryID VARCHAR(10);
SELECT @CategoryID = Category_ID FROM CATEGORY WHERE Category_Name = 'Gold';

-- Thêm 10 sản phẩm vàng 24K vào bảng PRODUCT
DECLARE @Category_ID VARCHAR(10)
SET @Category_ID = 'GOLD'

-- Thêm 10 sản phẩm vàng 24K với số lượng cụ thể
-- Thêm 3 sản phẩm vàng 24K
-- Thêm 3 sản phẩm vàng 24K
INSERT INTO PRODUCT (Product_ID, Product_Name, Category_ID, Date_In, Date_Out, Quantity, Mass, Price, Bill_ID, customer_id, Staff_ID)
VALUES 
    ('GOLD24K001', 'Gold 24K Product 1', '3', GETDATE(), NULL, 50, 10.0, 10.0 * (SELECT Category_Price FROM CATEGORY WHERE Category_ID = '3'), NULL, NULL, NULL),
    ('GOLD24K002', 'Gold 24K Product 2', '3', GETDATE(), NULL, 30, 10.0, 10.0 * (SELECT Category_Price FROM CATEGORY WHERE Category_ID = '3'), NULL, NULL, NULL),
    ('GOLD24K003', 'Gold 24K Product 3', '3', GETDATE(), NULL, 70, 10.0, 10.0 * (SELECT Category_Price FROM CATEGORY WHERE Category_ID = '3'), NULL, NULL, NULL);

-- Thêm 3 sản phẩm bạc
INSERT INTO PRODUCT (Product_ID, Product_Name, Category_ID, Date_In, Date_Out, Quantity, Mass, Price, Bill_ID, customer_id, Staff_ID)
VALUES 
    ('SILVER001', 'Silver Product 1', '2', GETDATE(), NULL, 40, 5.0, 5.0 * (SELECT Category_Price FROM CATEGORY WHERE Category_ID = '2'), NULL, NULL, NULL),
    ('SILVER002', 'Silver Product 2', '2', GETDATE(), NULL, 25, 5.0, 5.0 * (SELECT Category_Price FROM CATEGORY WHERE Category_ID = '2'), NULL, NULL, NULL),
    ('SILVER003', 'Silver Product 3', '2', GETDATE(), NULL, 60, 5.0, 5.0 * (SELECT Category_Price FROM CATEGORY WHERE Category_ID = '2'), NULL, NULL, NULL);


INSERT INTO CATEGORY (Category_ID, Category_Name, Category_Price)
VALUES ('1', 'Gold18K', 4200000),  -- Ví dụ giá vàng là 1000.00
       ('2', 'Silver', 6100000 ),  -- Ví dụ giá bạc là 500.00
       ('3', 'Gold24k',  100000); 
DELETE FROM PRODUCT
WHERE Date_In = '2024-04-17';