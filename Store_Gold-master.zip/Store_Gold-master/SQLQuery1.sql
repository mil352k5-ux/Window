﻿INSERT INTO Staff (staff_id, staff_Name, staff_Address, admin_id)
VALUES ('ThanhVy01', 'vy', 'LONG AN', 'ADMIN001');
SELECT * FROM BILL;
INSERT INTO Staff (staff_id, staff_Name, staff_Address, admin_id)
VALUES ('EMP012', 'tobeynguyen', 'LONG AN', 'ADMIN001');
SELECT 
    permission_name AS PermissionName,
    state_desc AS PermissionState
FROM 
    sys.fn_my_permissions(NULL, 'Store_gold') -- Thay 'SERVER' bằng tên cụ thể của đối tượng nếu muốn kiểm tra trên đối tượng khác
WHERE 
    HAS_PERMS_BY_NAME('StaffRolene2', 'Store_gold', permission_name) = 1; -- Thay 'TênVaiTro' bằng tên của vai trò bạn muốn kiểm tra
DROP LOGIN Staffrolene2;
DROP USER ADMIN003;
